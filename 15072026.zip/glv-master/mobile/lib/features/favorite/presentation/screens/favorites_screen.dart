// lib/features/favorite/presentation/screens/favorites_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/api/api_client.dart';

final favoritesProvider = FutureProvider<List<Map<String, dynamic>>>((ref) async {
  final res = await ref.read(dioProvider).get('/favorites');
  final data = res.data['data'] ?? res.data;
  return List<Map<String, dynamic>>.from(data);
});

class FavoritesScreen extends ConsumerWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favAsync = ref.watch(favoritesProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Favorilerim')),
      body: favAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Hata: $e')),
        data: (favorites) {
          if (favorites.isEmpty) {
            return Center(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.favorite_border, size: 72, color: Colors.grey),
                const SizedBox(height: 16),
                const Text('Henüz favori restoranınız yok', style: TextStyle(color: Colors.grey, fontSize: 16)),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => context.go('/home'),
                  child: const Text('Restoranlara Göz At'),
                ),
              ]),
            );
          }

          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(favoritesProvider),
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: favorites.length,
              itemBuilder: (ctx, i) {
                final fav = favorites[i];
                final branches = fav['branches'] as List? ?? [];
                final openBranch = branches.firstWhere((b) => b['is_open'] == true, orElse: () => branches.isNotEmpty ? branches.first : null);

                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16),
                    leading: Container(
                      width: 52, height: 52,
                      decoration: const BoxDecoration(color: Color(0xFFFFF7ED), shape: BoxShape.circle),
                      child: const Icon(Icons.storefront_outlined, color: Color(0xFFF97316)),
                    ),
                    title: Text(fav['restaurant_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const SizedBox(height: 4),
                      if (openBranch != null)
                        Row(children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: openBranch['is_open'] == true ? const Color(0xFFDCFCE7) : const Color(0xFFFEE2E2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              openBranch['is_open'] == true ? 'Açık' : 'Kapalı',
                              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: openBranch['is_open'] == true ? const Color(0xFF16A34A) : const Color(0xFFDC2626)),
                            ),
                          ),
                          if (openBranch['estimated_delivery_minutes'] != null) ...[
                            const SizedBox(width: 8),
                            const Icon(Icons.access_time, size: 13, color: Colors.grey),
                            const SizedBox(width: 2),
                            Text('${openBranch['estimated_delivery_minutes']} dk', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          ],
                        ]),
                    ]),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      // Favoriden çıkar
                      IconButton(
                        icon: const Icon(Icons.favorite, color: Color(0xFFE11D48)),
                        onPressed: () async {
                          await ref.read(dioProvider).post('/favorites/${fav['restaurant_id']}/toggle');
                          ref.invalidate(favoritesProvider);
                        },
                      ),
                      const Icon(Icons.chevron_right, color: Colors.grey),
                    ]),
                    onTap: openBranch != null
                        ? () => context.go('/restaurants/${openBranch['id']}/menu')
                        : null,
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
