// lib/features/menu/data/repositories/branch_list_repository.dart

import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/api/api_client.dart';

/// Şehirdeki tüm aktif şubeleri temsil eder (restoran kartı için).
class BranchListItem {
  final int id;
  final String name;
  final String restaurantName;
  final bool isOpen;
  final int estimatedDeliveryMinutes;
  final double minimumOrderAmount;
  final double avgFoodRating;
  final double avgDeliveryRating;
  final int reviewCount;
  final String? imageUrl;

  const BranchListItem({
    required this.id,
    required this.name,
    required this.restaurantName,
    required this.isOpen,
    required this.estimatedDeliveryMinutes,
    required this.minimumOrderAmount,
    required this.avgFoodRating,
    required this.avgDeliveryRating,
    required this.reviewCount,
    this.imageUrl,
  });

  double get overallRating =>
      reviewCount > 0 ? ((avgFoodRating + avgDeliveryRating) / 2) : 0;

  factory BranchListItem.fromJson(Map<String, dynamic> json) => BranchListItem(
    id: json['id'],
    name: json['name'],
    restaurantName: json['restaurant']?['name'] ?? json['name'],
    isOpen: json['is_open'] ?? false,
    estimatedDeliveryMinutes: json['estimated_delivery_minutes'] ?? 30,
    minimumOrderAmount: (json['minimum_order_amount'] ?? 0).toDouble(),
    avgFoodRating: (json['avg_food_rating'] ?? 0).toDouble(),
    avgDeliveryRating: (json['avg_delivery_rating'] ?? 0).toDouble(),
    reviewCount: json['review_count'] ?? 0,
    imageUrl: json['image_url'],
  );
}

final branchListRepositoryProvider = Provider<BranchListRepository>((ref) {
  return BranchListRepository(ref.read(dioProvider));
});

class BranchListRepository {
  final Dio _dio;
  BranchListRepository(this._dio);

  /// Şehirdeki aktif şubeleri getirir.
  /// NOT: Backend'de henüz "şehirdeki tüm şubeler" endpoint'i yoksa
  /// bu repository admin/restaurants endpoint'ini kullanır ya da
  /// yeni bir public endpoint gerekir (bkz. EKSİK_ENDPOINT.md).
  Future<List<BranchListItem>> getBranchesByCity(int cityId, {String? search}) async {
    final res = await _dio.get('/cities/$cityId/branches', queryParameters: {
      if (search != null && search.isNotEmpty) 'search': search,
    });

    final data = res.data['data'] ?? res.data;
    return (data as List).map((b) => BranchListItem.fromJson(b)).toList();
  }
}

final branchListProvider = FutureProvider.family<List<BranchListItem>, int>((ref, cityId) async {
  return ref.read(branchListRepositoryProvider).getBranchesByCity(cityId);
});

final branchSearchProvider = StateProvider<String>((ref) => '');
