// lib/features/menu/presentation/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/repositories/branch_list_repository.dart';
import '../../../auth/data/repositories/auth_repository.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final cityId = auth.user?.cityId ?? 1; // Varsayılan: Sarajevo
    final branchesAsync = ref.watch(branchListProvider(cityId));

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async => ref.invalidate(branchListProvider(cityId)),
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Teslimat Adresi', style: TextStyle(fontSize: 12, color: Colors.grey)),
                              Row(children: [
                                const Icon(Icons.location_on, color: Color(0xFFF97316), size: 16),
                                const SizedBox(width: 4),
                                Text(
                                  'Sarajevo',
                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                                ),
                                const Icon(Icons.keyboard_arrow_down, size: 18),
                              ]),
                            ],
                          ),
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.notifications_outlined),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      TextField(
                        controller: _searchCtrl,
                        onChanged: (v) => ref.read(branchSearchProvider.notifier).state = v,
                        decoration: InputDecoration(
                          hintText: 'Restoran ara...',
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE2E8F0))),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE2E8F0))),
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text('Restoranlar', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),

              branchesAsync.when(
                loading: () => const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(40),
                    child: Center(child: CircularProgressIndicator()),
                  ),
                ),
                error: (e, _) => SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(40),
                    child: Column(children: [
                      const Icon(Icons.wifi_off, size: 48, color: Colors.grey),
                      const SizedBox(height: 12),
                      const Text('Restoranlar yüklenemedi', style: TextStyle(color: Colors.grey)),
                      const SizedBox(height: 12),
                      TextButton(
                        onPressed: () => ref.invalidate(branchListProvider(cityId)),
                        child: const Text('Tekrar Dene'),
                      ),
                    ]),
                  ),
                ),
                data: (branches) {
                  final search = ref.watch(branchSearchProvider).toLowerCase();
                  final filtered = search.isEmpty
                      ? branches
                      : branches.where((b) => b.restaurantName.toLowerCase().contains(search)).toList();

                  if (filtered.isEmpty) {
                    return SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.all(40),
                        child: Column(children: [
                          const Icon(Icons.search_off, size: 48, color: Colors.grey),
                          const SizedBox(height: 12),
                          Text(
                            search.isEmpty ? 'Bu şehirde henüz restoran yok' : 'Sonuç bulunamadı',
                            style: const TextStyle(color: Colors.grey),
                          ),
                        ]),
                      ),
                    );
                  }

                  return SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (ctx, i) => _BranchCard(branch: filtered[i]),
                      childCount: filtered.length,
                    ),
                  );
                },
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 20)),
            ],
          ),
        ),
      ),
    );
  }
}

class _BranchCard extends StatelessWidget {
  final BranchListItem branch;
  const _BranchCard({required this.branch});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.go('/restaurants/${branch.id}/menu'),
      child: Opacity(
        opacity: branch.isOpen ? 1.0 : 0.6,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 130,
                decoration: const BoxDecoration(
                  color: Color(0xFFFFF7ED),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                ),
                child: Center(
                  child: Icon(Icons.storefront, size: 48, color: const Color(0xFFF97316).withOpacity(0.6)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(branch.restaurantName,
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              overflow: TextOverflow.ellipsis),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: branch.isOpen ? const Color(0xFFDCFCE7) : const Color(0xFFFEE2E2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            branch.isOpen ? 'Açık' : 'Kapalı',
                            style: TextStyle(
                              fontSize: 12, fontWeight: FontWeight.w600,
                              color: branch.isOpen ? const Color(0xFF16A34A) : const Color(0xFFDC2626),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(children: [
                      if (branch.reviewCount > 0) ...[
                        const Icon(Icons.star, color: Color(0xFFF59E0B), size: 16),
                        const SizedBox(width: 4),
                        Text(branch.overallRating.toStringAsFixed(1), style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text(' (${branch.reviewCount})', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                        const SizedBox(width: 16),
                      ],
                      const Icon(Icons.access_time, size: 16, color: Colors.grey),
                      const SizedBox(width: 4),
                      Text('${branch.estimatedDeliveryMinutes} dk', style: const TextStyle(color: Colors.grey)),
                    ]),
                    const SizedBox(height: 4),
                    Text('Min. sipariş: ${branch.minimumOrderAmount.toStringAsFixed(0)} KM',
                        style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
