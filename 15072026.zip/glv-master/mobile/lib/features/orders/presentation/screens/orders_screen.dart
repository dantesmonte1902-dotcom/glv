// lib/features/orders/presentation/screens/orders_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/repositories/order_history_repository.dart';
import '../../../../core/api/api_client.dart';

class OrdersScreen extends ConsumerStatefulWidget {
  const OrdersScreen({super.key});

  @override
  ConsumerState<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends ConsumerState<OrdersScreen> {
  final _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollCtrl.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _onScroll() {
    // Sayfanın sonuna yaklaşınca daha fazla yükle
    if (_scrollCtrl.position.pixels >= _scrollCtrl.position.maxScrollExtent - 200) {
      ref.read(orderHistoryProvider.notifier).load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(orderHistoryProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Siparişlerim')),
      body: RefreshIndicator(
        onRefresh: () => ref.read(orderHistoryProvider.notifier).refresh(),
        child: state.orders.isEmpty && state.isLoading
            ? const Center(child: CircularProgressIndicator())
            : state.orders.isEmpty && state.error != null
                ? Center(
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Icon(Icons.error_outline, size: 64, color: Colors.grey),
                      const SizedBox(height: 16),
                      Text(state.error!, style: const TextStyle(color: Colors.grey)),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => ref.read(orderHistoryProvider.notifier).refresh(),
                        child: const Text('Tekrar Dene'),
                      ),
                    ]),
                  )
                : state.orders.isEmpty
                    ? Center(
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          const Icon(Icons.receipt_long_outlined, size: 80, color: Colors.grey),
                          const SizedBox(height: 16),
                          const Text('Henüz sipariş vermediniz',
                              style: TextStyle(fontSize: 16, color: Colors.grey)),
                          const SizedBox(height: 20),
                          ElevatedButton(
                            onPressed: () => context.go('/home'),
                            child: const Text('Sipariş Ver'),
                          ),
                        ]),
                      )
                    : ListView.builder(
                        controller: _scrollCtrl,
                        padding: const EdgeInsets.all(16),
                        itemCount: state.orders.length + (state.hasMore ? 1 : 0),
                        itemBuilder: (ctx, i) {
                          if (i == state.orders.length) {
                            return const Padding(
                              padding: EdgeInsets.all(16),
                              child: Center(child: CircularProgressIndicator()),
                            );
                          }
                          return _OrderCard(order: state.orders[i]);
                        },
                      ),
      ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  final Map<String, dynamic> order;
  const _OrderCard({required this.order});

  @override
  Widget build(BuildContext context) {
    final status = order['status'] ?? '';
    final items = order['items'] as List? ?? [];
    final restaurantName = order['branch']?['restaurant']?['name'] ?? '';
    final total = order['total_amount'] ?? 0;
    final createdAt = order['created_at'] ?? '';

    return GestureDetector(
      onTap: () => context.go('/orders/${order['id']}/tracking'),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Column(children: [
          // Üst bar — restoran + durum
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: const BoxDecoration(
              color: Color(0xFFF8FAFC),
              borderRadius: BorderRadius.vertical(top: Radius.circular(14)),
            ),
            child: Row(children: [
              const Icon(Icons.storefront_outlined, size: 18, color: Color(0xFF64748B)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(restaurantName,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              ),
              _StatusBadge(status: status),
            ]),
          ),

          // Ürünler
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ...items.take(3).map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(children: [
                  Text('${item['quantity']}x ',
                      style: const TextStyle(color: Color(0xFFF97316), fontWeight: FontWeight.bold)),
                  Text(item['item_name'] ?? '',
                      style: const TextStyle(fontSize: 13, color: Color(0xFF475569))),
                ]),
              )),
              if (items.length > 3)
                Text('+${items.length - 3} ürün daha',
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
            ]),
          ),

          // Alt bar — tarih + toplam + detay
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: Color(0xFFE2E8F0))),
            ),
            child: Row(children: [
              Icon(Icons.access_time, size: 14, color: Colors.grey.shade400),
              const SizedBox(width: 4),
              Text(_formatDate(createdAt),
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade500)),
              const Spacer(),
              Text('${(total as num).toStringAsFixed(2)} KM',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16,
                      color: Color(0xFF1E293B))),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_right, color: Colors.grey),
            ]),
          ),

          if (status == 'delivered')
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: SizedBox(
                width: double.infinity,
                child: _ReorderButton(orderId: order['id'] as int),
              ),
            ),
        ]),
      ),
    );
  }

  String _formatDate(String isoDate) {
    try {
      final dt = DateTime.parse(isoDate).toLocal();
      return '${dt.day.toString().padLeft(2, '0')}.${dt.month.toString().padLeft(2, '0')}.${dt.year}  ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return isoDate;
    }
  }
}

class _ReorderButton extends ConsumerStatefulWidget {
  final int orderId;
  const _ReorderButton({required this.orderId});

  @override
  ConsumerState<_ReorderButton> createState() => _ReorderButtonState();
}

class _ReorderButtonState extends ConsumerState<_ReorderButton> {
  bool _loading = false;

  Future<void> _reorder() async {
    setState(() => _loading = true);
    try {
      final res = await ref.read(dioProvider).post('/orders/${widget.orderId}/reorder');
      final skipped = List<Map<String, dynamic>>.from(res.data['skipped'] ?? []);
      final branchIsOpen = res.data['branch_is_open'] == true;

      if (mounted) {
        if (skipped.isNotEmpty) {
          await showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('Bazı ürünler eklenemedi'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: skipped.map((s) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text('• ${s['item_name']}: ${s['reason']}', style: const TextStyle(fontSize: 13)),
                )).toList(),
              ),
              actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Tamam'))],
            ),
          );
        }

        if (!branchIsOpen) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Not: Bu restoran şu an kapalı, sipariş verirken tekrar kontrol edin.'), backgroundColor: Color(0xFFF59E0B)),
          );
        }

        context.push('/cart');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: _loading ? null : _reorder,
      icon: _loading
          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
          : const Icon(Icons.replay, size: 18, color: Color(0xFFF97316)),
      label: const Text('Yeniden Sipariş Ver', style: TextStyle(color: Color(0xFFF97316))),
      style: OutlinedButton.styleFrom(
        side: const BorderSide(color: Color(0xFFF97316)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    final (label, color, bg) = switch (status) {
      'pending_restaurant_approval' => ('Bekliyor', const Color(0xFFD97706), const Color(0xFFFEF9C3)),
      'searching_courier' => ('Hazırlanıyor', const Color(0xFF2563EB), const Color(0xFFDBEAFE)),
      'courier_assigned' => ('Kurye Atandı', const Color(0xFF7C3AED), const Color(0xFFEDE9FE)),
      'out_for_delivery' => ('Yolda', const Color(0xFF0891B2), const Color(0xFFCFFAFE)),
      'delivered' => ('Teslim Edildi', const Color(0xFF16A34A), const Color(0xFFDCFCE7)),
      'rejected' => ('Reddedildi', const Color(0xFFDC2626), const Color(0xFFFEE2E2)),
      'cancelled' => ('İptal', const Color(0xFF6B7280), const Color(0xFFF3F4F6)),
      _ => ('Bilinmiyor', const Color(0xFF6B7280), const Color(0xFFF3F4F6)),
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
    );
  }
}
