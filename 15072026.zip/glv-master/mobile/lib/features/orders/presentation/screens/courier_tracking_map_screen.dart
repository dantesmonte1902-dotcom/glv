// lib/features/orders/presentation/screens/courier_tracking_map_screen.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/services/websocket_service.dart';

/// Müşterinin kuryeyi gerçek zamanlı haritada takip ettiği ekran.
/// OrderTrackingScreen'den "Haritada Gör" ile açılır (status: out_for_delivery iken).
class CourierTrackingMapScreen extends ConsumerStatefulWidget {
  final int orderId;
  final double deliveryLat;
  final double deliveryLng;
  final String deliveryAddress;

  const CourierTrackingMapScreen({
    super.key,
    required this.orderId,
    required this.deliveryLat,
    required this.deliveryLng,
    required this.deliveryAddress,
  });

  @override
  ConsumerState<CourierTrackingMapScreen> createState() => _CourierTrackingMapScreenState();
}

class _CourierTrackingMapScreenState extends ConsumerState<CourierTrackingMapScreen> {
  GoogleMapController? _mapController;
  LatLng? _courierLocation;
  StreamSubscription? _wsSub;
  Timer? _etaTimer;
  int? _etaMinutes;

  @override
  void initState() {
    super.initState();
    _connectToCourierUpdates();
  }

  @override
  void dispose() {
    _wsSub?.cancel();
    _etaTimer?.cancel();
    _mapController?.dispose();
    super.dispose();
  }

  Future<void> _connectToCourierUpdates() async {
    final token = await const FlutterSecureStorage().read(key: AppConstants.tokenKey);
    if (token == null) return;

    final ws = ref.read(webSocketServiceProvider);
    await ws.connect(token);

    // private-orders.{id}.tracking kanalından kurye konum güncellemelerini dinle
    // (backend CourierLocationUpdated event'i bu kanala da broadcast ediyor)
    final stream = await ws.subscribePrivate('private-orders.${widget.orderId}.tracking', token);

    _wsSub = stream.listen((msg) {
      final event = msg['event'] as String? ?? '';
      if (event.contains('CourierLocationUpdated') || event.contains('courier.location')) {
        final data = msg['data'] as Map<String, dynamic>? ?? {};
        final lat = data['lat'] as double?;
        final lng = data['lng'] as double?;

        if (lat != null && lng != null && mounted) {
          setState(() => _courierLocation = LatLng(lat, lng));
          _updateCameraAndEta();
        }
      }
    });
  }

  void _updateCameraAndEta() {
    if (_courierLocation == null || _mapController == null) return;

    // Kurye ve teslimat noktasını ekranda gösterecek şekilde kamera ayarla
    final bounds = LatLngBounds(
      southwest: LatLng(
        _courierLocation!.latitude < widget.deliveryLat ? _courierLocation!.latitude : widget.deliveryLat,
        _courierLocation!.longitude < widget.deliveryLng ? _courierLocation!.longitude : widget.deliveryLng,
      ),
      northeast: LatLng(
        _courierLocation!.latitude > widget.deliveryLat ? _courierLocation!.latitude : widget.deliveryLat,
        _courierLocation!.longitude > widget.deliveryLng ? _courierLocation!.longitude : widget.deliveryLng,
      ),
    );

    _mapController!.animateCamera(CameraUpdate.newLatLngBounds(bounds, 80));

    // Basit mesafe bazlı tahmini süre (gerçek bir routing API daha doğru olur)
    final distanceMeters = _calculateDistance(
      _courierLocation!.latitude, _courierLocation!.longitude,
      widget.deliveryLat, widget.deliveryLng,
    );
    setState(() => _etaMinutes = (distanceMeters / 1000 / 0.3).ceil()); // ~18km/s ortalama hız varsayımı
  }

  double _calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const earthRadius = 6371000.0; // metre
    final dLat = _toRadians(lat2 - lat1);
    final dLon = _toRadians(lon2 - lon1);
    final a = (dLat / 2).abs() * (dLat / 2).abs() +
        _toRadians(lat1).abs() * _toRadians(lat2).abs() * (dLon / 2).abs() * (dLon / 2).abs();
    return earthRadius * 2 * a.abs();
  }

  double _toRadians(double degree) => degree * 3.1415926535 / 180;

  @override
  Widget build(BuildContext context) {
    final deliveryPoint = LatLng(widget.deliveryLat, widget.deliveryLng);

    return Scaffold(
      appBar: AppBar(title: const Text('Kurye Takibi')),
      body: Stack(children: [
        GoogleMap(
          initialCameraPosition: CameraPosition(target: deliveryPoint, zoom: 14),
          onMapCreated: (controller) => _mapController = controller,
          myLocationButtonEnabled: false,
          zoomControlsEnabled: false,
          markers: {
            Marker(
              markerId: const MarkerId('delivery'),
              position: deliveryPoint,
              icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
              infoWindow: InfoWindow(title: 'Teslimat Noktası', snippet: widget.deliveryAddress),
            ),
            if (_courierLocation != null)
              Marker(
                markerId: const MarkerId('courier'),
                position: _courierLocation!,
                icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueOrange),
                infoWindow: const InfoWindow(title: 'Kuryeniz'),
              ),
          },
        ),

        // Alt bilgi kartı
        Positioned(
          left: 16, right: 16, bottom: 16,
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 12, offset: const Offset(0, 4))],
            ),
            child: Row(children: [
              Container(
                width: 48, height: 48,
                decoration: const BoxDecoration(color: Color(0xFFFFF7ED), shape: BoxShape.circle),
                child: const Icon(Icons.delivery_dining, color: Color(0xFFF97316)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(
                    _courierLocation == null ? 'Kurye konumu bekleniyor...' : 'Kurye yolda',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                  if (_etaMinutes != null)
                    Text('Tahmini varış: ~$_etaMinutes dk', style: const TextStyle(color: Colors.grey, fontSize: 13)),
                ]),
              ),
              if (_courierLocation == null)
                const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
            ]),
          ),
        ),
      ]),
    );
  }
}
