// lib/features/orders/presentation/screens/order_tracking_screen.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/services/websocket_service.dart';
import '../../../../core/api/api_client.dart';
import '../../data/repositories/order_repository.dart';

class OrderTrackingScreen extends ConsumerStatefulWidget {
  final int orderId;
  const OrderTrackingScreen({super.key, required this.orderId});

  @override
  ConsumerState<OrderTrackingScreen> createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends ConsumerState<OrderTrackingScreen> {
  Map<String, dynamic>? _order;
  bool _loading = true;
  StreamSubscription? _wsSub;

  final _steps = [
    _Step('pending_restaurant_approval', 'Sipariş Alındı', 'Restoran onayı bekleniyor', Icons.receipt_outlined),
    _Step('searching_courier', 'Hazırlanıyor', 'Restoranınız siparişinizi hazırlıyor', Icons.restaurant_outlined),
    _Step('courier_assigned', 'Kurye Atandı', 'Kurye siparişinizi almaya gidiyor', Icons.delivery_dining_outlined),
    _Step('out_for_delivery', 'Yolda!', 'Kurye kapınıza doğru geliyor', Icons.directions_bike_outlined),
    _Step('delivered', 'Teslim Edildi', 'Afiyet olsun! 🎉', Icons.check_circle_outline),
  ];

  @override
  void initState() {
    super.initState();
    _loadOrder();
    _connectWebSocket();
  }

  @override
  void dispose() {
    _wsSub?.cancel();
    super.dispose();
  }

  Future<void> _loadOrder() async {
    try {
      final order = await ref.read(orderRepositoryProvider).getOrder(widget.orderId);
      if (mounted) setState(() { _order = order; _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _connectWebSocket() async {
    final token = await const FlutterSecureStorage().read(key: AppConstants.tokenKey);
    if (token == null) return;

    final ws = ref.read(webSocketServiceProvider);
    await ws.connect(token);
    // private-orders.{id}.tracking kanalından sipariş durumu güncellemelerini dinle
    final stream = await ws.subscribePrivate('private-orders.${widget.orderId}.tracking', token);

    _wsSub = stream.listen((msg) {
      final event = msg['event'] as String? ?? '';
      if (event.contains('OrderStatusUpdated') || event.contains('order.status')) {
        final data = msg['data'] as Map<String, dynamic>? ?? {};
        if (mounted && data['status'] != null) {
          setState(() => _order = {...?_order, 'status': data['status']});
        }
      }
    });
  }

  int _stepIndex(String? status) {
    if (status == null) return 0;
    final idx = _steps.indexWhere((s) => s.status == status);
    return idx == -1 ? 0 : idx;
  }

  Future<void> _cancelOrder() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Siparişi İptal Et'),
        content: const Text('Bu siparişi iptal etmek istediğinize emin misiniz?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Evet, İptal Et', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await ref.read(orderRepositoryProvider).cancelOrder(widget.orderId);
      if (mounted) {
        setState(() => _order = {...?_order, 'status': 'cancelled'});
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Siparişiniz iptal edildi.'), backgroundColor: Color(0xFF16A34A)),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _reorder() async {
    try {
      final res = await ref.read(dioProvider).post('/orders/${widget.orderId}/reorder');
      final skipped = List<Map<String, dynamic>>.from(res.data['skipped'] ?? []);

      if (mounted) {
        if (skipped.isNotEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('${skipped.length} ürün eklenemedi (artık mevcut değil). Sepetinizi kontrol edin.')),
          );
        }
        context.push('/cart');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'), backgroundColor: Colors.red));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final status = _order?['status'] as String? ?? 'pending_restaurant_approval';
    final currentIdx = _stepIndex(status);
    final isDelivered = status == 'delivered';
    final isOutForDelivery = status == 'out_for_delivery';
    final isRejected = status == 'rejected' || status == 'cancelled';
    final deliveryLat = (_order?['delivery_lat'] as num?)?.toDouble();
    final deliveryLng = (_order?['delivery_lng'] as num?)?.toDouble();

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: Text('Sipariş #${widget.orderId}'),
        backgroundColor: Colors.white,
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loadOrder),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                // Durum kartı
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: isDelivered
                        ? [const Color(0xFF16A34A), const Color(0xFF15803D)]
                        : isRejected
                            ? [const Color(0xFFDC2626), const Color(0xFFB91C1C)]
                            : [const Color(0xFFF97316), const Color(0xFFEA580C)]),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(children: [
                    Icon(
                      isDelivered ? Icons.check_circle : isRejected ? Icons.cancel : Icons.access_time,
                      color: Colors.white, size: 48,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      isRejected ? 'Sipariş Reddedildi' : isDelivered ? 'Teslim Edildi!' : _steps[currentIdx].title,
                      style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      isRejected ? 'Üzgünüz, bu sipariş kabul edilemedi.' : _steps[currentIdx].subtitle,
                      style: const TextStyle(color: Colors.white70, fontSize: 14),
                      textAlign: TextAlign.center,
                    ),
                  ]),
                ),

                // Haritada Gör butonu (kurye yoldayken)
                if (isOutForDelivery && deliveryLat != null && deliveryLng != null) ...[
                  const SizedBox(height: 16),
                  OutlinedButton.icon(
                    onPressed: () => context.go(
                      '/orders/${widget.orderId}/map'
                      '?lat=$deliveryLat&lng=$deliveryLng&address=${Uri.encodeComponent(_order?['delivery_address'] ?? '')}',
                    ),
                    icon: const Icon(Icons.map_outlined, color: Color(0xFFF97316)),
                    label: const Text('Haritada Takip Et', style: TextStyle(color: Color(0xFFF97316))),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFFF97316)),
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ],

                // İptal butonu (yalnızca onay/kurye arama aşamasında)
                if (status == 'pending_restaurant_approval' || status == 'searching_courier') ...[
                  const SizedBox(height: 16),
                  OutlinedButton.icon(
                    onPressed: _cancelOrder,
                    icon: const Icon(Icons.close, color: Colors.red),
                    label: const Text('Siparişi İptal Et', style: TextStyle(color: Colors.red)),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Colors.red),
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ],

                const SizedBox(height: 24),

                if (!isRejected) ...[
                  const Text('Sipariş Adımları', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                  const SizedBox(height: 16),

                  ...List.generate(_steps.length, (i) {
                    final step = _steps[i];
                    final isDone = i <= currentIdx;
                    final isActive = i == currentIdx;

                    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Column(children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 400),
                          width: 42, height: 42,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isDone
                                ? (isActive ? const Color(0xFFF97316) : const Color(0xFF16A34A))
                                : const Color(0xFFE2E8F0),
                            boxShadow: isActive ? [BoxShadow(color: const Color(0xFFF97316).withOpacity(0.4), blurRadius: 8, spreadRadius: 2)] : null,
                          ),
                          child: Icon(isDone && !isActive ? Icons.check : step.icon, color: isDone ? Colors.white : const Color(0xFF94A3B8), size: 20),
                        ),
                        if (i < _steps.length - 1)
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 400),
                            width: 2, height: 36,
                            color: i < currentIdx ? const Color(0xFF16A34A) : const Color(0xFFE2E8F0),
                          ),
                      ]),
                      const SizedBox(width: 16),
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(step.title, style: TextStyle(fontSize: 15, fontWeight: isActive ? FontWeight.bold : FontWeight.normal, color: isDone ? const Color(0xFF1E293B) : const Color(0xFF94A3B8))),
                          if (isActive) Text(step.subtitle, style: const TextStyle(fontSize: 12, color: Color(0xFFF97316))),
                        ]),
                      ),
                    ]);
                  }),
                ],

                const SizedBox(height: 24),

                // Sipariş özeti
                if (_order != null) _OrderSummaryCard(order: _order!),

                const SizedBox(height: 24),

                // Değerlendirme butonu
                if (isDelivered) ...[
                  ElevatedButton.icon(
                    onPressed: () => context.go('/orders/${widget.orderId}/review'),
                    icon: const Icon(Icons.star_outline),
                    label: const Text('Değerlendir'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF59E0B),
                      minimumSize: const Size.fromHeight(48),
                    ),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () => context.push('/orders/${widget.orderId}/dispute'),
                    icon: const Icon(Icons.report_problem_outlined, color: Color(0xFFDC2626)),
                    label: const Text('Sorun Bildir / İtiraz Et', style: TextStyle(color: Color(0xFFDC2626))),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFFDC2626)),
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _reorder,
                    icon: const Icon(Icons.replay, color: Color(0xFFF97316)),
                    label: const Text('Yeniden Sipariş Ver', style: TextStyle(color: Color(0xFFF97316))),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFFF97316)),
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],

                OutlinedButton.icon(
                  onPressed: () => context.go('/home'),
                  icon: const Icon(Icons.home_outlined),
                  label: const Text('Ana Sayfaya Dön'),
                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                ),
              ]),
            ),
    );
  }
}

class _Step {
  final String status, title, subtitle;
  final IconData icon;
  const _Step(this.status, this.title, this.subtitle, this.icon);
}

class _OrderSummaryCard extends StatelessWidget {
  final Map<String, dynamic> order;
  const _OrderSummaryCard({required this.order});

  @override
  Widget build(BuildContext context) {
    final items = order['items'] as List? ?? [];
    final restaurantName = order['branch']?['restaurant']?['name'] ?? '';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE2E8F0))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.storefront_outlined, size: 18, color: Color(0xFF64748B)),
          const SizedBox(width: 8),
          Text(restaurantName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        ]),
        const SizedBox(height: 12),
        const Divider(height: 1),
        const SizedBox(height: 12),
        ...items.map((item) => Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('${item['quantity']}x ${item['item_name']}', style: const TextStyle(fontSize: 13)),
            Text('${(item['line_total'] as num).toStringAsFixed(2)} KM', style: const TextStyle(fontSize: 13, color: Color(0xFF64748B))),
          ]),
        )),
        const SizedBox(height: 8),
        const Divider(height: 1),
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Toplam', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          Text('${(order['total_amount'] as num).toStringAsFixed(2)} KM',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFFF97316))),
        ]),
      ]),
    );
  }
}
