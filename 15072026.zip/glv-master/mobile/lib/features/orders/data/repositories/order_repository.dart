// lib/features/orders/data/repositories/order_repository.dart

import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/api/api_client.dart';

final orderRepositoryProvider = Provider<OrderRepository>((ref) {
  return OrderRepository(ref.read(dioProvider));
});

class OrderRepository {
  final Dio _dio;
  OrderRepository(this._dio);

  Future<Map<String, dynamic>> placeOrder({
    required int cityId,
    required int branchId,
    required List items,
    required String deliveryAddress,
    required String paymentMethod,
    String? couponCode,
    double? deliveryLat,
    double? deliveryLng,
    int redeemPoints = 0,
  }) async {
    final res = await _dio.post('/orders', data: {
      'city_id': cityId,
      'branch_id': branchId,
      'domain_type': 'food',
      'payment_method': paymentMethod,
      'delivery_address': deliveryAddress,
      if (deliveryLat != null) 'delivery_lat': deliveryLat,
      if (deliveryLng != null) 'delivery_lng': deliveryLng,
      if (couponCode != null) 'coupon_code': couponCode,
      if (redeemPoints > 0) 'redeem_points': redeemPoints,
      'items': items.map((i) => {
        'product_id': i['product_id'],
        'quantity': i['quantity'],
        'selected_options': (i['selected_options'] as List? ?? []).map((o) => o['option_id']).toList(),
      }).toList(),
    });
    return res.data;
  }

  Future<Map<String, dynamic>> getOrder(int orderId) async {
    final res = await _dio.get('/orders/$orderId');
    return res.data;
  }

  Future<Map<String, dynamic>> cancelOrder(int orderId, {String? reason}) async {
    final res = await _dio.post('/orders/$orderId/cancel', data: {
      if (reason != null) 'reason': reason,
    });
    return res.data;
  }
}

final orderProvider = FutureProvider.family<Map<String, dynamic>, int>((ref, orderId) async {
  return ref.read(orderRepositoryProvider).getOrder(orderId);
});
