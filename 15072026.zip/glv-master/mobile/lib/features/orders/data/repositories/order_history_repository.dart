// lib/features/orders/data/repositories/order_history_repository.dart

import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/api/api_client.dart';

final orderHistoryProvider = StateNotifierProvider<OrderHistoryNotifier, OrderHistoryState>((ref) {
  return OrderHistoryNotifier(ref.read(dioProvider));
});

class OrderHistoryState {
  final List<Map<String, dynamic>> orders;
  final bool isLoading;
  final bool hasMore;
  final int currentPage;
  final String? error;

  const OrderHistoryState({
    this.orders = const [],
    this.isLoading = false,
    this.hasMore = true,
    this.currentPage = 1,
    this.error,
  });

  OrderHistoryState copyWith({
    List<Map<String, dynamic>>? orders,
    bool? isLoading,
    bool? hasMore,
    int? currentPage,
    String? error,
  }) => OrderHistoryState(
    orders: orders ?? this.orders,
    isLoading: isLoading ?? this.isLoading,
    hasMore: hasMore ?? this.hasMore,
    currentPage: currentPage ?? this.currentPage,
    error: error,
  );
}

class OrderHistoryNotifier extends StateNotifier<OrderHistoryState> {
  final Dio _dio;
  OrderHistoryNotifier(this._dio) : super(const OrderHistoryState()) {
    load();
  }

  Future<void> load({bool refresh = false}) async {
    if (state.isLoading) return;
    if (!state.hasMore && !refresh) return;

    final page = refresh ? 1 : state.currentPage;
    state = state.copyWith(isLoading: true, error: null);

    try {
      final res = await _dio.get('/orders', queryParameters: {'page': page, 'per_page': 10});
      final newOrders = List<Map<String, dynamic>>.from(res.data['data']);
      final meta = res.data['meta'];
      final lastPage = meta['last_page'] as int;

      state = state.copyWith(
        orders: refresh ? newOrders : [...state.orders, ...newOrders],
        isLoading: false,
        hasMore: page < lastPage,
        currentPage: page + 1,
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<void> refresh() => load(refresh: true);
}
