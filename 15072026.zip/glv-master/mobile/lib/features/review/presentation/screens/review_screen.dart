// lib/features/review/presentation/screens/review_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/api/api_client.dart';

class ReviewScreen extends ConsumerStatefulWidget {
  final int orderId;
  const ReviewScreen({super.key, required this.orderId});

  @override
  ConsumerState<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends ConsumerState<ReviewScreen> {
  int _foodRating = 0;
  int _deliveryRating = 0;
  final _commentCtrl = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _commentCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_foodRating == 0 || _deliveryRating == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lütfen tüm puanları verin.'), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() => _saving = true);
    try {
      await ref.read(dioProvider).post('/orders/${widget.orderId}/review', data: {
        'food_rating': _foodRating,
        'delivery_rating': _deliveryRating,
        if (_commentCtrl.text.trim().isNotEmpty) 'comment': _commentCtrl.text.trim(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Değerlendirmeniz için teşekkürler! 🌟'), backgroundColor: Color(0xFF16A34A)),
        );
        context.go('/orders');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Siparişi Değerlendir')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Yemek Kalitesi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          const SizedBox(height: 8),
          _StarRating(rating: _foodRating, onChanged: (v) => setState(() => _foodRating = v)),
          const SizedBox(height: 24),
          const Text('Teslimat Hızı', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          const SizedBox(height: 8),
          _StarRating(rating: _deliveryRating, onChanged: (v) => setState(() => _deliveryRating = v)),
          const SizedBox(height: 24),
          const Text('Yorumunuz (opsiyonel)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          const SizedBox(height: 8),
          TextField(
            controller: _commentCtrl,
            maxLines: 4,
            maxLength: 1000,
            decoration: const InputDecoration(hintText: 'Deneyiminizi paylaşın...'),
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: _saving ? null : _submit,
            child: _saving
                ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Text('Değerlendirmeyi Gönder'),
          ),
        ]),
      ),
    );
  }
}

class _StarRating extends StatelessWidget {
  final int rating;
  final ValueChanged<int> onChanged;
  const _StarRating({required this.rating, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(5, (i) => GestureDetector(
        onTap: () => onChanged(i + 1),
        child: Padding(
          padding: const EdgeInsets.only(right: 8),
          child: Icon(
            i < rating ? Icons.star : Icons.star_border,
            color: const Color(0xFFF59E0B),
            size: 36,
          ),
        ),
      )),
    );
  }
}
