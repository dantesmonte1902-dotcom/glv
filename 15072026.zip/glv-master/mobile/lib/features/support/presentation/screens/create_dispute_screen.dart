// lib/features/support/presentation/screens/create_dispute_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/api/api_client.dart';

class CreateDisputeScreen extends ConsumerStatefulWidget {
  final int orderId;
  const CreateDisputeScreen({super.key, required this.orderId});

  @override
  ConsumerState<CreateDisputeScreen> createState() => _CreateDisputeScreenState();
}

class _CreateDisputeScreenState extends ConsumerState<CreateDisputeScreen> {
  final _descriptionCtrl = TextEditingController();
  String _type = 'missing_item';
  bool _submitting = false;

  final _types = const [
    ('missing_item', 'Eksik Ürün', Icons.remove_shopping_cart_outlined),
    ('wrong_item', 'Yanlış Ürün', Icons.swap_horiz),
    ('quality_issue', 'Kalite Sorunu', Icons.thumb_down_outlined),
    ('never_arrived', 'Sipariş Hiç Gelmedi', Icons.location_off_outlined),
    ('other', 'Diğer', Icons.more_horiz),
  ];

  Future<void> _submit() async {
    if (_descriptionCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lütfen sorunu kısaca açıklayın.')),
      );
      return;
    }

    setState(() => _submitting = true);
    try {
      await ref.read(dioProvider).post('/orders/${widget.orderId}/disputes', data: {
        'type': _type,
        'description': _descriptionCtrl.text.trim(),
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('İtirazınız alındı. En kısa sürede dönüş yapacağız.'), backgroundColor: Color(0xFF16A34A)),
        );
        context.pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  void dispose() {
    _descriptionCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sorun Bildir')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Ne oldu?', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 12),

          Wrap(
            spacing: 8, runSpacing: 8,
            children: _types.map((t) {
              final selected = t.$1 == _type;
              return ChoiceChip(
                label: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(t.$3, size: 16, color: selected ? Colors.white : const Color(0xFF475569)),
                  const SizedBox(width: 6),
                  Text(t.$2),
                ]),
                selected: selected,
                onSelected: (_) => setState(() => _type = t.$1),
                selectedColor: const Color(0xFFDC2626),
                labelStyle: TextStyle(color: selected ? Colors.white : const Color(0xFF1E293B)),
                backgroundColor: Colors.white,
                side: BorderSide(color: selected ? const Color(0xFFDC2626) : const Color(0xFFE2E8F0)),
              );
            }).toList(),
          ),

          const SizedBox(height: 24),
          const Text('Detay', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          TextField(
            controller: _descriptionCtrl,
            maxLines: 5,
            decoration: const InputDecoration(
              hintText: 'Lütfen yaşadığınız sorunu detaylıca anlatın...',
              border: OutlineInputBorder(),
            ),
          ),

          const SizedBox(height: 8),
          Text(
            'İtirazlar teslimattan sonra en fazla 72 saat içinde açılabilir. Ekibimiz talebinizi inceleyip size dönüş yapacaktır.',
            style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
          ),

          const SizedBox(height: 28),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _submitting ? null : _submit,
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFDC2626), minimumSize: const Size.fromHeight(50)),
              child: _submitting
                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('İtirazı Gönder'),
            ),
          ),
        ]),
      ),
    );
  }
}
