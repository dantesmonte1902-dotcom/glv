// lib/features/support/presentation/screens/support_ticket_thread_screen.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../../../../core/api/api_client.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/services/websocket_service.dart';

class SupportTicketThreadScreen extends ConsumerStatefulWidget {
  final int ticketId;
  const SupportTicketThreadScreen({super.key, required this.ticketId});

  @override
  ConsumerState<SupportTicketThreadScreen> createState() => _SupportTicketThreadScreenState();
}

class _SupportTicketThreadScreenState extends ConsumerState<SupportTicketThreadScreen> {
  Map<String, dynamic>? _ticket;
  List<Map<String, dynamic>> _messages = [];
  bool _loading = true;
  bool _sending = false;
  final _messageCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  StreamSubscription? _wsSub;

  @override
  void initState() {
    super.initState();
    _load();
    _connectWebSocket();
  }

  @override
  void dispose() {
    _wsSub?.cancel();
    _messageCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final res = await ref.read(dioProvider).get('/support/tickets/${widget.ticketId}');
      setState(() {
        _ticket = res.data;
        _messages = List<Map<String, dynamic>>.from(res.data['messages'] ?? []);
        _loading = false;
      });
      _scrollToBottom();
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _connectWebSocket() async {
    final token = await const FlutterSecureStorage().read(key: AppConstants.tokenKey);
    if (token == null) return;

    final ws = ref.read(webSocketServiceProvider);
    await ws.connect(token);
    final stream = await ws.subscribePrivate('private-support-tickets.${widget.ticketId}', token);

    _wsSub = stream.listen((msg) {
      final event = msg['event'] as String? ?? '';
      if (event.contains('support.message') || event.contains('SupportMessageSent')) {
        final data = msg['data'] as Map<String, dynamic>? ?? {};
        final incoming = data['message'] as Map<String, dynamic>?;
        if (incoming != null && mounted) {
          setState(() => _messages = [..._messages, incoming]);
          _scrollToBottom();
        }
      }
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(_scrollCtrl.position.maxScrollExtent, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _send() async {
    final text = _messageCtrl.text.trim();
    if (text.isEmpty) return;

    setState(() => _sending = true);
    _messageCtrl.clear();
    try {
      await ref.read(dioProvider).post('/support/tickets/${widget.ticketId}/messages', data: {'message': text});
      // WebSocket kendi mesajımızı da geri yayınlar; yine de anlık his için burada eklemiyoruz,
      // event geldiğinde listeye eklenecek. Eğer WS bağlantısı yoksa fallback olarak yeniden yükle.
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'), backgroundColor: Colors.red));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isClosed = _ticket?['status'] == 'closed';

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: Text(_ticket?['subject']?.toString() ?? 'Destek Talebi'),
        backgroundColor: Colors.white,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              Expanded(
                child: ListView.builder(
                  controller: _scrollCtrl,
                  padding: const EdgeInsets.all(16),
                  itemCount: _messages.length,
                  itemBuilder: (context, i) => _MessageBubble(message: _messages[i]),
                ),
              ),
              if (isClosed)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  color: const Color(0xFFF1F5F9),
                  child: const Text('Bu destek talebi kapatıldı.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
                )
              else
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(children: [
                      Expanded(
                        child: TextField(
                          controller: _messageCtrl,
                          decoration: InputDecoration(
                            hintText: 'Mesajınızı yazın...',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          ),
                          onSubmitted: (_) => _send(),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        onPressed: _sending ? null : _send,
                        icon: _sending
                            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Icon(Icons.send, color: Color(0xFFF97316)),
                      ),
                    ]),
                  ),
                ),
            ]),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final Map<String, dynamic> message;
  const _MessageBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final isStaff = message['is_staff'] == true;

    return Align(
      alignment: isStaff ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: isStaff ? Colors.white : const Color(0xFFF97316),
          borderRadius: BorderRadius.circular(14),
          border: isStaff ? Border.all(color: const Color(0xFFE2E8F0)) : null,
        ),
        child: Text(
          message['message']?.toString() ?? '',
          style: TextStyle(color: isStaff ? const Color(0xFF1E293B) : Colors.white),
        ),
      ),
    );
  }
}
