// lib/features/support/presentation/screens/support_tickets_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/api/api_client.dart';

final supportTicketsProvider = FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  final res = await ref.read(dioProvider).get('/support/tickets');
  final data = res.data['data'] ?? res.data;
  return List<Map<String, dynamic>>.from(data);
});

class SupportTicketsScreen extends ConsumerWidget {
  const SupportTicketsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ticketsAsync = ref.watch(supportTicketsProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(title: const Text('Yardım & Destek'), backgroundColor: Colors.white),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await context.push('/support/new');
          ref.invalidate(supportTicketsProvider);
        },
        backgroundColor: const Color(0xFFF97316),
        icon: const Icon(Icons.add),
        label: const Text('Yeni Talep'),
      ),
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(supportTicketsProvider),
        child: ticketsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('Yüklenemedi: $e')),
          data: (tickets) {
            if (tickets.isEmpty) {
              return ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  const SizedBox(height: 60),
                  Icon(Icons.support_agent_outlined, size: 72, color: Colors.grey.shade300),
                  const SizedBox(height: 16),
                  const Center(child: Text('Henüz destek talebiniz yok', style: TextStyle(color: Colors.grey, fontSize: 15))),
                  const SizedBox(height: 4),
                  const Center(child: Text('Bir sorun mu yaşıyorsunuz? Bize ulaşın.', style: TextStyle(color: Colors.grey, fontSize: 13))),
                ],
              );
            }

            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: tickets.length,
              itemBuilder: (context, i) => _TicketTile(ticket: tickets[i]),
            );
          },
        ),
      ),
    );
  }
}

class _TicketTile extends StatelessWidget {
  final Map<String, dynamic> ticket;
  const _TicketTile({required this.ticket});

  @override
  Widget build(BuildContext context) {
    final status = ticket['status']?.toString() ?? 'open';
    final subject = ticket['subject']?.toString() ?? '';
    final statusLabel = switch (status) {
      'open' => 'Açık',
      'in_progress' => 'Yanıtlandı',
      'closed' => 'Kapalı',
      _ => status,
    };
    final statusColor = switch (status) {
      'open' => const Color(0xFFDC2626),
      'in_progress' => const Color(0xFF2563EB),
      _ => Colors.grey,
    };

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        leading: Container(
          width: 40, height: 40,
          decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(10)),
          child: const Icon(Icons.chat_bubble_outline, color: Color(0xFFF97316)),
        ),
        title: Text(subject, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(statusLabel, style: TextStyle(color: statusColor, fontSize: 12, fontWeight: FontWeight.w600)),
        trailing: const Icon(Icons.chevron_right, color: Colors.grey),
        onTap: () => context.push('/support/${ticket['id']}'),
      ),
    );
  }
}
