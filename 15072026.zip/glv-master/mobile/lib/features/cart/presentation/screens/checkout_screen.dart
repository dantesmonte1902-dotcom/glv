// lib/features/cart/presentation/screens/checkout_screen.dart
// Adres defterinden seçim desteği eklendi

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/repositories/cart_repository.dart';
import '../../../orders/data/repositories/order_repository.dart';
import '../../../address/data/models/address_model.dart';
import '../../../address/data/repositories/address_repository.dart';
import '../../../address/presentation/screens/address_list_screen.dart';
import '../../../loyalty/presentation/screens/loyalty_screen.dart' show loyaltySummaryProvider;

class CheckoutScreen extends ConsumerStatefulWidget {
  const CheckoutScreen({super.key});

  @override
  ConsumerState<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends ConsumerState<CheckoutScreen> {
  final _manualAddressCtrl = TextEditingController();
  final _couponCtrl = TextEditingController();
  String _paymentMethod = 'cash_on_delivery';
  Map<String, dynamic>? _summary;
  bool _loadingSummary = false;
  bool _placingOrder = false;
  CustomerAddress? _selectedAddress; // Adres defterinden seçilen
  bool _usePoints = false;

  String get _deliveryAddress =>
      _selectedAddress?.fullAddress ?? _manualAddressCtrl.text.trim();

  Future<void> _pickAddress() async {
    final picked = await Navigator.push<CustomerAddress>(
      context,
      MaterialPageRoute(
        builder: (_) => const AddressListScreen(selectionMode: true),
      ),
    );
    if (picked != null) {
      setState(() {
        _selectedAddress = picked;
        _manualAddressCtrl.text = picked.fullAddress;
      });
      if (_summary != null) _loadSummary();
    }
  }

  Future<void> _loadSummary() async {
    setState(() => _loadingSummary = true);
    try {
      final availablePoints = ref.read(loyaltySummaryProvider).valueOrNull?['points_balance'] as int? ?? 0;

      final s = await ref.read(cartRepositoryProvider).checkoutSummary(
        couponCode: _couponCtrl.text.isEmpty ? null : _couponCtrl.text,
        deliveryLat: _selectedAddress?.lat,
        deliveryLng: _selectedAddress?.lng,
        redeemPoints: _usePoints ? availablePoints : 0,
      );
      setState(() => _summary = s);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      setState(() => _loadingSummary = false);
    }
  }

  Future<void> _placeOrder() async {
    if (_deliveryAddress.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lütfen teslimat adresini seçin veya girin.')),
      );
      return;
    }

    if (_summary == null) {
      await _loadSummary();
      return;
    }

    setState(() => _placingOrder = true);
    try {
      final cart = await ref.read(cartRepositoryProvider).getCart();
      final pointsUsed = (_summary?['loyalty']?['points_used'] as num?)?.toInt() ?? 0;
      final order = await ref.read(orderRepositoryProvider).placeOrder(
        cityId: 1,
        branchId: cart['branch_id'],
        items: cart['items'],
        deliveryAddress: _deliveryAddress,
        paymentMethod: _paymentMethod,
        couponCode: _couponCtrl.text.isEmpty ? null : _couponCtrl.text,
        deliveryLat: _selectedAddress?.lat,
        deliveryLng: _selectedAddress?.lng,
        redeemPoints: pointsUsed,
      );
      if (mounted) context.go('/orders/${order['id']}/tracking');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      setState(() => _placingOrder = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final addressAsync = ref.watch(addressProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Sipariş Özeti')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          // ─── Teslimat Adresi ────────────────────────────────────────────
          const Text('Teslimat Adresi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 10),

          // Adres defterinden seçme butonu
          addressAsync.when(
            loading: () => const SizedBox.shrink(),
            error: (_, __) => const SizedBox.shrink(),
            data: (addresses) => addresses.isEmpty
                ? const SizedBox.shrink()
                : OutlinedButton.icon(
                    onPressed: _pickAddress,
                    icon: const Icon(Icons.location_on_outlined, color: Color(0xFFF97316)),
                    label: Text(
                      _selectedAddress != null
                          ? _selectedAddress!.title
                          : 'Kayıtlı adreslerimden seç',
                      style: const TextStyle(color: Color(0xFFF97316)),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFFF97316)),
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
          ),

          if (_selectedAddress != null) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF7ED),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFF97316)),
              ),
              child: Row(children: [
                const Icon(Icons.check_circle, color: Color(0xFFF97316), size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(_selectedAddress!.title,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    Text(_selectedAddress!.fullAddress,
                        style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ]),
                ),
                TextButton(
                  onPressed: () => setState(() => _selectedAddress = null),
                  child: const Text('Değiştir', style: TextStyle(fontSize: 12)),
                ),
              ]),
            ),
          ] else ...[
            const SizedBox(height: 8),
            TextField(
              controller: _manualAddressCtrl,
              maxLines: 2,
              decoration: const InputDecoration(
                hintText: 'veya adresinizi buraya yazın...',
                prefixIcon: Icon(Icons.edit_location_alt_outlined),
              ),
            ),
          ],

          const SizedBox(height: 24),

          // ─── Ödeme Yöntemi ───────────────────────────────────────────────
          const Text('Ödeme Yöntemi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          _PaymentOption(
            value: 'cash_on_delivery',
            groupValue: _paymentMethod,
            label: 'Kapıda Ödeme',
            icon: Icons.payments_outlined,
            onChanged: (v) => setState(() => _paymentMethod = v!),
          ),
          _PaymentOption(
            value: 'card',
            groupValue: _paymentMethod,
            label: 'Kredi / Banka Kartı',
            icon: Icons.credit_card_outlined,
            onChanged: (v) => setState(() => _paymentMethod = v!),
          ),
          const SizedBox(height: 24),

          // ─── Sadakat Puanı ──────────────────────────────────────────────
          Consumer(builder: (context, ref, _) {
            final loyaltyAsync = ref.watch(loyaltySummaryProvider);
            final balance = loyaltyAsync.valueOrNull?['points_balance'] as int? ?? 0;

            if (balance <= 0) return const SizedBox.shrink();

            return Container(
              padding: const EdgeInsets.all(14),
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF7ED),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFFED7AA)),
              ),
              child: Row(children: [
                const Icon(Icons.stars_rounded, color: Color(0xFFF97316), size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '$balance puanınız var (≈${(balance / 100).toStringAsFixed(2)} KM)',
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                  ),
                ),
                Switch(
                  value: _usePoints,
                  activeColor: const Color(0xFFF97316),
                  onChanged: (v) {
                    setState(() => _usePoints = v);
                    _loadSummary();
                  },
                ),
              ]),
            );
          }),

          // ─── Kupon ──────────────────────────────────────────────────────
          const Text('Kupon', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _couponCtrl,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(hintText: 'Kupon kodunuz'),
              ),
            ),
            const SizedBox(width: 12),
            ElevatedButton(onPressed: _loadSummary, child: const Text('Uygula')),
          ]),

          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 12),

          // ─── Fiyat özeti ─────────────────────────────────────────────────
          if (_loadingSummary)
            const Center(child: CircularProgressIndicator())
          else if (_summary != null) ...[
            _SummaryRow('Ara Toplam', '${(_summary!['subtotal'] as num).toStringAsFixed(2)} KM'),
            _SummaryRow('Teslimat Ücreti', '${(_summary!['delivery_fee'] as num).toStringAsFixed(2)} KM'),
            _SummaryRow('Servis Ücreti', '${(_summary!['service_fee'] as num).toStringAsFixed(2)} KM'),
            Builder(builder: (context) {
              final totalDiscount = (_summary!['discount_amount'] as num?)?.toDouble() ?? 0;
              final pointsDiscount = (_summary!['loyalty']?['points_discount'] as num?)?.toDouble() ?? 0;
              final couponDiscount = totalDiscount - pointsDiscount; // 'discount_amount' ikisinin toplamı

              return Column(children: [
                if (couponDiscount > 0)
                  _SummaryRow('Kupon İndirimi', '-${couponDiscount.toStringAsFixed(2)} KM', isDiscount: true),
                if (pointsDiscount > 0)
                  _SummaryRow(
                    '${_summary!['loyalty']['points_used']} puan kullanıldı',
                    '-${pointsDiscount.toStringAsFixed(2)} KM',
                    isDiscount: true,
                  ),
              ]);
            }),
            const Divider(),
            _SummaryRow('Toplam', '${(_summary!['total'] as num).toStringAsFixed(2)} KM', isBold: true),
          ] else
            TextButton.icon(
              onPressed: _loadSummary,
              icon: const Icon(Icons.calculate_outlined),
              label: const Text('Fiyat özetini hesapla'),
            ),

          const SizedBox(height: 32),
        ]),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: ElevatedButton(
          onPressed: _placingOrder ? null : _placeOrder,
          child: _placingOrder
              ? const SizedBox(height: 20, width: 20,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : Text(_summary != null
                  ? 'Sipariş Ver — ${(_summary!['total'] as num).toStringAsFixed(2)} KM'
                  : 'Sipariş Ver'),
        ),
      ),
    );
  }
}

class _PaymentOption extends StatelessWidget {
  final String value, groupValue, label;
  final IconData icon;
  final ValueChanged<String?> onChanged;
  const _PaymentOption({required this.value, required this.groupValue, required this.label, required this.icon, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final selected = value == groupValue;
    return GestureDetector(
      onTap: () => onChanged(value),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF7ED) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? const Color(0xFFF97316) : const Color(0xFFE2E8F0), width: selected ? 2 : 1),
        ),
        child: Row(children: [
          Radio<String>(value: value, groupValue: groupValue, onChanged: onChanged, activeColor: const Color(0xFFF97316)),
          Icon(icon, color: selected ? const Color(0xFFF97316) : Colors.grey),
          const SizedBox(width: 12),
          Text(label, style: TextStyle(fontWeight: selected ? FontWeight.w600 : FontWeight.normal)),
        ]),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label, value;
  final bool isBold, isDiscount;
  const _SummaryRow(this.label, this.value, {this.isBold = false, this.isDiscount = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: TextStyle(fontSize: isBold ? 16 : 14, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
        Text(value, style: TextStyle(fontSize: isBold ? 16 : 14, fontWeight: isBold ? FontWeight.bold : FontWeight.normal, color: isDiscount ? const Color(0xFF16A34A) : null)),
      ]),
    );
  }
}
