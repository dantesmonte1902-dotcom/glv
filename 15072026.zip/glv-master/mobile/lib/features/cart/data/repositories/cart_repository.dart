// lib/features/cart/data/repositories/cart_repository.dart

import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/api/api_client.dart';

final cartRepositoryProvider = Provider<CartRepository>((ref) {
  return CartRepository(ref.read(dioProvider));
});

class CartRepository {
  final Dio _dio;
  CartRepository(this._dio);

  Future<Map<String, dynamic>> getCart() async {
    final res = await _dio.get('/cart');
    return res.data;
  }

  Future<Map<String, dynamic>> addItem({
    required int branchId,
    required int productId,
    required int quantity,
    required List<int> selectedOptions,
  }) async {
    final res = await _dio.post('/cart/items', data: {
      'branch_id': branchId,
      'product_id': productId,
      'quantity': quantity,
      'selected_options': selectedOptions,
    });
    return res.data;
  }

  Future<Map<String, dynamic>> updateItem(String itemKey, int quantity) async {
    final res = await _dio.patch('/cart/items/$itemKey', data: {'quantity': quantity});
    return res.data;
  }

  Future<Map<String, dynamic>> removeItem(String itemKey) async {
    final res = await _dio.delete('/cart/items/$itemKey');
    return res.data;
  }

  Future<void> clearCart() async {
    await _dio.delete('/cart');
  }

  Future<Map<String, dynamic>> checkoutSummary({
    String? couponCode,
    String domainType = 'food',
    double? deliveryLat,
    double? deliveryLng,
    int redeemPoints = 0,
  }) async {
    final res = await _dio.post('/cart/checkout-summary', data: {
      if (couponCode != null) 'coupon_code': couponCode,
      'domain_type': domainType,
      if (deliveryLat != null) 'delivery_lat': deliveryLat,
      if (deliveryLng != null) 'delivery_lng': deliveryLng,
      if (redeemPoints > 0) 'redeem_points': redeemPoints,
    });
    return res.data;
  }
}

final cartProvider = FutureProvider<Map<String, dynamic>>((ref) async {
  return ref.read(cartRepositoryProvider).getCart();
});
