// lib/features/loyalty/presentation/screens/loyalty_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';
import '../../../../core/api/api_client.dart';

final loyaltySummaryProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  final res = await ref.read(dioProvider).get('/loyalty/summary');
  return Map<String, dynamic>.from(res.data);
});

final loyaltyHistoryProvider = FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  final res = await ref.read(dioProvider).get('/loyalty/history');
  final data = res.data['data'] ?? res.data;
  return List<Map<String, dynamic>>.from(data);
});

class LoyaltyScreen extends ConsumerWidget {
  const LoyaltyScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final summaryAsync = ref.watch(loyaltySummaryProvider);
    final historyAsync = ref.watch(loyaltyHistoryProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(title: const Text('Sadakat & Referans'), backgroundColor: Colors.white),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(loyaltySummaryProvider);
          ref.invalidate(loyaltyHistoryProvider);
        },
        child: summaryAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('Yüklenemedi: $e')),
          data: (summary) {
            final balance = summary['points_balance'] ?? 0;
            final referral = Map<String, dynamic>.from(summary['referral'] ?? {});
            final referralCode = referral['referral_code']?.toString() ?? '';
            final totalInvited = referral['total_invited'] ?? 0;
            final completedFirstOrder = referral['completed_first_order'] ?? 0;

            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // Puan bakiye kartı
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFFF97316), Color(0xFFEA580C)]),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Row(children: [
                      Icon(Icons.stars_rounded, color: Colors.white, size: 22),
                      SizedBox(width: 8),
                      Text('Sadakat Puanınız', style: TextStyle(color: Colors.white70, fontSize: 13)),
                    ]),
                    const SizedBox(height: 8),
                    Text('$balance puan', style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(
                      '≈ ${(balance / 100).toStringAsFixed(2)} KM indirim değerinde',
                      style: const TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                  ]),
                ),

                const SizedBox(height: 20),
                const Text('Arkadaşını Davet Et', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                const Text(
                  'Davet ettiğin arkadaşın ilk siparişini tamamladığında sen 500, o 200 puan kazanır.',
                  style: TextStyle(color: Colors.grey, fontSize: 13),
                ),
                const SizedBox(height: 12),

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                  ),
                  child: Column(children: [
                    Row(children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF8FAFC),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: const Color(0xFFE2E8F0), style: BorderStyle.solid),
                          ),
                          child: Text(
                            referralCode.isEmpty ? '—' : referralCode,
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 2),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      IconButton(
                        onPressed: referralCode.isEmpty ? null : () {
                          Clipboard.setData(ClipboardData(text: referralCode));
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Referans kodu kopyalandı.')),
                          );
                        },
                        icon: const Icon(Icons.copy_outlined),
                        style: IconButton.styleFrom(backgroundColor: const Color(0xFFF8FAFC)),
                      ),
                    ]),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF97316), foregroundColor: Colors.white),
                        icon: const Icon(Icons.share_outlined, size: 18),
                        label: const Text('Davet Kodunu Paylaş'),
                        onPressed: referralCode.isEmpty ? null : () {
                          Share.share(
                            'GLV\'ye katıl, ilk siparişinde bonus kazan! Davet kodum: $referralCode',
                          );
                        },
                      ),
                    ),
                  ]),
                ),

                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: _MiniStat(label: 'Davet Edilen', value: '$totalInvited')),
                  const SizedBox(width: 12),
                  Expanded(child: _MiniStat(label: 'Sipariş Tamamlayan', value: '$completedFirstOrder')),
                ]),

                const SizedBox(height: 24),
                const Text('Puan Geçmişi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),

                historyAsync.when(
                  loading: () => const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Center(child: CircularProgressIndicator()),
                  ),
                  error: (e, _) => Text('Geçmiş yüklenemedi: $e', style: const TextStyle(color: Colors.red)),
                  data: (transactions) {
                    if (transactions.isEmpty) {
                      return Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(32),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: const Color(0xFFE2E8F0)),
                        ),
                        child: const Center(child: Text('Henüz puan hareketi yok', style: TextStyle(color: Colors.grey))),
                      );
                    }

                    return Column(children: transactions.map((t) => _TransactionTile(transaction: t)).toList());
                  },
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label, value;
  const _MiniStat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(children: [
        Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      ]),
    );
  }
}

class _TransactionTile extends StatelessWidget {
  final Map<String, dynamic> transaction;
  const _TransactionTile({required this.transaction});

  @override
  Widget build(BuildContext context) {
    final points = (transaction['points'] as num?)?.toInt() ?? 0;
    final isPositive = points >= 0;
    final description = transaction['description']?.toString() ?? '';
    final createdAt = transaction['created_at']?.toString() ?? '';
    final dateOnly = createdAt.contains('T') ? createdAt.split('T')[0] : createdAt;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: isPositive ? const Color(0xFFF0FDF4) : const Color(0xFFFEF2F2),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            isPositive ? Icons.add_circle_outline : Icons.remove_circle_outline,
            color: isPositive ? const Color(0xFF16A34A) : const Color(0xFFDC2626),
            size: 18,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(description, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
            Text(dateOnly, style: const TextStyle(color: Colors.grey, fontSize: 11)),
          ]),
        ),
        Text(
          '${isPositive ? '+' : ''}$points',
          style: TextStyle(fontWeight: FontWeight.bold, color: isPositive ? const Color(0xFF16A34A) : const Color(0xFFDC2626)),
        ),
      ]),
    );
  }
}
