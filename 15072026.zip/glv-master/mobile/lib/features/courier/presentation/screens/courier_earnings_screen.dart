// lib/features/courier/presentation/screens/courier_earnings_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/api/api_client.dart';

enum EarningsPeriod { today, week, month }

extension on EarningsPeriod {
  String get apiValue => switch (this) {
        EarningsPeriod.today => 'today',
        EarningsPeriod.week => 'week',
        EarningsPeriod.month => 'month',
      };

  String get label => switch (this) {
        EarningsPeriod.today => 'Bugün',
        EarningsPeriod.week => 'Bu Hafta',
        EarningsPeriod.month => 'Bu Ay',
      };
}

final earningsPeriodProvider = StateProvider<EarningsPeriod>((ref) => EarningsPeriod.week);

final earningsSummaryProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  final period = ref.watch(earningsPeriodProvider);
  final res = await ref.read(dioProvider).get('/courier/earnings/summary', queryParameters: {'period': period.apiValue});
  return Map<String, dynamic>.from(res.data);
});

final earningsListProvider = FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
  final period = ref.watch(earningsPeriodProvider);
  final res = await ref.read(dioProvider).get('/courier/earnings', queryParameters: {'period': period.apiValue});
  final data = res.data['data'] ?? res.data;
  return List<Map<String, dynamic>>.from(data);
});

class CourierEarningsScreen extends ConsumerWidget {
  const CourierEarningsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedPeriod = ref.watch(earningsPeriodProvider);
    final summaryAsync = ref.watch(earningsSummaryProvider);
    final listAsync = ref.watch(earningsListProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(title: const Text('Kazançlarım'), backgroundColor: Colors.white),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(earningsSummaryProvider);
          ref.invalidate(earningsListProvider);
        },
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Dönem seçici
            Row(
              children: EarningsPeriod.values.map((p) {
                final selected = p == selectedPeriod;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ChoiceChip(
                      label: Text(p.label),
                      selected: selected,
                      onSelected: (_) => ref.read(earningsPeriodProvider.notifier).state = p,
                      selectedColor: const Color(0xFF16A34A),
                      labelStyle: TextStyle(color: selected ? Colors.white : Colors.black87),
                      backgroundColor: Colors.white,
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),

            summaryAsync.when(
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: 40),
                child: Center(child: CircularProgressIndicator()),
              ),
              error: (e, _) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Text('Özet yüklenemedi: $e', style: const TextStyle(color: Colors.red)),
              ),
              data: (summary) => _SummaryCard(summary: summary),
            ),

            const SizedBox(height: 24),
            const Text('Teslimat Geçmişi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),

            listAsync.when(
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: 20),
                child: Center(child: CircularProgressIndicator()),
              ),
              error: (e, _) => Text('Liste yüklenemedi: $e', style: const TextStyle(color: Colors.red)),
              data: (earnings) {
                if (earnings.isEmpty) {
                  return Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(32),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                    ),
                    child: Column(children: [
                      Icon(Icons.account_balance_wallet_outlined, size: 56, color: Colors.grey.shade300),
                      const SizedBox(height: 12),
                      const Text('Bu dönemde henüz teslimat kazancınız yok', style: TextStyle(color: Colors.grey)),
                    ]),
                  );
                }

                return Column(
                  children: earnings.map((e) => _EarningTile(earning: e)).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final Map<String, dynamic> summary;
  const _SummaryCard({required this.summary});

  @override
  Widget build(BuildContext context) {
    final total = (summary['total_earning'] as num?)?.toDouble() ?? 0;
    final pending = (summary['pending_amount'] as num?)?.toDouble() ?? 0;
    final paid = (summary['paid_amount'] as num?)?.toDouble() ?? 0;
    final count = summary['delivery_count'] ?? 0;
    final avg = (summary['avg_per_delivery'] as num?)?.toDouble() ?? 0;

    return Column(children: [
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF16A34A), Color(0xFF15803D)]),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Toplam Kazanç', style: TextStyle(color: Colors.white70, fontSize: 13)),
          const SizedBox(height: 6),
          Text('${total.toStringAsFixed(2)} KM', style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text('$count teslimat · ort. ${avg.toStringAsFixed(2)} KM', style: const TextStyle(color: Colors.white70, fontSize: 13)),
        ]),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: _MiniStat(label: 'Bekleyen Ödeme', value: '${pending.toStringAsFixed(2)} KM', color: const Color(0xFFF59E0B)),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _MiniStat(label: 'Ödenen', value: '${paid.toStringAsFixed(2)} KM', color: const Color(0xFF2563EB)),
        ),
      ]),
    ]);
  }
}

class _MiniStat extends StatelessWidget {
  final String label, value;
  final Color color;
  const _MiniStat({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      ]),
    );
  }
}

class _EarningTile extends StatelessWidget {
  final Map<String, dynamic> earning;
  const _EarningTile({required this.earning});

  @override
  Widget build(BuildContext context) {
    final total = (earning['total_earning'] as num?)?.toDouble() ?? 0;
    final distance = (earning['distance_km'] as num?)?.toDouble() ?? 0;
    final status = earning['status'] ?? 'pending';
    final earnedAt = earning['earned_at']?.toString() ?? '';
    final order = earning['order'] as Map<String, dynamic>?;
    final address = order?['delivery_address']?.toString() ?? 'Teslimat';
    final earnedDateOnly = earnedAt.contains('T') ? earnedAt.split('T')[0] : earnedAt;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(children: [
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(color: const Color(0xFFF0FDF4), borderRadius: BorderRadius.circular(10)),
          child: const Icon(Icons.delivery_dining, color: Color(0xFF16A34A)),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(address, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 2),
            Text('${distance.toStringAsFixed(1)} km · $earnedDateOnly', style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ]),
        ),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('+${total.toStringAsFixed(2)} KM', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF16A34A))),
          const SizedBox(height: 4),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: status == 'paid' ? const Color(0xFFDCFCE7) : const Color(0xFFFEF3C7),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              status == 'paid' ? 'Ödendi' : 'Bekliyor',
              style: TextStyle(fontSize: 10, color: status == 'paid' ? const Color(0xFF15803D) : const Color(0xFFB45309)),
            ),
          ),
        ]),
      ]),
    );
  }
}
