// lib/features/courier/presentation/screens/courier_home_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/api/api_client.dart';
import '../../data/services/courier_location_service.dart';

final courierOnlineProvider = StateProvider<bool>((ref) => false);

final courierTodaySummaryProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  final res = await ref.read(dioProvider).get('/courier/earnings/summary', queryParameters: {'period': 'today'});
  return Map<String, dynamic>.from(res.data);
});

final courierWeekSummaryProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  final res = await ref.read(dioProvider).get('/courier/earnings/summary', queryParameters: {'period': 'week'});
  return Map<String, dynamic>.from(res.data);
});

final courierActiveRouteProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  final res = await ref.read(dioProvider).get('/courier/route');
  return Map<String, dynamic>.from(res.data);
});

class CourierHomeScreen extends ConsumerStatefulWidget {
  const CourierHomeScreen({super.key});

  @override
  ConsumerState<CourierHomeScreen> createState() => _CourierHomeScreenState();
}

class _CourierHomeScreenState extends ConsumerState<CourierHomeScreen> {
  bool _permissionDenied = false;

  Future<void> _toggleOnline(bool value) async {
    if (value) {
      // Online olunca konum iznini kontrol et ve takibi başlat
      final locationService = ref.read(courierLocationServiceProvider);
      final hasPermission = await locationService.ensurePermissions();

      if (!hasPermission) {
        setState(() => _permissionDenied = true);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Konum izni olmadan online olamazsınız.'),
              backgroundColor: Colors.red,
            ),
          );
        }
        return;
      }

      setState(() => _permissionDenied = false);
      await locationService.startTracking();
    } else {
      // Offline olunca takibi durdur
      ref.read(courierLocationServiceProvider).stopTracking();
    }

    ref.read(courierOnlineProvider.notifier).state = value;

    try {
      await ref.read(dioProvider).patch('/courier/availability', data: {'is_online': value});
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final isOnline = ref.watch(courierOnlineProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text('Kurye Paneli'),
        backgroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.account_balance_wallet_outlined),
            tooltip: 'Kazançlarım',
            onPressed: () => context.push('/courier/earnings'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          // Online/Offline kart
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isOnline
                    ? [const Color(0xFF16A34A), const Color(0xFF15803D)]
                    : [const Color(0xFF64748B), const Color(0xFF475569)],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(
                    isOnline ? '🟢 Çevrimiçisin' : '⚫ Çevrimdışısın',
                    style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isOnline ? 'Konum izleniyor, sipariş teklifi alıyorsun' : 'Sipariş almak için aç',
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                ]),
              ),
              Switch(
                value: isOnline,
                activeColor: Colors.white,
                activeTrackColor: const Color(0xFF4ADE80),
                inactiveThumbColor: Colors.white,
                inactiveTrackColor: Colors.white24,
                onChanged: _toggleOnline,
              ),
            ]),
          ),

          if (_permissionDenied) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFEF2F2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFFECACA)),
              ),
              child: const Row(children: [
                Icon(Icons.location_off, color: Color(0xFFDC2626), size: 20),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Konum izni reddedildi. Lütfen ayarlardan konum iznini etkinleştirin.',
                    style: TextStyle(color: Color(0xFFDC2626), fontSize: 13),
                  ),
                ),
              ]),
            ),
          ],

          const SizedBox(height: 24),

          // İstatistikler
          Consumer(builder: (context, ref, _) {
            final todayAsync = ref.watch(courierTodaySummaryProvider);
            final weekAsync = ref.watch(courierWeekSummaryProvider);

            final todayCount = todayAsync.valueOrNull?['delivery_count']?.toString() ?? '—';
            final todayEarning = (todayAsync.valueOrNull?['total_earning'] as num?)?.toStringAsFixed(2) ?? '0.00';
            final weekCount = weekAsync.valueOrNull?['delivery_count']?.toString() ?? '—';

            return Column(children: [
              Row(children: [
                Expanded(child: _StatCard(label: 'Bugün', value: '$todayCount Teslimat', icon: Icons.delivery_dining, color: const Color(0xFF2563EB))),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () => context.push('/courier/earnings'),
                    child: _StatCard(label: 'Kazanç (Bugün)', value: '$todayEarning KM', icon: Icons.account_balance_wallet_outlined, color: const Color(0xFF16A34A)),
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _StatCard(label: 'Bu Hafta', value: '$weekCount Teslimat', icon: Icons.calendar_today_outlined, color: const Color(0xFF7C3AED))),
                const SizedBox(width: 12),
                Expanded(child: _StatCard(label: 'Puan', value: '—', icon: Icons.star_outline, color: const Color(0xFFF59E0B))),
              ]),
            ]);
          }),

          const SizedBox(height: 24),

          const Text('Aktif Sipariş', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),

          if (!isOnline)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Column(children: [
                Icon(Icons.directions_bike, size: 64, color: Colors.grey.shade300),
                const SizedBox(height: 16),
                const Text('Sipariş almak için çevrimiçi olun', style: TextStyle(color: Colors.grey, fontSize: 15)),
              ]),
            )
          else
            Consumer(builder: (context, ref, _) {
              final routeAsync = ref.watch(courierActiveRouteProvider);

              return routeAsync.when(
                loading: () => Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                  ),
                  child: const Center(child: CircularProgressIndicator(strokeWidth: 3)),
                ),
                error: (_, __) => Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFE2E8F0)),
                  ),
                  child: const Column(children: [
                    SizedBox(
                      width: 32, height: 32,
                      child: CircularProgressIndicator(strokeWidth: 3, color: Color(0xFFF97316)),
                    ),
                    SizedBox(height: 16),
                    Text('Sipariş bekleniyor...', style: TextStyle(color: Colors.grey)),
                  ]),
                ),
                data: (route) {
                  final stops = List<Map<String, dynamic>>.from(route['stops'] ?? []);

                  if (stops.isEmpty) {
                    return Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(32),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: const Column(children: [
                        SizedBox(
                          width: 32, height: 32,
                          child: CircularProgressIndicator(strokeWidth: 3, color: Color(0xFFF97316)),
                        ),
                        SizedBox(height: 16),
                        Text('Sipariş bekleniyor...', style: TextStyle(color: Colors.grey)),
                      ]),
                    );
                  }

                  // Kabul edilmiş sipariş sayısı = dropoff durak sayısı (her sipariş bir dropoff'a sahip)
                  final orderCount = stops.map((s) => s['order_id']).toSet().length;
                  final distance = (route['total_distance_km'] as num?)?.toDouble() ?? 0;
                  final eta = route['total_eta_minutes'] ?? 0;
                  final nextStop = stops.first;

                  return GestureDetector(
                    onTap: () => context.push('/courier/route'),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFFBFDBFE)),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(color: const Color(0xFFEFF6FF), borderRadius: BorderRadius.circular(20)),
                            child: Text(
                              orderCount > 1 ? '$orderCount sipariş · birlikte taşınıyor' : '1 sipariş',
                              style: const TextStyle(color: Color(0xFF1D4ED8), fontSize: 12, fontWeight: FontWeight.w600),
                            ),
                          ),
                          const Spacer(),
                          Text('${distance.toStringAsFixed(1)} km · ~$eta dk', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                        ]),
                        const SizedBox(height: 12),
                        Row(children: [
                          Icon(nextStop['type'] == 'pickup' ? Icons.storefront : Icons.flag, color: const Color(0xFF2563EB), size: 20),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Sıradaki: ${nextStop['label'] ?? ''}',
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ),
                          const Icon(Icons.chevron_right, color: Colors.grey),
                        ]),
                      ]),
                    ),
                  );
                },
              );
            }),
        ]),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;
  const _StatCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      ]),
    );
  }
}
