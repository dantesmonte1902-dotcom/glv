// lib/features/courier/presentation/screens/courier_route_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/api/api_client.dart';

final courierRouteProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  final res = await ref.read(dioProvider).get('/courier/route');
  return Map<String, dynamic>.from(res.data);
});

/// Kuryenin üzerindeki tüm kabul edilmiş siparişler için optimize edilmiş
/// durak sırasını (teslim alma + teslim etme) gösterir. Tek siparişte de
/// çalışır, ama asıl değeri kurye aynı anda 2+ sipariş taşırken (batching)
/// ortaya çıkar: hangi sıraya göre gideceğini net gösterir.
class CourierRouteScreen extends ConsumerWidget {
  const CourierRouteScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final routeAsync = ref.watch(courierRouteProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(title: const Text('Aktif Rotam'), backgroundColor: Colors.white),
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(courierRouteProvider),
        child: routeAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('Rota yüklenemedi: $e')),
          data: (route) {
            final stops = List<Map<String, dynamic>>.from(route['stops'] ?? []);
            final totalDistance = (route['total_distance_km'] as num?)?.toDouble() ?? 0;
            final totalEta = route['total_eta_minutes'] ?? 0;

            if (stops.isEmpty) {
              return ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  const SizedBox(height: 60),
                  Icon(Icons.route_outlined, size: 72, color: Colors.grey.shade300),
                  const SizedBox(height: 16),
                  const Center(child: Text('Şu anda aktif rotanız yok', style: TextStyle(color: Colors.grey, fontSize: 15))),
                ],
              );
            }

            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // Özet kart
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF2563EB), Color(0xFF1D4ED8)]),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${stops.length} durak', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text(
                          '${totalDistance.toStringAsFixed(1)} km · ~$totalEta dk',
                          style: const TextStyle(color: Colors.white70, fontSize: 13),
                        ),
                      ]),
                    ),
                    const Icon(Icons.alt_route, color: Colors.white, size: 32),
                  ]),
                ),
                const SizedBox(height: 20),

                ...stops.asMap().entries.map((entry) {
                  final stop = entry.value;
                  final isLast = entry.key == stops.length - 1;
                  return _RouteStopTile(stop: stop, isLast: isLast);
                }),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _RouteStopTile extends ConsumerWidget {
  final Map<String, dynamic> stop;
  final bool isLast;
  const _RouteStopTile({required this.stop, required this.isLast});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isPickup = stop['type'] == 'pickup';
    final sequence = stop['sequence'];
    final label = stop['label']?.toString() ?? '';
    final address = stop['address']?.toString() ?? '';
    final distance = (stop['distance_from_previous_km'] as num?)?.toDouble() ?? 0;
    final orderId = stop['order_id'];

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Sıra numarası + dikey çizgi
          Column(children: [
            Container(
              width: 32, height: 32,
              decoration: BoxDecoration(
                color: isPickup ? const Color(0xFFF97316) : const Color(0xFF16A34A),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text('$sequence', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ),
            if (!isLast) Expanded(child: Container(width: 2, color: const Color(0xFFE2E8F0))),
          ]),
          const SizedBox(width: 14),

          // Durak kartı
          Expanded(
            child: Container(
              margin: const EdgeInsets.only(bottom: 16),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: isPickup ? const Color(0xFFFFF7ED) : const Color(0xFFF0FDF4),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      isPickup ? 'RESTORANDAN AL' : 'MÜŞTERİYE TESLİM ET',
                      style: TextStyle(
                        fontSize: 10, fontWeight: FontWeight.bold,
                        color: isPickup ? const Color(0xFFC2410C) : const Color(0xFF15803D),
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text('${distance.toStringAsFixed(1)} km', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                ]),
                const SizedBox(height: 8),
                Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                if (address.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(address, style: const TextStyle(color: Colors.grey, fontSize: 13)),
                ],
                if (!isPickup) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF16A34A), foregroundColor: Colors.white),
                      icon: const Icon(Icons.check_circle_outline, size: 18),
                      label: const Text('Teslim Edildi'),
                      onPressed: () => _markDelivered(context, ref, orderId),
                    ),
                  ),
                ],
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _markDelivered(BuildContext context, WidgetRef ref, dynamic orderId) async {
    try {
      await ref.read(dioProvider).post('/orders/$orderId/deliver');
      ref.invalidate(courierRouteProvider);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Teslimat tamamlandı olarak işaretlendi.'), backgroundColor: Color(0xFF16A34A)),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Hata: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }
}
