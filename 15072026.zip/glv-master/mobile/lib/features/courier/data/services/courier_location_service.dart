// lib/features/courier/data/services/courier_location_service.dart

import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import '../../../../core/api/api_client.dart';

class CourierLocationService {
  final _ref;
  StreamSubscription<Position>? _positionSub;

  CourierLocationService(this._ref);

  /// Konum izinlerini kontrol eder ve gerekirse ister.
  Future<bool> ensurePermissions() async {
    var permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.deniedForever) {
      return false;
    }

    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    return serviceEnabled && permission != LocationPermission.denied;
  }

  /// Konum takibini başlatır. Her 15 metrede bir backend'e konum gönderir.
  Future<void> startTracking() async {
    final hasPermission = await ensurePermissions();
    if (!hasPermission) return;

    const settings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 15, // metre
    );

    _positionSub = Geolocator.getPositionStream(locationSettings: settings).listen(
      (position) => _sendLocationUpdate(position),
    );
  }

  void stopTracking() {
    _positionSub?.cancel();
    _positionSub = null;
  }

  Future<void> _sendLocationUpdate(Position position) async {
    try {
      await _ref.read(dioProvider).patch('/courier/location', data: {
        'lat': position.latitude,
        'lng': position.longitude,
      });
    } catch (_) {
      // Sessizce başarısız ol — bir sonraki güncellemede tekrar dener
    }
  }
}

final courierLocationServiceProvider = Provider<CourierLocationService>((ref) {
  final service = CourierLocationService(ref);
  ref.onDispose(service.stopTracking);
  return service;
});
