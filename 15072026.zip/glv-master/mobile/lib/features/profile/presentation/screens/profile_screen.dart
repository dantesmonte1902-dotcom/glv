// lib/features/profile/presentation/screens/profile_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../auth/data/repositories/auth_repository.dart';
import '../../../address/presentation/screens/address_list_screen.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final user = auth.user;

    if (user == null) {
      return Scaffold(
        body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.person_outline, size: 80, color: Colors.grey),
          const SizedBox(height: 16),
          const Text('Hesabınıza giriş yapın', style: TextStyle(fontSize: 16, color: Colors.grey)),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: () => context.go('/login'), child: const Text('Giriş Yap')),
        ])),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(title: const Text('Profilim'), backgroundColor: Colors.white),
      body: ListView(children: [

        // Profil başlık kartı
        Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 24),
          child: Column(children: [
            Stack(children: [
              CircleAvatar(
                radius: 44,
                backgroundColor: const Color(0xFFFFF7ED),
                child: Text(
                  user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                  style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xFFF97316)),
                ),
              ),
              Positioned(
                bottom: 0, right: 0,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(color: Color(0xFFF97316), shape: BoxShape.circle),
                  child: const Icon(Icons.edit, color: Colors.white, size: 14),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            Text(user.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(user.email, style: const TextStyle(color: Colors.grey, fontSize: 13)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              decoration: BoxDecoration(color: const Color(0xFFFFF7ED), borderRadius: BorderRadius.circular(20)),
              child: Text(
                _roleTr(user.role),
                style: const TextStyle(color: Color(0xFFF97316), fontWeight: FontWeight.w600, fontSize: 12),
              ),
            ),
          ]),
        ),

        const SizedBox(height: 12),

        // Müşteri menüsü
        if (user.isCustomer) ...[
          _MenuSection(title: 'Siparişlerim', items: [
            _MenuItem(Icons.receipt_long_outlined, 'Siparişlerim', () => context.go('/orders')),
            _MenuItem(Icons.favorite_border, 'Favorilerim', () => context.go('/favorites')),
            _MenuItem(Icons.stars_outlined, 'Sadakat & Referans', () => context.push('/loyalty')),
          ]),
          const SizedBox(height: 8),
          _MenuSection(title: 'Hesap', items: [
            _MenuItem(Icons.location_on_outlined, 'Adreslerim', () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const AddressListScreen()),
            )),
            _MenuItem(Icons.notifications_outlined, 'Bildirimler', () {}),
          ]),
        ],

        // Restoran menüsü
        if (user.isRestaurant) ...[
          _MenuSection(title: 'Yönetim', items: [
            _MenuItem(Icons.bar_chart_outlined, 'Raporlar ve Analitik', () {}),
            _MenuItem(Icons.restaurant_menu_outlined, 'Menü Yönetimi', () {}),
          ]),
        ],

        const SizedBox(height: 8),

        // Genel
        _MenuSection(title: 'Diğer', items: [
          _MenuItem(Icons.help_outline, 'Yardım & Destek', () => context.push('/support')),
          _MenuItem(Icons.info_outline, 'Hakkında', () {}),
        ]),

        const SizedBox(height: 8),

        // Çıkış
        Container(
          color: Colors.white,
          child: _MenuItem(
            Icons.logout, 'Çıkış Yap',
            () async {
              await ref.read(authProvider.notifier).logout();
              if (context.mounted) context.go('/login');
            },
            color: Colors.red,
          ),
        ),

        const SizedBox(height: 40),
        Center(
          child: Text('GLV v1.0.0', style: TextStyle(color: Colors.grey.shade400, fontSize: 12)),
        ),
        const SizedBox(height: 24),
      ]),
    );
  }

  String _roleTr(String role) => switch (role) {
    'admin' => 'Admin',
    'restaurant' => 'Restoran',
    'courier' => 'Kurye',
    _ => 'Müşteri',
  };
}

class _MenuSection extends StatelessWidget {
  final String title;
  final List<Widget> items;
  const _MenuSection({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
        child: Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.grey)),
      ),
      Container(
        color: Colors.white,
        child: Column(
          children: items.expand((item) sync* {
            yield item;
            if (item != items.last) yield const Divider(height: 1, indent: 56);
          }).toList(),
        ),
      ),
    ]);
  }
}

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;
  const _MenuItem(this.icon, this.label, this.onTap, {this.color});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: color ?? const Color(0xFF475569)),
      title: Text(label, style: TextStyle(color: color ?? const Color(0xFF1E293B), fontSize: 15)),
      trailing: Icon(Icons.chevron_right, color: Colors.grey.shade300),
      onTap: onTap,
    );
  }
}
