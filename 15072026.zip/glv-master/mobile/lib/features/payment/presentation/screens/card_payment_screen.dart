// lib/features/payment/presentation/screens/card_payment_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/api/api_client.dart';

class CardPaymentScreen extends ConsumerStatefulWidget {
  final int orderId;
  final double amount;

  const CardPaymentScreen({
    super.key,
    required this.orderId,
    required this.amount,
  });

  @override
  ConsumerState<CardPaymentScreen> createState() => _CardPaymentScreenState();
}

class _CardPaymentScreenState extends ConsumerState<CardPaymentScreen> {
  bool _loading = false;
  String? _error;

  Future<void> _pay() async {
    setState(() { _loading = true; _error = null; });

    try {
      // 1. Backend'den PaymentIntent oluştur
      final response = await ref.read(dioProvider).post(
        '/orders/${widget.orderId}/payment/intent',
      );

      final clientSecret = response.data['client_secret'] as String;

      // 2. Stripe ödeme sayfasını aç
      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'GLV Teslimat',
          style: ThemeMode.light,
          appearance: const PaymentSheetAppearance(
            colors: PaymentSheetAppearanceColors(
              primary: Color(0xFFF97316),
            ),
            shapes: PaymentSheetShape(
              borderRadius: 12,
            ),
          ),
        ),
      );

      await Stripe.instance.presentPaymentSheet();

      // 3. Ödeme başarılı — sipariş takip sayfasına git
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Ödeme başarılı! Siparişiniz onaylanıyor.'),
            backgroundColor: Color(0xFF16A34A),
          ),
        );
        context.go('/orders/${widget.orderId}/tracking');
      }
    } on StripeException catch (e) {
      if (e.error.code == FailureCode.Canceled) {
        // Kullanıcı iptal etti — hata gösterme
        setState(() => _loading = false);
        return;
      }
      setState(() {
        _error = e.error.localizedMessage ?? 'Ödeme başarısız oldu.';
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Bir hata oluştu: $e';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kart ile Ödeme')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Sipariş özeti
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Sipariş No', style: TextStyle(color: Colors.grey)),
                  Text('#${widget.orderId}', style: const TextStyle(fontWeight: FontWeight.bold)),
                ]),
                const SizedBox(height: 12),
                const Divider(height: 1),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Toplam Tutar', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  Text(
                    '${widget.amount.toStringAsFixed(2)} KM',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFFF97316)),
                  ),
                ]),
              ]),
            ),

            const SizedBox(height: 32),

            // Güvenli ödeme bilgisi
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFF0FDF4),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFBBF7D0)),
              ),
              child: const Row(children: [
                Icon(Icons.lock_outline, color: Color(0xFF16A34A), size: 20),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Ödemeniz Stripe ile güvenli şekilde işlenir. Kart bilgileriniz bizimle paylaşılmaz.',
                    style: TextStyle(color: Color(0xFF15803D), fontSize: 13),
                  ),
                ),
              ]),
            ),

            const SizedBox(height: 16),

            // Kabul edilen kartlar
            const Row(children: [
              Text('Kabul edilen kartlar:', style: TextStyle(color: Colors.grey, fontSize: 13)),
              SizedBox(width: 8),
              _CardBadge('VISA'),
              SizedBox(width: 6),
              _CardBadge('MC'),
              SizedBox(width: 6),
              _CardBadge('AMEX'),
            ]),

            const Spacer(),

            if (_error != null) ...[
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFFEF2F2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFFECACA)),
                ),
                child: Row(children: [
                  const Icon(Icons.error_outline, color: Color(0xFFDC2626), size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(_error!, style: const TextStyle(color: Color(0xFFDC2626), fontSize: 13)),
                  ),
                ]),
              ),
              const SizedBox(height: 16),
            ],

            ElevatedButton.icon(
              onPressed: _loading ? null : _pay,
              icon: _loading
                  ? const SizedBox(height: 18, width: 18,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.credit_card),
              label: Text(
                _loading ? 'İşleniyor...' : 'Kartla Öde — ${widget.amount.toStringAsFixed(2)} KM',
              ),
            ),

            const SizedBox(height: 12),

            OutlinedButton(
              onPressed: _loading ? null : () => Navigator.pop(context),
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
              child: const Text('Geri Dön'),
            ),
          ],
        ),
      ),
    );
  }
}

class _CardBadge extends StatelessWidget {
  final String label;
  const _CardBadge(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFFE2E8F0)),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF475569))),
    );
  }
}
