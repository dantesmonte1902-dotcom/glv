// lib/features/address/data/models/address_model.dart

class CustomerAddress {
  final int id;
  final String title;
  final String fullAddress;
  final String? district;
  final String? cityName;
  final double? lat;
  final double? lng;
  final String? notes;
  final bool isDefault;

  const CustomerAddress({
    required this.id,
    required this.title,
    required this.fullAddress,
    this.district,
    this.cityName,
    this.lat,
    this.lng,
    this.notes,
    required this.isDefault,
  });

  factory CustomerAddress.fromJson(Map<String, dynamic> json) => CustomerAddress(
    id: json['id'],
    title: json['title'],
    fullAddress: json['full_address'],
    district: json['district'],
    cityName: json['city_name'],
    lat: json['lat']?.toDouble(),
    lng: json['lng']?.toDouble(),
    notes: json['notes'],
    isDefault: json['is_default'] ?? false,
  );

  Map<String, dynamic> toJson() => {
    'title': title,
    'full_address': fullAddress,
    if (district != null) 'district': district,
    if (cityName != null) 'city_name': cityName,
    if (lat != null) 'lat': lat,
    if (lng != null) 'lng': lng,
    if (notes != null) 'notes': notes,
    'is_default': isDefault,
  };
}
