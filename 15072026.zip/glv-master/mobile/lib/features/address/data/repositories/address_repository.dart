// lib/features/address/data/repositories/address_repository.dart

import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/api/api_client.dart';
import '../models/address_model.dart';

final addressRepositoryProvider = Provider<AddressRepository>((ref) {
  return AddressRepository(ref.read(dioProvider));
});

class AddressRepository {
  final Dio _dio;
  AddressRepository(this._dio);

  Future<List<CustomerAddress>> getAddresses() async {
    final res = await _dio.get('/addresses');
    final data = res.data['data'] ?? res.data;
    return (data as List).map((a) => CustomerAddress.fromJson(a)).toList();
  }

  Future<CustomerAddress> createAddress(Map<String, dynamic> data) async {
    final res = await _dio.post('/addresses', data: data);
    return CustomerAddress.fromJson(res.data['data'] ?? res.data);
  }

  Future<CustomerAddress> updateAddress(int id, Map<String, dynamic> data) async {
    final res = await _dio.patch('/addresses/$id', data: data);
    return CustomerAddress.fromJson(res.data['data'] ?? res.data);
  }

  Future<void> deleteAddress(int id) async {
    await _dio.delete('/addresses/$id');
  }

  Future<CustomerAddress> setDefault(int id) async {
    final res = await _dio.post('/addresses/$id/set-default');
    return CustomerAddress.fromJson(res.data['data'] ?? res.data);
  }
}

// State notifier
class AddressNotifier extends StateNotifier<AsyncValue<List<CustomerAddress>>> {
  final AddressRepository _repo;

  AddressNotifier(this._repo) : super(const AsyncValue.loading()) {
    load();
  }

  Future<void> load() async {
    state = const AsyncValue.loading();
    try {
      final addresses = await _repo.getAddresses();
      state = AsyncValue.data(addresses);
    } catch (e, s) {
      state = AsyncValue.error(e, s);
    }
  }

  Future<void> create(Map<String, dynamic> data) async {
    await _repo.createAddress(data);
    await load();
  }

  Future<void> update(int id, Map<String, dynamic> data) async {
    await _repo.updateAddress(id, data);
    await load();
  }

  Future<void> delete(int id) async {
    await _repo.deleteAddress(id);
    await load();
  }

  Future<void> setDefault(int id) async {
    await _repo.setDefault(id);
    await load();
  }
}

final addressProvider = StateNotifierProvider<AddressNotifier, AsyncValue<List<CustomerAddress>>>((ref) {
  return AddressNotifier(ref.read(addressRepositoryProvider));
});
