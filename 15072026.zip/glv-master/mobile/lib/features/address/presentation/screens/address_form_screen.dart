// lib/features/address/presentation/screens/address_form_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/address_model.dart';
import '../../data/repositories/address_repository.dart';

class AddressFormScreen extends ConsumerStatefulWidget {
  final CustomerAddress? address; // null ise yeni ekle, dolu ise düzenle
  const AddressFormScreen({super.key, this.address});

  @override
  ConsumerState<AddressFormScreen> createState() => _AddressFormScreenState();
}

class _AddressFormScreenState extends ConsumerState<AddressFormScreen> {
  final _titleCtrl = TextEditingController();
  final _fullAddressCtrl = TextEditingController();
  final _districtCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  bool _isDefault = false;
  bool _saving = false;

  final _quickTitles = ['Ev', 'İş', 'Annem', 'Okul', 'Diğer'];

  @override
  void initState() {
    super.initState();
    final a = widget.address;
    if (a != null) {
      _titleCtrl.text = a.title;
      _fullAddressCtrl.text = a.fullAddress;
      _districtCtrl.text = a.district ?? '';
      _notesCtrl.text = a.notes ?? '';
      _isDefault = a.isDefault;
    }
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _fullAddressCtrl.dispose();
    _districtCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_titleCtrl.text.trim().isEmpty || _fullAddressCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Başlık ve adres zorunludur.'), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() => _saving = true);

    final data = {
      'title': _titleCtrl.text.trim(),
      'full_address': _fullAddressCtrl.text.trim(),
      if (_districtCtrl.text.isNotEmpty) 'district': _districtCtrl.text.trim(),
      if (_notesCtrl.text.isNotEmpty) 'notes': _notesCtrl.text.trim(),
      'is_default': _isDefault,
    };

    try {
      if (widget.address == null) {
        await ref.read(addressProvider.notifier).create(data);
      } else {
        await ref.read(addressProvider.notifier).update(widget.address!.id, data);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Hata: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.address != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Adresi Düzenle' : 'Yeni Adres'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          // Hızlı başlık seçimi
          const Text('Başlık', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: _quickTitles.map((t) => ChoiceChip(
              label: Text(t),
              selected: _titleCtrl.text == t,
              selectedColor: const Color(0xFFF97316),
              labelStyle: TextStyle(
                color: _titleCtrl.text == t ? Colors.white : null,
                fontWeight: _titleCtrl.text == t ? FontWeight.bold : null,
              ),
              onSelected: (_) => setState(() => _titleCtrl.text = t),
            )).toList(),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _titleCtrl,
            decoration: const InputDecoration(hintText: 'veya kendiniz yazın...'),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 20),

          const Text('Adres', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          TextField(
            controller: _fullAddressCtrl,
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: 'Sokak, bina no, daire...',
              prefixIcon: Padding(
                padding: EdgeInsets.only(bottom: 48),
                child: Icon(Icons.location_on_outlined),
              ),
            ),
          ),
          const SizedBox(height: 16),

          const Text('Semt / Mahalle', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          TextField(
            controller: _districtCtrl,
            decoration: const InputDecoration(hintText: 'Örn: Centar, Grbavica'),
          ),
          const SizedBox(height: 16),

          const Text('Kapı Notu (opsiyonel)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 8),
          TextField(
            controller: _notesCtrl,
            decoration: const InputDecoration(
              hintText: 'Örn: Kapı kodu 1234, 3. kat sağ',
              prefixIcon: Icon(Icons.notes_outlined),
            ),
          ),
          const SizedBox(height: 20),

          // Varsayılan toggle
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: Row(children: [
              const Icon(Icons.star_outline, color: Color(0xFFF97316)),
              const SizedBox(width: 12),
              const Expanded(
                child: Text('Varsayılan adres olarak kaydet',
                    style: TextStyle(fontWeight: FontWeight.w500)),
              ),
              Switch(
                value: _isDefault,
                activeColor: const Color(0xFFF97316),
                onChanged: (v) => setState(() => _isDefault = v),
              ),
            ]),
          ),

          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(height: 20, width: 20,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : Text(isEditing ? 'Güncelle' : 'Kaydet'),
          ),
        ]),
      ),
    );
  }
}
