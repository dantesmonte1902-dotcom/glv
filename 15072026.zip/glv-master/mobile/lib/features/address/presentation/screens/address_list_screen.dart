// lib/features/address/presentation/screens/address_list_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/address_model.dart';
import '../../data/repositories/address_repository.dart';
import 'address_form_screen.dart';

class AddressListScreen extends ConsumerWidget {
  /// Eğer true ise müşteri teslimat için adres seçiyor (checkout'tan açılır)
  final bool selectionMode;
  const AddressListScreen({super.key, this.selectionMode = false});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final addressAsync = ref.watch(addressProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(selectionMode ? 'Teslimat Adresi Seç' : 'Adreslerim'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AddressFormScreen()),
            ).then((_) => ref.read(addressProvider.notifier).load()),
          ),
        ],
      ),
      body: addressAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Hata: $e')),
        data: (addresses) {
          if (addresses.isEmpty) {
            return Center(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.location_off_outlined, size: 72, color: Colors.grey),
                const SizedBox(height: 16),
                const Text('Kayıtlı adresiniz yok', style: TextStyle(color: Colors.grey, fontSize: 16)),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AddressFormScreen()),
                  ).then((_) => ref.read(addressProvider.notifier).load()),
                  icon: const Icon(Icons.add),
                  label: const Text('Adres Ekle'),
                ),
              ]),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: addresses.length,
            itemBuilder: (ctx, i) => _AddressTile(
              address: addresses[i],
              selectionMode: selectionMode,
              onSelect: selectionMode
                  ? () => Navigator.pop(context, addresses[i])
                  : null,
            ),
          );
        },
      ),
    );
  }
}

class _AddressTile extends ConsumerWidget {
  final CustomerAddress address;
  final bool selectionMode;
  final VoidCallback? onSelect;

  const _AddressTile({
    required this.address,
    required this.selectionMode,
    this.onSelect,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: address.isDefault
              ? const Color(0xFFF97316)
              : const Color(0xFFE2E8F0),
          width: address.isDefault ? 2 : 1,
        ),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        onTap: selectionMode ? onSelect : null,
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: address.isDefault
                ? const Color(0xFFFFF7ED)
                : const Color(0xFFF1F5F9),
            shape: BoxShape.circle,
          ),
          child: Icon(
            _iconForTitle(address.title),
            color: address.isDefault
                ? const Color(0xFFF97316)
                : const Color(0xFF64748B),
          ),
        ),
        title: Row(children: [
          Text(address.title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          if (address.isDefault) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFFF97316),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text('Varsayılan',
                  style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600)),
            ),
          ],
        ]),
        subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 4),
          Text(address.fullAddress,
              style: const TextStyle(color: Colors.grey, fontSize: 13),
              maxLines: 2,
              overflow: TextOverflow.ellipsis),
          if (address.notes != null) ...[
            const SizedBox(height: 2),
            Text(address.notes!,
                style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12)),
          ],
        ]),
        trailing: selectionMode
            ? const Icon(Icons.chevron_right)
            : PopupMenuButton<String>(
                onSelected: (value) async {
                  switch (value) {
                    case 'default':
                      await ref.read(addressProvider.notifier).setDefault(address.id);
                    case 'edit':
                      if (context.mounted) {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => AddressFormScreen(address: address)),
                        );
                        ref.read(addressProvider.notifier).load();
                      }
                    case 'delete':
                      if (context.mounted) {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: const Text('Adresi Sil'),
                            content: Text('"${address.title}" adresini silmek istediğinize emin misiniz?'),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
                              TextButton(
                                onPressed: () => Navigator.pop(context, true),
                                child: const Text('Sil', style: TextStyle(color: Colors.red)),
                              ),
                            ],
                          ),
                        );
                        if (confirm == true) {
                          await ref.read(addressProvider.notifier).delete(address.id);
                        }
                      }
                  }
                },
                itemBuilder: (_) => [
                  if (!address.isDefault)
                    const PopupMenuItem(value: 'default', child: Text('Varsayılan Yap')),
                  const PopupMenuItem(value: 'edit', child: Text('Düzenle')),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Text('Sil', style: TextStyle(color: Colors.red)),
                  ),
                ],
              ),
      ),
    );
  }

  IconData _iconForTitle(String title) {
    final t = title.toLowerCase();
    if (t.contains('ev') || t.contains('home')) return Icons.home_outlined;
    if (t.contains('iş') || t.contains('ofis') || t.contains('work')) return Icons.business_outlined;
    return Icons.location_on_outlined;
  }
}
