// lib/main.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'core/constants/app_constants.dart';
import 'features/auth/data/repositories/auth_repository.dart';
import 'core/services/websocket_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Stripe başlat
  Stripe.publishableKey = AppConstants.stripePublishableKey;
  await Stripe.instance.applySettings();

  runApp(const ProviderScope(child: GlvApp()));
}

class GlvApp extends ConsumerWidget {
  const GlvApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(routerProvider);
    final auth = ref.watch(authProvider);

    // Kullanıcı giriş yaptığında WebSocket'e bağlan
    ref.listen(authProvider, (prev, next) {
      if (prev?.user == null && next.user != null) {
        // Bağlantı kurulacak — token auth interceptor üzerinden alınıyor
        // WebSocket servisi gerektiğinde lazy başlatılır
      }
    });

    return MaterialApp.router(
      title: 'GLV',
      theme: AppTheme.light,
      routerConfig: router,
      debugShowCheckedModeBanner: false,
    );
  }
}
