// lib/core/constants/app_constants.dart

class AppConstants {
  AppConstants._();

  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8080/api/v1',
  );

  static const String stripePublishableKey = String.fromEnvironment(
    'STRIPE_KEY',
    defaultValue: 'pk_test_YOUR_KEY_HERE',
  );

  // ─── Reverb WebSocket ─────────────────────────────────────────────────────
  static const String wsHost = String.fromEnvironment('WS_HOST', defaultValue: '10.0.2.2');
  static const int wsPort = int.fromEnvironment('WS_PORT', defaultValue: 8080);
  static const String wsKey = String.fromEnvironment('REVERB_APP_KEY', defaultValue: 'glv');
  static const String wsSecret = String.fromEnvironment('REVERB_APP_SECRET', defaultValue: 'secret');
  static const String wsScheme = String.fromEnvironment('WS_SCHEME', defaultValue: 'ws');

  // ─── Storage ──────────────────────────────────────────────────────────────
  static const String tokenKey = 'auth_token';
  static const String userKey = 'auth_user';
  static const String cityIdKey = 'selected_city_id';
}
