// lib/core/router/app_router.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/register_screen.dart';
import '../../features/menu/presentation/screens/home_screen.dart';
import '../../features/menu/presentation/screens/restaurant_menu_screen.dart';
import '../../features/menu/presentation/screens/product_detail_screen.dart';
import '../../features/cart/presentation/screens/cart_screen.dart';
import '../../features/cart/presentation/screens/checkout_screen.dart';
import '../../features/orders/presentation/screens/orders_screen.dart';
import '../../features/orders/presentation/screens/order_tracking_screen.dart';
import '../../features/orders/presentation/screens/courier_tracking_map_screen.dart';
import '../../features/payment/presentation/screens/card_payment_screen.dart';
import '../../features/review/presentation/screens/review_screen.dart';
import '../../features/favorite/presentation/screens/favorites_screen.dart';
import '../../features/courier/presentation/screens/courier_home_screen.dart';
import '../../features/courier/presentation/screens/courier_earnings_screen.dart';
import '../../features/courier/presentation/screens/courier_route_screen.dart';
import '../../features/loyalty/presentation/screens/loyalty_screen.dart';
import '../../features/support/presentation/screens/support_tickets_screen.dart';
import '../../features/support/presentation/screens/new_support_ticket_screen.dart';
import '../../features/support/presentation/screens/support_ticket_thread_screen.dart';
import '../../features/support/presentation/screens/create_dispute_screen.dart';
import '../../features/profile/presentation/screens/profile_screen.dart';
import '../api/api_client.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authEvent = ref.watch(authEventProvider);

  return GoRouter(
    initialLocation: '/home',
    redirect: (context, state) {
      if (authEvent == AuthEvent.unauthorized) {
        ref.read(authEventProvider.notifier).state = AuthEvent.none;
        return '/login';
      }
      return null;
    },
    routes: [
      GoRoute(path: '/login',    builder: (_, __) => const LoginScreen()),
      GoRoute(path: '/register', builder: (_, __) => const RegisterScreen()),

      ShellRoute(
        builder: (ctx, state, child) => MainShell(child: child),
        routes: [
          GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),

          GoRoute(
            path: '/restaurants/:branchId/menu',
            builder: (_, s) => RestaurantMenuScreen(branchId: int.parse(s.pathParameters['branchId']!)),
          ),

          GoRoute(
            path: '/products/:branchId/:productId',
            builder: (_, s) => ProductDetailScreen(
              branchId: int.parse(s.pathParameters['branchId']!),
              productId: int.parse(s.pathParameters['productId']!),
            ),
          ),

          GoRoute(path: '/cart',     builder: (_, __) => const CartScreen()),
          GoRoute(path: '/checkout', builder: (_, __) => const CheckoutScreen()),
          GoRoute(path: '/orders',   builder: (_, __) => const OrdersScreen()),

          GoRoute(
            path: '/orders/:orderId/tracking',
            builder: (_, s) => OrderTrackingScreen(orderId: int.parse(s.pathParameters['orderId']!)),
          ),

          GoRoute(
            path: '/orders/:orderId/dispute',
            builder: (_, s) => CreateDisputeScreen(orderId: int.parse(s.pathParameters['orderId']!)),
          ),

          GoRoute(path: '/support', builder: (_, __) => const SupportTicketsScreen()),
          GoRoute(path: '/support/new', builder: (_, __) => const NewSupportTicketScreen()),
          GoRoute(
            path: '/support/:ticketId',
            builder: (_, s) => SupportTicketThreadScreen(ticketId: int.parse(s.pathParameters['ticketId']!)),
          ),

          // Kurye harita takip ekranı
          GoRoute(
            path: '/orders/:orderId/map',
            builder: (_, s) => CourierTrackingMapScreen(
              orderId: int.parse(s.pathParameters['orderId']!),
              deliveryLat: double.parse(s.uri.queryParameters['lat'] ?? '0'),
              deliveryLng: double.parse(s.uri.queryParameters['lng'] ?? '0'),
              deliveryAddress: Uri.decodeComponent(s.uri.queryParameters['address'] ?? ''),
            ),
          ),

          // Kart ödeme ekranı
          GoRoute(
            path: '/orders/:orderId/pay',
            builder: (_, s) => CardPaymentScreen(
              orderId: int.parse(s.pathParameters['orderId']!),
              amount: double.parse(s.uri.queryParameters['amount'] ?? '0'),
            ),
          ),

          // Değerlendirme ekranı
          GoRoute(
            path: '/orders/:orderId/review',
            builder: (_, s) => ReviewScreen(orderId: int.parse(s.pathParameters['orderId']!)),
          ),

          // Favoriler
          GoRoute(path: '/favorites', builder: (_, __) => const FavoritesScreen()),

          GoRoute(path: '/courier', builder: (_, __) => const CourierHomeScreen()),
          GoRoute(path: '/courier/earnings', builder: (_, __) => const CourierEarningsScreen()),
          GoRoute(path: '/courier/route', builder: (_, __) => const CourierRouteScreen()),
          GoRoute(path: '/loyalty', builder: (_, __) => const LoyaltyScreen()),
          GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
        ],
      ),
    ],
  );
});

class MainShell extends ConsumerWidget {
  final Widget child;
  const MainShell({super.key, required this.child});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: child,
      bottomNavigationBar: NavigationBar(
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined),          selectedIcon: Icon(Icons.home),          label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined),  selectedIcon: Icon(Icons.shopping_cart),  label: 'Sepet'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined),   selectedIcon: Icon(Icons.receipt_long),   label: 'Siparişler'),
          NavigationDestination(icon: Icon(Icons.person_outline),          selectedIcon: Icon(Icons.person),         label: 'Profil'),
        ],
        onDestinationSelected: (i) {
          switch (i) {
            case 0: context.go('/home');
            case 1: context.go('/cart');
            case 2: context.go('/orders');
            case 3: context.go('/profile');
          }
        },
      ),
    );
  }
}
