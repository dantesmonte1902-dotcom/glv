// lib/core/services/websocket_service.dart

import 'dart:async';
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:crypto/crypto.dart';
import '../constants/app_constants.dart';

/// Reverb WebSocket bağlantısı ve kanal yönetimi
class WebSocketService {
  WebSocketChannel? _channel;
  final Map<String, StreamController<Map<String, dynamic>>> _channelControllers = {};
  bool _isConnected = false;
  Timer? _pingTimer;
  int _socketId = 0;

  bool get isConnected => _isConnected;

  /// Reverb'e bağlan
  Future<void> connect(String authToken) async {
    if (_isConnected) return;

    final uri = Uri(
      scheme: AppConstants.wsScheme,
      host: AppConstants.wsHost,
      port: AppConstants.wsPort,
      path: '/app/${AppConstants.wsKey}',
      queryParameters: {
        'protocol': '7',
        'client': 'flutter',
        'version': '8.0.0',
      },
    );

    try {
      _channel = WebSocketChannel.connect(uri);

      _channel!.stream.listen(
        (data) => _handleMessage(jsonDecode(data as String), authToken),
        onDone: () {
          _isConnected = false;
          _scheduleReconnect(authToken);
        },
        onError: (e) {
          _isConnected = false;
          _scheduleReconnect(authToken);
        },
      );

      // Bağlantı canlı tutucu ping (30 saniyede bir)
      _pingTimer = Timer.periodic(const Duration(seconds: 30), (_) {
        if (_isConnected) _send({'event': 'pusher:ping', 'data': {}});
      });
    } catch (e) {
      _scheduleReconnect(authToken);
    }
  }

  /// Private kanala abone ol (private-order.{id} gibi)
  Future<Stream<Map<String, dynamic>>> subscribePrivate(
    String channelName,
    String authToken,
  ) async {
    _channelControllers[channelName] ??= StreamController.broadcast();

    final authData = await _authenticate(channelName, authToken);

    _send({
      'event': 'pusher:subscribe',
      'data': {
        'channel': channelName,
        'auth': authData,
      },
    });

    return _channelControllers[channelName]!.stream;
  }

  /// Public kanala abone ol
  Stream<Map<String, dynamic>> subscribe(String channelName) {
    _channelControllers[channelName] ??= StreamController.broadcast();

    _send({
      'event': 'pusher:subscribe',
      'data': {'channel': channelName},
    });

    return _channelControllers[channelName]!.stream;
  }

  /// Kanaldan çık
  void unsubscribe(String channelName) {
    _send({
      'event': 'pusher:unsubscribe',
      'data': {'channel': channelName},
    });
    _channelControllers[channelName]?.close();
    _channelControllers.remove(channelName);
  }

  /// Bağlantıyı kapat
  void disconnect() {
    _pingTimer?.cancel();
    _channel?.sink.close();
    _isConnected = false;
    for (final ctrl in _channelControllers.values) {
      ctrl.close();
    }
    _channelControllers.clear();
  }

  // ─── Dahili ────────────────────────────────────────────────────────────────

  void _send(Map<String, dynamic> data) {
    try {
      _channel?.sink.add(jsonEncode(data));
    } catch (_) {}
  }

  void _handleMessage(Map<String, dynamic> msg, String authToken) {
    final event = msg['event'] as String?;
    final channel = msg['channel'] as String?;

    switch (event) {
      case 'pusher:connection_established':
        _isConnected = true;
        final data = jsonDecode(msg['data'] as String);
        _socketId = (data['socket_id'] as String).hashCode;

      case 'pusher:pong':
        break; // bağlantı canlı

      case 'pusher_internal:subscription_succeeded':
        break; // abone olundu

      default:
        if (channel != null && _channelControllers.containsKey(channel)) {
          final rawData = msg['data'];
          final parsedData = rawData is String
              ? jsonDecode(rawData) as Map<String, dynamic>
              : rawData as Map<String, dynamic>;

          _channelControllers[channel]!.add({
            'event': event,
            'data': parsedData,
          });
        }
    }
  }

  /// Reverb private kanal kimlik doğrulaması
  Future<String> _authenticate(String channel, String token) async {
    // HMAC-SHA256 imzalama
    final key = utf8.encode(AppConstants.wsSecret);
    final message = utf8.encode('$_socketId:$channel');
    final hmac = Hmac(sha256, key);
    final digest = hmac.convert(message);

    return '${AppConstants.wsKey}:${digest.toString()}';
  }

  Timer? _reconnectTimer;
  void _scheduleReconnect(String token) {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 5), () => connect(token));
  }
}

final webSocketServiceProvider = Provider<WebSocketService>((ref) {
  final service = WebSocketService();
  ref.onDispose(service.disconnect);
  return service;
});
