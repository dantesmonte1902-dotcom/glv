// mobile/ios/Runner/AppDelegate.swift

import UIKit
import Flutter
import Stripe

@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    GeneratedPluginRegistrant.register(with: self)

    // Stripe publishable key Flutter tarafında ayarlanıyor (Stripe.publishableKey)
    // bu satıra gerek yok ama native bir Stripe çağrısı gerekirse buraya eklenir.

    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
