<?php

namespace App\Filament\Admin\Widgets;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Models\Restaurant;
use App\Models\User;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class StatsOverview extends BaseWidget
{
    protected static ?int $sort = 1;

    protected function getStats(): array
    {
        $todayOrders = Order::whereDate('created_at', today())->count();
        $todayRevenue = Order::whereDate('created_at', today())
            ->where('payment_status', 'paid')
            ->sum('total_amount');

        $pendingOrders = Order::where('status', OrderStatus::PENDING_RESTAURANT_APPROVAL)->count();
        $activeRestaurants = Restaurant::where('is_active', true)->count();

        return [
            Stat::make('Bugünkü Siparişler', $todayOrders)
                ->description('Son 24 saat')
                ->descriptionIcon('heroicon-m-shopping-bag')
                ->color('primary'),

            Stat::make('Bugünkü Gelir', number_format($todayRevenue, 2) . ' KM')
                ->description('Ödenen siparişler')
                ->descriptionIcon('heroicon-m-currency-dollar')
                ->color('success'),

            Stat::make('Bekleyen Siparişler', $pendingOrders)
                ->description('Restoran onayı bekliyor')
                ->descriptionIcon('heroicon-m-clock')
                ->color('warning'),

            Stat::make('Aktif Restoranlar', $activeRestaurants)
                ->description('Toplam aktif')
                ->descriptionIcon('heroicon-m-building-storefront')
                ->color('info'),
        ];
    }
}
