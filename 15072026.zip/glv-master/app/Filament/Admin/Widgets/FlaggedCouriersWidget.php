<?php

namespace App\Filament\Admin\Widgets;

use App\Services\Fraud\FraudSignalService;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class FlaggedCouriersWidget extends BaseWidget
{
    protected static ?string $heading = '⚠️ Yüksek Ret Oranlı Kuryeler (son 30 gün)';
    protected static ?int $sort = 6;
    protected int|string|array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            ->query(app(FraudSignalService::class)->flaggedCouriersQuery())
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('Kurye'),
                Tables\Columns\TextColumn::make('phone')->label('Telefon'),
                Tables\Columns\TextColumn::make('total_offers_count')->label('Toplam Teklif')->alignCenter(),
                Tables\Columns\TextColumn::make('rejected_offers_count')->label('Reddedilen')->alignCenter()->color('warning'),
                Tables\Columns\TextColumn::make('rejection_rate')->label('Ret Oranı')->badge()->color('danger')->suffix('%'),
            ])
            ->paginated([5, 10, 25])
            ->emptyStateHeading('Şu an işaretlenen kurye yok')
            ->emptyStateIcon('heroicon-o-shield-check');
    }
}
