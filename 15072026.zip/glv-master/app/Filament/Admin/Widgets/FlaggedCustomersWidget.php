<?php

namespace App\Filament\Admin\Widgets;

use App\Services\Fraud\FraudSignalService;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class FlaggedCustomersWidget extends BaseWidget
{
    protected static ?string $heading = '⚠️ Riskli Müşteriler (son 30 gün)';
    protected static ?int $sort = 5;
    protected int|string|array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            ->query(app(FraudSignalService::class)->flaggedCustomersQuery())
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('Müşteri'),
                Tables\Columns\TextColumn::make('phone')->label('Telefon'),
                Tables\Columns\TextColumn::make('total_orders_count')->label('Toplam Sipariş')->alignCenter(),
                Tables\Columns\TextColumn::make('cancelled_orders_count')->label('İptal')->alignCenter()->color('warning'),
                Tables\Columns\TextColumn::make('disputes_count')->label('İtiraz')->alignCenter()->color('danger'),
                Tables\Columns\TextColumn::make('risk_score')->label('Risk Skoru')->badge()->color('danger'),
            ])
            ->paginated([5, 10, 25])
            ->emptyStateHeading('Şu an işaretlenen riskli müşteri yok')
            ->emptyStateIcon('heroicon-o-shield-check');
    }
}
