<?php

namespace App\Filament\Admin\Resources;

use App\Filament\Admin\Resources\ReviewResource\Pages;
use App\Models\Review;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class ReviewResource extends Resource
{
    protected static ?string $model = Review::class;
    protected static ?string $navigationIcon = 'heroicon-o-star';
    protected static ?string $navigationLabel = 'Değerlendirmeler';
    protected static ?string $modelLabel = 'Değerlendirme';
    protected static ?string $pluralModelLabel = 'Değerlendirmeler';
    protected static ?int $navigationSort = 6;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Değerlendirme Bilgileri')->schema([
                Forms\Components\TextInput::make('customer.name')->label('Müşteri')->disabled(),
                Forms\Components\TextInput::make('branch.name')->label('Şube')->disabled(),
                Forms\Components\TextInput::make('food_rating')->label('Yemek Puanı')->disabled()->suffix('/ 5'),
                Forms\Components\TextInput::make('delivery_rating')->label('Teslimat Puanı')->disabled()->suffix('/ 5'),
                Forms\Components\Textarea::make('comment')->label('Yorum')->disabled(),
                Forms\Components\Toggle::make('is_visible')->label('Görünür'),
            ])->columns(2),

            Forms\Components\Section::make('Restoran Yanıtı')->schema([
                Forms\Components\Textarea::make('reply')->label('Yanıt')->maxLength(1000),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                Tables\Columns\TextColumn::make('id')->label('#')->sortable(),
                Tables\Columns\TextColumn::make('customer.name')->label('Müşteri')->searchable(),
                Tables\Columns\TextColumn::make('branch.restaurant.name')->label('Restoran'),
                Tables\Columns\TextColumn::make('branch.name')->label('Şube'),
                Tables\Columns\TextColumn::make('food_rating')
                    ->label('Yemek')
                    ->formatStateUsing(fn ($s) => str_repeat('⭐', $s)),
                Tables\Columns\TextColumn::make('delivery_rating')
                    ->label('Teslimat')
                    ->formatStateUsing(fn ($s) => str_repeat('⭐', $s)),
                Tables\Columns\TextColumn::make('comment')
                    ->label('Yorum')
                    ->limit(60)
                    ->wrap(),
                Tables\Columns\IconColumn::make('is_visible')->label('Görünür')->boolean(),
                Tables\Columns\IconColumn::make('reply')
                    ->label('Yanıt')
                    ->boolean()
                    ->getStateUsing(fn ($record) => ! empty($record->reply)),
                Tables\Columns\TextColumn::make('created_at')->label('Tarih')->dateTime('d.m.Y')->sortable(),
            ])
            ->filters([
                Tables\Filters\TernaryFilter::make('is_visible')->label('Görünürlük'),
                Tables\Filters\Filter::make('no_reply')
                    ->label('Yanıtsızlar')
                    ->query(fn ($q) => $q->whereNull('reply')),
                Tables\Filters\SelectFilter::make('food_rating')
                    ->label('Yemek Puanı')
                    ->options([1 => '1★', 2 => '2★', 3 => '3★', 4 => '4★', 5 => '5★']),
            ])
            ->actions([
                Tables\Actions\EditAction::make()->label('Düzenle'),
                Tables\Actions\Action::make('toggle_visibility')
                    ->label(fn (Review $r) => $r->is_visible ? 'Gizle' : 'Göster')
                    ->icon(fn (Review $r) => $r->is_visible ? 'heroicon-o-eye-slash' : 'heroicon-o-eye')
                    ->color(fn (Review $r) => $r->is_visible ? 'danger' : 'success')
                    ->action(function (Review $review) {
                        app(\App\Services\Review\ReviewService::class)->toggleVisibility($review);
                    })
                    ->requiresConfirmation(),
            ])
            ->bulkActions([
                Tables\Actions\BulkAction::make('hide_selected')
                    ->label('Seçilenleri Gizle')
                    ->icon('heroicon-o-eye-slash')
                    ->action(fn ($records) => $records->each(fn ($r) => $r->update(['is_visible' => false]))),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListReviews::route('/'),
            'edit' => Pages\EditReview::route('/{record}/edit'),
        ];
    }
}
