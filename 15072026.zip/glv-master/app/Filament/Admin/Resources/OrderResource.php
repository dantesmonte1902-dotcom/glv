<?php

namespace App\Filament\Admin\Resources;

use App\Enums\OrderStatus;
use App\Filament\Admin\Resources\OrderResource\Pages;
use App\Models\Order;
use App\Services\Orders\OrderService;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class OrderResource extends Resource
{
    protected static ?string $model = Order::class;
    protected static ?string $navigationIcon = 'heroicon-o-shopping-bag';
    protected static ?string $navigationLabel = 'Siparişler';
    protected static ?string $modelLabel = 'Sipariş';
    protected static ?string $pluralModelLabel = 'Siparişler';
    protected static ?int $navigationSort = 3;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Sipariş Bilgileri')->schema([
                Forms\Components\TextInput::make('id')->label('Sipariş No')->disabled(),
                Forms\Components\TextInput::make('customer.name')->label('Müşteri')->disabled(),
                Forms\Components\TextInput::make('branch.name')->label('Şube')->disabled(),
                Forms\Components\TextInput::make('total_amount')->label('Toplam')->disabled()->suffix('KM'),
                Forms\Components\Select::make('status')
                    ->label('Durum')
                    ->options(collect(OrderStatus::cases())->mapWithKeys(
                        fn ($s) => [$s->value => $s->value]
                    ))
                    ->required(),
                Forms\Components\TextInput::make('payment_status')->label('Ödeme Durumu')->disabled(),
                Forms\Components\Textarea::make('notes')->label('Notlar'),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                Tables\Columns\TextColumn::make('id')
                    ->label('#')
                    ->sortable(),
                Tables\Columns\TextColumn::make('customer.name')
                    ->label('Müşteri')
                    ->searchable(),
                Tables\Columns\TextColumn::make('branch.restaurant.name')
                    ->label('Restoran'),
                Tables\Columns\TextColumn::make('branch.name')
                    ->label('Şube'),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Durum')
                    ->colors([
                        'warning' => OrderStatus::PENDING_RESTAURANT_APPROVAL->value,
                        'primary' => OrderStatus::SEARCHING_COURIER->value,
                        'info' => [OrderStatus::COURIER_ASSIGNED->value, OrderStatus::OUT_FOR_DELIVERY->value],
                        'success' => OrderStatus::DELIVERED->value,
                        'danger' => [OrderStatus::REJECTED->value, OrderStatus::CANCELLED->value],
                    ]),
                Tables\Columns\BadgeColumn::make('payment_status')
                    ->label('Ödeme')
                    ->colors([
                        'warning' => 'unpaid',
                        'success' => 'paid',
                        'danger' => 'refunded',
                    ]),
                Tables\Columns\TextColumn::make('payment_method')
                    ->label('Ödeme Yöntemi')
                    ->formatStateUsing(fn ($state) => $state?->label() ?? '-'),
                Tables\Columns\TextColumn::make('total_amount')
                    ->label('Toplam')
                    ->suffix(' KM')
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Tarih')
                    ->dateTime('d.m.Y H:i')
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->label('Durum')
                    ->options(collect(OrderStatus::cases())->mapWithKeys(fn ($s) => [$s->value => $s->value])),
                Tables\Filters\SelectFilter::make('payment_status')
                    ->label('Ödeme')
                    ->options(['unpaid' => 'Ödenmedi', 'paid' => 'Ödendi', 'refunded' => 'İade Edildi']),
                Tables\Filters\Filter::make('today')
                    ->label('Bugün')
                    ->query(fn (Builder $q) => $q->whereDate('created_at', today())),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make('approve')
                    ->label('Onayla')
                    ->icon('heroicon-o-check')
                    ->color('success')
                    ->visible(fn (Order $r) => $r->status === OrderStatus::PENDING_RESTAURANT_APPROVAL)
                    ->action(function (Order $record) {
                        app(OrderService::class)->approve(auth()->user(), $record);
                    })
                    ->requiresConfirmation(),
                Tables\Actions\Action::make('reject')
                    ->label('Reddet')
                    ->icon('heroicon-o-x-mark')
                    ->color('danger')
                    ->visible(fn (Order $r) => $r->status === OrderStatus::PENDING_RESTAURANT_APPROVAL)
                    ->form([
                        Forms\Components\Textarea::make('reason')->label('Red Nedeni')->required(),
                    ])
                    ->action(function (Order $record, array $data) {
                        app(OrderService::class)->reject(auth()->user(), $record, $data['reason']);
                    }),
            ])
            ->bulkActions([]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListOrders::route('/'),
            'view' => Pages\ViewOrder::route('/{record}'),
            'edit' => Pages\EditOrder::route('/{record}/edit'),
        ];
    }
}
