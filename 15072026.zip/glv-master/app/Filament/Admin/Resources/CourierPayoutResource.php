<?php

namespace App\Filament\Admin\Resources;

use App\Filament\Admin\Resources\CourierPayoutResource\Pages;
use App\Models\CourierPayout;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class CourierPayoutResource extends Resource
{
    protected static ?string $model = CourierPayout::class;
    protected static ?string $navigationIcon = 'heroicon-o-banknotes';
    protected static ?string $navigationLabel = 'Kurye Ödemeleri';
    protected static ?string $modelLabel = 'Kurye Ödemesi';
    protected static ?string $pluralModelLabel = 'Kurye Ödemeleri';
    protected static ?int $navigationSort = 7;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Ödeme Bilgileri')->schema([
                Forms\Components\TextInput::make('courier.name')->label('Kurye')->disabled(),
                Forms\Components\TextInput::make('period_start')->label('Dönem Başlangıç')->disabled(),
                Forms\Components\TextInput::make('period_end')->label('Dönem Bitiş')->disabled(),
                Forms\Components\TextInput::make('order_count')->label('Teslimat Sayısı')->disabled(),
                Forms\Components\TextInput::make('total_amount')->label('Toplam Tutar')->disabled()->suffix('KM'),
                Forms\Components\TextInput::make('notes')->label('Not'),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                Tables\Columns\TextColumn::make('id')->label('#')->sortable(),
                Tables\Columns\TextColumn::make('courier.name')->label('Kurye')->searchable(),
                Tables\Columns\TextColumn::make('period_start')->label('Başlangıç')->date('d.m.Y'),
                Tables\Columns\TextColumn::make('period_end')->label('Bitiş')->date('d.m.Y'),
                Tables\Columns\TextColumn::make('order_count')->label('Teslimat')->alignCenter(),
                Tables\Columns\TextColumn::make('total_amount')->label('Tutar')->money('BAM')->sortable(),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Durum')
                    ->formatStateUsing(fn ($state) => $state instanceof \App\Enums\CourierPayoutStatus ? $state->label() : $state)
                    ->colors([
                        'warning' => fn ($state) => ($state->value ?? $state) === 'pending',
                        'success' => fn ($state) => ($state->value ?? $state) === 'paid',
                    ]),
                Tables\Columns\TextColumn::make('paid_at')->label('Ödeme Tarihi')->dateTime('d.m.Y H:i'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->label('Durum')
                    ->options(['pending' => 'Bekliyor', 'paid' => 'Ödendi']),
            ])
            ->actions([
                Tables\Actions\Action::make('mark_paid')
                    ->label('Ödendi İşaretle')
                    ->icon('heroicon-o-check-circle')
                    ->color('success')
                    ->visible(fn (CourierPayout $record) => ($record->status->value ?? $record->status) === 'pending')
                    ->requiresConfirmation()
                    ->action(fn (CourierPayout $record) => app(\App\Services\Courier\CourierPayoutService::class)->markPaid($record)),
                Tables\Actions\ViewAction::make()->label('Görüntüle'),
            ])
            ->headerActions([
                Tables\Actions\Action::make('generate_batch')
                    ->label('Haftalık Ödeme Oluştur')
                    ->icon('heroicon-o-plus-circle')
                    ->form([
                        Forms\Components\DatePicker::make('period_start')
                            ->label('Dönem Başlangıç')
                            ->default(now()->subDays(7))
                            ->required(),
                        Forms\Components\DatePicker::make('period_end')
                            ->label('Dönem Bitiş')
                            ->default(now())
                            ->required(),
                    ])
                    ->action(function (array $data): void {
                        app(\App\Services\Courier\CourierPayoutService::class)->generateBatch(
                            \Illuminate\Support\Carbon::parse($data['period_start'])->startOfDay(),
                            \Illuminate\Support\Carbon::parse($data['period_end'])->endOfDay(),
                        );
                    })
                    ->requiresConfirmation()
                    ->modalDescription('Seçilen dönemdeki ödenmemiş tüm kurye kazançları, kurye başına gruplanıp ödeme kaydı oluşturulacak.'),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCourierPayouts::route('/'),
            'view' => Pages\ViewCourierPayout::route('/{record}'),
        ];
    }
}
