<?php

namespace App\Filament\Admin\Resources;

use App\Filament\Admin\Resources\CouponResource\Pages;
use App\Models\Coupon;
use App\Models\Restaurant;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class CouponResource extends Resource
{
    protected static ?string $model = Coupon::class;
    protected static ?string $navigationIcon = 'heroicon-o-tag';
    protected static ?string $navigationLabel = 'Kuponlar';
    protected static ?string $modelLabel = 'Kupon';
    protected static ?string $pluralModelLabel = 'Kuponlar';
    protected static ?int $navigationSort = 5;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Kupon Bilgileri')->schema([
                Forms\Components\TextInput::make('code')
                    ->label('Kupon Kodu')
                    ->required()
                    ->unique(ignoreRecord: true)
                    ->maxLength(50)
                    ->afterStateUpdated(fn ($set, $state) => $set('code', strtoupper($state)))
                    ->live(),
                Forms\Components\Select::make('type')
                    ->label('İndirim Türü')
                    ->options(['percentage' => 'Yüzde (%)', 'fixed' => 'Sabit Tutar (KM)'])
                    ->required(),
                Forms\Components\TextInput::make('value')
                    ->label('İndirim Değeri')
                    ->numeric()
                    ->required(),
                Forms\Components\TextInput::make('minimum_order_amount')
                    ->label('Min. Sipariş Tutarı (KM)')
                    ->numeric()
                    ->default(0),
                Forms\Components\TextInput::make('maximum_discount')
                    ->label('Max. İndirim (KM, yüzde türü için)')
                    ->numeric()
                    ->nullable(),
                Forms\Components\Select::make('restaurant_id')
                    ->label('Restoran (boş = tüm restoranlar)')
                    ->options(Restaurant::pluck('name', 'id'))
                    ->nullable()
                    ->searchable(),
                Forms\Components\TextInput::make('usage_limit')
                    ->label('Toplam Kullanım Limiti')
                    ->numeric()
                    ->nullable(),
                Forms\Components\TextInput::make('per_user_limit')
                    ->label('Kullanıcı Başı Limit')
                    ->numeric()
                    ->default(1),
                Forms\Components\DateTimePicker::make('starts_at')
                    ->label('Başlangıç Tarihi'),
                Forms\Components\DateTimePicker::make('expires_at')
                    ->label('Bitiş Tarihi'),
                Forms\Components\Toggle::make('is_active')
                    ->label('Aktif')
                    ->default(true),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('code')->label('Kod')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('type')->label('Tür')
                    ->formatStateUsing(fn ($s) => $s === 'percentage' ? 'Yüzde' : 'Sabit'),
                Tables\Columns\TextColumn::make('value')->label('Değer'),
                Tables\Columns\TextColumn::make('usage_count')->label('Kullanım')->sortable(),
                Tables\Columns\TextColumn::make('usage_limit')->label('Limit'),
                Tables\Columns\TextColumn::make('expires_at')->label('Bitiş')->dateTime('d.m.Y')->sortable(),
                Tables\Columns\IconColumn::make('is_active')->label('Aktif')->boolean(),
            ])
            ->filters([
                Tables\Filters\TernaryFilter::make('is_active')->label('Aktiflik'),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make('deactivate')
                    ->label('Pasife Al')
                    ->icon('heroicon-o-x-circle')
                    ->color('danger')
                    ->visible(fn (Coupon $r) => $r->is_active)
                    ->action(fn (Coupon $r) => $r->update(['is_active' => false]))
                    ->requiresConfirmation(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCoupons::route('/'),
            'create' => Pages\CreateCoupon::route('/create'),
            'edit' => Pages\EditCoupon::route('/{record}/edit'),
        ];
    }
}
