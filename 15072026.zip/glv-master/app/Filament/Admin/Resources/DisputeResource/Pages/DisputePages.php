<?php

namespace App\Filament\Admin\Resources\DisputeResource\Pages;

use App\Filament\Admin\Resources\DisputeResource;
use App\Models\Dispute;
use App\Services\Support\DisputeService;
use Filament\Resources\Pages\EditRecord;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Model;

class ListDisputes extends ListRecords
{
    protected static string $resource = DisputeResource::class;
}

class EditDispute extends EditRecord
{
    protected static string $resource = DisputeResource::class;

    /**
     * Standart Eloquent kaydetme yerine DisputeService::resolve() kullanılır,
     * çünkü çözüm tipi para iadesi veya puan telafisini otomatik tetikler.
     */
    protected function handleRecordUpdate(Model $record, array $data): Model
    {
        /** @var Dispute $record */
        if (($record->status->value ?? $record->status) === 'resolved') {
            return $record; // zaten çözülmüş, tekrar işlem yapma
        }

        return app(DisputeService::class)->resolve(auth()->user(), $record, $data);
    }
}
