<?php

namespace App\Filament\Admin\Resources\CourierPayoutResource\Pages;

use App\Filament\Admin\Resources\CourierPayoutResource;
use Filament\Resources\Pages\ListRecords;
use Filament\Resources\Pages\ViewRecord;

class ListCourierPayouts extends ListRecords
{
    protected static string $resource = CourierPayoutResource::class;

    protected function getHeaderActions(): array { return []; }
}

class ViewCourierPayout extends ViewRecord
{
    protected static string $resource = CourierPayoutResource::class;
}
