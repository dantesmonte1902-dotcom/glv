<?php

namespace App\Filament\Admin\Resources;

use App\Enums\SupportTicketStatus;
use App\Filament\Admin\Resources\SupportTicketResource\Pages;
use App\Filament\Admin\Resources\SupportTicketResource\RelationManagers\MessagesRelationManager;
use App\Models\SupportTicket;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class SupportTicketResource extends Resource
{
    protected static ?string $model = SupportTicket::class;
    protected static ?string $navigationIcon = 'heroicon-o-chat-bubble-left-right';
    protected static ?string $navigationLabel = 'Destek Talepleri';
    protected static ?string $modelLabel = 'Destek Talebi';
    protected static ?string $pluralModelLabel = 'Destek Talepleri';
    protected static ?int $navigationSort = 10;

    public static function getNavigationBadge(): ?string
    {
        $count = static::getModel()::where('status', SupportTicketStatus::OPEN)->count();

        return $count > 0 ? (string) $count : null;
    }

    public static function getNavigationBadgeColor(): ?string
    {
        return 'danger';
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('user.name')->label('Müşteri')->disabled(),
            Forms\Components\TextInput::make('subject')->label('Konu')->disabled(),
            Forms\Components\Select::make('status')
                ->label('Durum')
                ->options([
                    'open' => 'Açık',
                    'in_progress' => 'İşlemde',
                    'closed' => 'Kapalı',
                ])
                ->required(),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('last_message_at', 'desc')
            ->columns([
                Tables\Columns\TextColumn::make('id')->label('#')->sortable(),
                Tables\Columns\TextColumn::make('user.name')->label('Müşteri')->searchable(),
                Tables\Columns\TextColumn::make('subject')->label('Konu')->limit(40),
                Tables\Columns\TextColumn::make('order_id')->label('Sipariş #')->placeholder('—'),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Durum')
                    ->formatStateUsing(fn ($state) => $state instanceof SupportTicketStatus ? $state->label() : $state)
                    ->colors([
                        'danger' => fn ($state) => ($state->value ?? $state) === 'open',
                        'warning' => fn ($state) => ($state->value ?? $state) === 'in_progress',
                        'gray' => fn ($state) => ($state->value ?? $state) === 'closed',
                    ]),
                Tables\Columns\TextColumn::make('last_message_at')->label('Son Mesaj')->dateTime('d.m.Y H:i'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->label('Durum')
                    ->options(['open' => 'Açık', 'in_progress' => 'İşlemde', 'closed' => 'Kapalı']),
            ])
            ->actions([
                Tables\Actions\EditAction::make()->label('Yanıtla'),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            MessagesRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSupportTickets::route('/'),
            'edit' => Pages\EditSupportTicket::route('/{record}/edit'),
        ];
    }
}
