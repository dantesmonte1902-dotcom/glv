<?php

namespace App\Filament\Admin\Resources;

use App\Filament\Admin\Resources\RestaurantResource\Pages;
use App\Models\City;
use App\Models\Restaurant;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class RestaurantResource extends Resource
{
    protected static ?string $model = Restaurant::class;
    protected static ?string $navigationIcon = 'heroicon-o-building-storefront';
    protected static ?string $navigationLabel = 'Restoranlar';
    protected static ?string $modelLabel = 'Restoran';
    protected static ?string $pluralModelLabel = 'Restoranlar';
    protected static ?int $navigationSort = 2;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Genel Bilgiler')->schema([
                Forms\Components\TextInput::make('name')
                    ->label('Restoran Adı')
                    ->required()
                    ->maxLength(255),
                Forms\Components\TextInput::make('brand_slug')
                    ->label('Marka Slug')
                    ->required()
                    ->unique(ignoreRecord: true)
                    ->maxLength(100),
                Forms\Components\Toggle::make('is_active')
                    ->label('Aktif')
                    ->default(true),
            ])->columns(2),

            Forms\Components\Section::make('Şubeler')->schema([
                Forms\Components\Repeater::make('branches')
                    ->relationship()
                    ->label('Şubeler')
                    ->schema([
                        Forms\Components\Select::make('city_id')
                            ->label('Şehir')
                            ->options(City::pluck('name', 'id'))
                            ->required(),
                        Forms\Components\TextInput::make('name')
                            ->label('Şube Adı')
                            ->required(),
                        Forms\Components\TextInput::make('address')
                            ->label('Adres')
                            ->required(),
                        Forms\Components\TextInput::make('lat')
                            ->label('Enlem')
                            ->numeric(),
                        Forms\Components\TextInput::make('lng')
                            ->label('Boylam')
                            ->numeric(),
                        Forms\Components\TextInput::make('service_radius_km')
                            ->label('Hizmet Yarıçapı (km)')
                            ->numeric()
                            ->default(5),
                        Forms\Components\TextInput::make('minimum_order_amount')
                            ->label('Min. Sipariş (KM)')
                            ->numeric()
                            ->default(10),
                        Forms\Components\TextInput::make('estimated_delivery_minutes')
                            ->label('Tahmini Teslimat (dk)')
                            ->numeric()
                            ->default(30),
                        Forms\Components\TimePicker::make('opens_at')
                            ->label('Açılış Saati'),
                        Forms\Components\TimePicker::make('closes_at')
                            ->label('Kapanış Saati'),
                        Forms\Components\Toggle::make('is_active')
                            ->label('Aktif')
                            ->default(true),
                        Forms\Components\Toggle::make('is_open')
                            ->label('Şu An Açık')
                            ->default(false),
                    ])->columns(3)->collapsible(),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->label('Restoran')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('brand_slug')
                    ->label('Slug'),
                Tables\Columns\TextColumn::make('branches_count')
                    ->label('Şube Sayısı')
                    ->counts('branches'),
                Tables\Columns\IconColumn::make('is_active')
                    ->label('Aktif')
                    ->boolean(),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Oluşturulma')
                    ->dateTime('d.m.Y')
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\TernaryFilter::make('is_active')->label('Aktiflik'),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make('toggle_active')
                    ->label(fn (Restaurant $r) => $r->is_active ? 'Pasife Al' : 'Aktive Et')
                    ->icon(fn (Restaurant $r) => $r->is_active ? 'heroicon-o-x-circle' : 'heroicon-o-check-circle')
                    ->action(fn (Restaurant $r) => $r->update(['is_active' => ! $r->is_active]))
                    ->requiresConfirmation(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListRestaurants::route('/'),
            'create' => Pages\CreateRestaurant::route('/create'),
            'edit' => Pages\EditRestaurant::route('/{record}/edit'),
        ];
    }
}
