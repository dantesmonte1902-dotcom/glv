<?php

namespace App\Filament\Admin\Resources;

use App\Enums\DisputeStatus;
use App\Filament\Admin\Resources\DisputeResource\Pages;
use App\Models\Dispute;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class DisputeResource extends Resource
{
    protected static ?string $model = Dispute::class;
    protected static ?string $navigationIcon = 'heroicon-o-exclamation-triangle';
    protected static ?string $navigationLabel = 'İtirazlar';
    protected static ?string $modelLabel = 'İtiraz';
    protected static ?string $pluralModelLabel = 'İtirazlar';
    protected static ?int $navigationSort = 9;

    public static function getNavigationBadge(): ?string
    {
        $count = static::getModel()::where('status', DisputeStatus::OPEN)->count();

        return $count > 0 ? (string) $count : null;
    }

    public static function getNavigationBadgeColor(): ?string
    {
        return 'danger';
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('İtiraz Detayı')->schema([
                Forms\Components\TextInput::make('customer.name')->label('Müşteri')->disabled(),
                Forms\Components\TextInput::make('order_id')->label('Sipariş #')->disabled(),
                Forms\Components\TextInput::make('type')
                    ->label('Tür')
                    ->formatStateUsing(fn ($state) => $state instanceof \App\Enums\DisputeType ? $state->label() : $state)
                    ->disabled(),
                Forms\Components\Textarea::make('description')->label('Açıklama')->disabled()->rows(3),
                Forms\Components\FileUpload::make('photo_url')->label('Fotoğraf')->disabled()->image(),
            ])->columns(1),

            Forms\Components\Section::make('Çözüm')->schema([
                Forms\Components\Select::make('resolution_type')
                    ->label('Çözüm Tipi')
                    ->options([
                        'refund' => 'Para İadesi',
                        'compensate_points' => 'Puan Telafisi',
                        'none' => 'Telafi Yok (Reddet)',
                    ])
                    ->live()
                    ->required(),
                Forms\Components\TextInput::make('resolution_amount')
                    ->label('İade Tutarı (KM)')
                    ->numeric()
                    ->visible(fn (Forms\Get $get) => $get('resolution_type') === 'refund')
                    ->required(fn (Forms\Get $get) => $get('resolution_type') === 'refund'),
                Forms\Components\TextInput::make('resolution_points')
                    ->label('Telafi Puanı')
                    ->numeric()
                    ->visible(fn (Forms\Get $get) => $get('resolution_type') === 'compensate_points')
                    ->required(fn (Forms\Get $get) => $get('resolution_type') === 'compensate_points'),
                Forms\Components\Textarea::make('resolution_notes')
                    ->label('Müşteriye Not')
                    ->rows(2)
                    ->required(),
            ])->columns(1)->visible(fn (Dispute $record) => ($record->status->value ?? $record->status) !== 'resolved'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                Tables\Columns\TextColumn::make('id')->label('#')->sortable(),
                Tables\Columns\TextColumn::make('customer.name')->label('Müşteri')->searchable(),
                Tables\Columns\TextColumn::make('order_id')->label('Sipariş #'),
                Tables\Columns\TextColumn::make('type')
                    ->label('Tür')
                    ->formatStateUsing(fn ($state) => $state instanceof \App\Enums\DisputeType ? $state->label() : $state),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Durum')
                    ->formatStateUsing(fn ($state) => $state instanceof DisputeStatus ? $state->label() : $state)
                    ->colors([
                        'danger' => fn ($state) => ($state->value ?? $state) === 'open',
                        'warning' => fn ($state) => ($state->value ?? $state) === 'under_review',
                        'success' => fn ($state) => ($state->value ?? $state) === 'resolved',
                        'gray' => fn ($state) => ($state->value ?? $state) === 'rejected',
                    ]),
                Tables\Columns\TextColumn::make('created_at')->label('Açılış')->dateTime('d.m.Y H:i'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->label('Durum')
                    ->options([
                        'open' => 'Açık',
                        'under_review' => 'İnceleniyor',
                        'resolved' => 'Çözüldü',
                        'rejected' => 'Reddedildi',
                    ]),
            ])
            ->actions([
                Tables\Actions\EditAction::make()->label('İncele / Çöz'),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListDisputes::route('/'),
            'edit' => Pages\EditDispute::route('/{record}/edit'),
        ];
    }
}
