<?php

namespace App\Filament\Admin\Resources;

use App\Filament\Admin\Resources\CampaignResource\Pages;
use App\Models\Campaign;
use App\Models\City;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class CampaignResource extends Resource
{
    protected static ?string $model = Campaign::class;
    protected static ?string $navigationIcon = 'heroicon-o-megaphone';
    protected static ?string $navigationLabel = 'Kampanyalar';
    protected static ?string $modelLabel = 'Kampanya';
    protected static ?string $pluralModelLabel = 'Kampanyalar';
    protected static ?int $navigationSort = 8;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Kampanya')->schema([
                Forms\Components\TextInput::make('title')
                    ->label('Kampanya Adı (dahili)')
                    ->required()
                    ->maxLength(255),
                Forms\Components\TextInput::make('message_title')
                    ->label('Bildirim Başlığı')
                    ->required()
                    ->maxLength(255),
                Forms\Components\Textarea::make('message_body')
                    ->label('Bildirim Metni')
                    ->required()
                    ->maxLength(500)
                    ->rows(3),
            ])->columns(1),

            Forms\Components\Section::make('Hedef Kitle')->schema([
                Forms\Components\Select::make('segment_type')
                    ->label('Segment')
                    ->options([
                        'all' => 'Tüm Müşteriler',
                        'inactive_customers' => 'Uzun Süredir Sipariş Vermeyenler',
                        'city' => 'Belirli Şehir',
                    ])
                    ->default('all')
                    ->live()
                    ->required(),

                Forms\Components\Select::make('segment_params.city_id')
                    ->label('Şehir')
                    ->options(fn () => City::query()->pluck('name', 'id'))
                    ->visible(fn (Forms\Get $get) => $get('segment_type') === 'city')
                    ->required(fn (Forms\Get $get) => $get('segment_type') === 'city'),

                Forms\Components\TextInput::make('segment_params.inactive_days')
                    ->label('Kaç gündür sipariş vermeyenler')
                    ->numeric()
                    ->default(30)
                    ->visible(fn (Forms\Get $get) => $get('segment_type') === 'inactive_customers'),
            ])->columns(1),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                Tables\Columns\TextColumn::make('title')->label('Kampanya')->searchable(),
                Tables\Columns\TextColumn::make('segment_type')
                    ->label('Segment')
                    ->formatStateUsing(fn ($state) => $state instanceof \App\Enums\CampaignSegmentType ? $state->label() : $state),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Durum')
                    ->formatStateUsing(fn ($state) => $state instanceof \App\Enums\CampaignStatus ? $state->label() : $state)
                    ->colors([
                        'gray' => fn ($state) => ($state->value ?? $state) === 'draft',
                        'success' => fn ($state) => ($state->value ?? $state) === 'sent',
                    ]),
                Tables\Columns\TextColumn::make('recipient_count')->label('Alıcı Sayısı')->alignCenter(),
                Tables\Columns\TextColumn::make('sent_at')->label('Gönderim Tarihi')->dateTime('d.m.Y H:i'),
            ])
            ->actions([
                Tables\Actions\Action::make('send')
                    ->label('Gönder')
                    ->icon('heroicon-o-paper-airplane')
                    ->color('success')
                    ->visible(fn (Campaign $record) => ($record->status->value ?? $record->status) === 'draft')
                    ->requiresConfirmation()
                    ->modalDescription('Bu kampanya, seçilen segmentteki tüm müşterilere anlık push bildirimi olarak gönderilecek. Bu işlem geri alınamaz.')
                    ->action(fn (Campaign $record) => app(\App\Services\Campaign\CampaignService::class)->send($record)),
                Tables\Actions\EditAction::make()
                    ->visible(fn (Campaign $record) => ($record->status->value ?? $record->status) === 'draft'),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()->label('Yeni Kampanya'),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCampaigns::route('/'),
            'create' => Pages\CreateCampaign::route('/create'),
            'edit' => Pages\EditCampaign::route('/{record}/edit'),
        ];
    }
}
