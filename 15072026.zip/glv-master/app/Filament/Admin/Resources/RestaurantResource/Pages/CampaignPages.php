<?php

namespace App\Filament\Admin\Resources\CampaignResource\Pages;

use App\Filament\Admin\Resources\CampaignResource;
use Filament\Resources\Pages\CreateRecord;
use Filament\Resources\Pages\EditRecord;
use Filament\Resources\Pages\ListRecords;

class ListCampaigns extends ListRecords
{
    protected static string $resource = CampaignResource::class;
}

class CreateCampaign extends CreateRecord
{
    protected static string $resource = CampaignResource::class;
}

class EditCampaign extends EditRecord
{
    protected static string $resource = CampaignResource::class;
}
