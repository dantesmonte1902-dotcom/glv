<?php

namespace App\Filament\Admin\Resources\SupportTicketResource\RelationManagers;

use App\Models\SupportMessage;
use App\Models\SupportTicket;
use App\Services\Support\SupportService;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;

class MessagesRelationManager extends RelationManager
{
    protected static string $relationship = 'messages';
    protected static ?string $title = 'Mesajlar';
    protected static ?string $modelLabel = 'Mesaj';

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Textarea::make('message')
                ->label('Yanıtınız')
                ->required()
                ->rows(4)
                ->columnSpanFull(),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('message')
            ->defaultSort('created_at', 'asc')
            ->columns([
                Tables\Columns\IconColumn::make('is_staff')
                    ->label('Kimden')
                    ->boolean()
                    ->trueIcon('heroicon-o-headset')
                    ->falseIcon('heroicon-o-user')
                    ->trueColor('primary')
                    ->falseColor('gray'),
                Tables\Columns\TextColumn::make('sender.name')->label('Gönderen'),
                Tables\Columns\TextColumn::make('message')->label('Mesaj')->wrap(),
                Tables\Columns\TextColumn::make('created_at')->label('Zaman')->dateTime('d.m.Y H:i'),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()
                    ->label('Yanıt Gönder')
                    ->using(function (array $data): SupportMessage {
                        /** @var SupportTicket $ticket */
                        $ticket = $this->getOwnerRecord();

                        return app(SupportService::class)->postMessage(
                            auth()->user(),
                            $ticket,
                            $data['message'],
                            isStaff: true,
                        );
                    }),
            ])
            ->actions([]);
    }
}
