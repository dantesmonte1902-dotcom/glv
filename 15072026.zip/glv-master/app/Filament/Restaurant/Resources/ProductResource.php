<?php

namespace App\Filament\Restaurant\Resources;

use App\Filament\Restaurant\Resources\ProductResource\Pages;
use App\Models\MenuCategory;
use App\Models\Product;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;
    protected static ?string $navigationIcon = 'heroicon-o-cube';
    protected static ?string $navigationLabel = 'Ürünler';
    protected static ?string $modelLabel = 'Ürün';
    protected static ?string $pluralModelLabel = 'Ürünler';
    protected static ?int $navigationSort = 3;

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->where('restaurant_id', auth()->user()->restaurant_id)
            ->with(['category', 'optionGroups.options'])
            ->orderBy('sort_order');
    }

    public static function form(Form $form): Form
    {
        $restaurantId = auth()->user()->restaurant_id;

        return $form->schema([
            Forms\Components\Section::make('Ürün Bilgileri')->schema([
                Forms\Components\Select::make('menu_category_id')
                    ->label('Kategori')
                    ->options(
                        MenuCategory::where('restaurant_id', $restaurantId)
                            ->where('is_active', true)
                            ->pluck('name', 'id')
                    )
                    ->required(),
                Forms\Components\TextInput::make('name')
                    ->label('Ürün Adı')
                    ->required()
                    ->maxLength(255)
                    ->live()
                    ->afterStateUpdated(fn ($set, $state) => $set('slug', Str::slug($state))),
                Forms\Components\TextInput::make('slug')
                    ->label('Slug')
                    ->required(),
                Forms\Components\Textarea::make('description')
                    ->label('Açıklama')
                    ->maxLength(2000)
                    ->columnSpanFull(),
                Forms\Components\TextInput::make('base_price')
                    ->label('Taban Fiyat (KM)')
                    ->numeric()
                    ->required(),
                Forms\Components\TextInput::make('preparation_time_minutes')
                    ->label('Hazırlık Süresi (dk)')
                    ->numeric()
                    ->default(15),
                Forms\Components\TextInput::make('sort_order')
                    ->label('Sıralama')
                    ->numeric()
                    ->default(0),
                Forms\Components\Toggle::make('is_available')
                    ->label('Müsait')
                    ->default(true),
                Forms\Components\Toggle::make('is_active')
                    ->label('Aktif')
                    ->default(true),
            ])->columns(2),

            Forms\Components\Section::make('Seçenek Grupları')->schema([
                Forms\Components\Repeater::make('optionGroups')
                    ->relationship()
                    ->label('Seçenek Grupları')
                    ->schema([
                        Forms\Components\TextInput::make('name')
                            ->label('Grup Adı (örn: Boy Seçimi)')
                            ->required(),
                        Forms\Components\Toggle::make('is_required')
                            ->label('Zorunlu'),
                        Forms\Components\Toggle::make('is_multiple')
                            ->label('Çoklu Seçim'),
                        Forms\Components\TextInput::make('min_selections')
                            ->label('Min. Seçim')
                            ->numeric()
                            ->default(0),
                        Forms\Components\TextInput::make('max_selections')
                            ->label('Max. Seçim')
                            ->numeric()
                            ->default(1),
                        Forms\Components\TextInput::make('sort_order')
                            ->label('Sıra')
                            ->numeric()
                            ->default(0),

                        Forms\Components\Repeater::make('options')
                            ->relationship()
                            ->label('Seçenekler')
                            ->schema([
                                Forms\Components\TextInput::make('name')
                                    ->label('Seçenek Adı')
                                    ->required(),
                                Forms\Components\TextInput::make('price_modifier')
                                    ->label('Fiyat Farkı (KM)')
                                    ->numeric()
                                    ->default(0),
                                Forms\Components\Toggle::make('is_default')
                                    ->label('Varsayılan'),
                                Forms\Components\Toggle::make('is_active')
                                    ->label('Aktif')
                                    ->default(true),
                                Forms\Components\TextInput::make('sort_order')
                                    ->label('Sıra')
                                    ->numeric()
                                    ->default(0),
                            ])->columns(3)->collapsible(),
                    ])->collapsible()->columns(3),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('Ürün')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('category.name')->label('Kategori'),
                Tables\Columns\TextColumn::make('base_price')->label('Fiyat')->suffix(' KM')->sortable(),
                Tables\Columns\TextColumn::make('preparation_time_minutes')->label('Hazırlık (dk)'),
                Tables\Columns\IconColumn::make('is_available')->label('Müsait')->boolean(),
                Tables\Columns\IconColumn::make('is_active')->label('Aktif')->boolean(),
                Tables\Columns\TextColumn::make('sort_order')->label('Sıra')->sortable(),
            ])
            ->reorderable('sort_order')
            ->filters([
                Tables\Filters\SelectFilter::make('menu_category_id')
                    ->label('Kategori')
                    ->options(
                        MenuCategory::where('restaurant_id', auth()->user()?->restaurant_id)
                            ->pluck('name', 'id')
                    ),
                Tables\Filters\TernaryFilter::make('is_available')->label('Müsaitlik'),
                Tables\Filters\TernaryFilter::make('is_active')->label('Aktiflik'),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make('toggle_available')
                    ->label(fn (Product $r) => $r->is_available ? 'Müsait Değil' : 'Müsait Et')
                    ->icon(fn (Product $r) => $r->is_available ? 'heroicon-o-eye-slash' : 'heroicon-o-eye')
                    ->action(fn (Product $r) => $r->update(['is_available' => ! $r->is_available])),
            ]);
    }

    public static function mutateFormDataBeforeCreate(array $data): array
    {
        $data['restaurant_id'] = auth()->user()->restaurant_id;

        return $data;
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit' => Pages\EditProduct::route('/{record}/edit'),
        ];
    }
}
