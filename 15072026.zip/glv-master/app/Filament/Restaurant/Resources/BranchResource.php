<?php

namespace App\Filament\Restaurant\Resources;

use App\Filament\Restaurant\Resources\BranchResource\Pages;
use App\Models\RestaurantBranch;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class BranchResource extends Resource
{
    protected static ?string $model = RestaurantBranch::class;
    protected static ?string $navigationIcon = 'heroicon-o-map-pin';
    protected static ?string $navigationLabel = 'Şubeler';
    protected static ?string $modelLabel = 'Şube';
    protected static ?string $pluralModelLabel = 'Şubeler';
    protected static ?int $navigationSort = 4;

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->where('restaurant_id', auth()->user()->restaurant_id);
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Şube Bilgileri')->schema([
                Forms\Components\TextInput::make('name')->label('Şube Adı')->required(),
                Forms\Components\TextInput::make('address')->label('Adres')->required(),
                Forms\Components\TextInput::make('lat')->label('Enlem')->numeric(),
                Forms\Components\TextInput::make('lng')->label('Boylam')->numeric(),
                Forms\Components\TextInput::make('service_radius_km')
                    ->label('Hizmet Yarıçapı (km)')->numeric()->default(5),
                Forms\Components\TextInput::make('minimum_order_amount')
                    ->label('Min. Sipariş (KM)')->numeric()->default(10),
                Forms\Components\TextInput::make('estimated_delivery_minutes')
                    ->label('Tahmini Teslimat (dk)')->numeric()->default(30),
                Forms\Components\TimePicker::make('opens_at')->label('Açılış Saati'),
                Forms\Components\TimePicker::make('closes_at')->label('Kapanış Saati'),
                Forms\Components\Toggle::make('is_open')->label('Şu An Açık')->default(false),
                Forms\Components\Toggle::make('is_active')->label('Aktif')->default(true),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('Şube'),
                Tables\Columns\TextColumn::make('city.name')->label('Şehir'),
                Tables\Columns\TextColumn::make('opens_at')->label('Açılış'),
                Tables\Columns\TextColumn::make('closes_at')->label('Kapanış'),
                Tables\Columns\TextColumn::make('minimum_order_amount')->label('Min. Sipariş')->suffix(' KM'),
                Tables\Columns\IconColumn::make('is_open')->label('Açık')->boolean(),
                Tables\Columns\IconColumn::make('is_active')->label('Aktif')->boolean(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make('toggle_open')
                    ->label(fn (RestaurantBranch $r) => $r->is_open ? 'Kapat' : 'Aç')
                    ->icon(fn (RestaurantBranch $r) => $r->is_open ? 'heroicon-o-lock-closed' : 'heroicon-o-lock-open')
                    ->color(fn (RestaurantBranch $r) => $r->is_open ? 'danger' : 'success')
                    ->action(fn (RestaurantBranch $r) => $r->update(['is_open' => ! $r->is_open]))
                    ->requiresConfirmation(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListBranches::route('/'),
            'edit' => Pages\EditBranch::route('/{record}/edit'),
        ];
    }
}
