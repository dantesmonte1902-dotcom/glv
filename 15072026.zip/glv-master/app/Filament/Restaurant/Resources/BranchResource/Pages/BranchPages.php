<?php

namespace App\Filament\Restaurant\Resources\BranchResource\Pages;

use App\Filament\Restaurant\Resources\BranchResource;
use Filament\Resources\Pages\EditRecord;
use Filament\Resources\Pages\ListRecords;

class ListBranches extends ListRecords
{
    protected static string $resource = BranchResource::class;

    protected function getHeaderActions(): array { return []; }
}

class EditBranch extends EditRecord
{
    protected static string $resource = BranchResource::class;
}
