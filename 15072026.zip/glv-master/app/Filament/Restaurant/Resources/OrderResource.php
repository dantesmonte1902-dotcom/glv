<?php

namespace App\Filament\Restaurant\Resources;

use App\Enums\OrderStatus;
use App\Filament\Restaurant\Resources\OrderResource\Pages;
use App\Models\Order;
use App\Services\Orders\OrderService;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class OrderResource extends Resource
{
    protected static ?string $model = Order::class;
    protected static ?string $navigationIcon = 'heroicon-o-shopping-bag';
    protected static ?string $navigationLabel = 'Siparişler';
    protected static ?string $modelLabel = 'Sipariş';
    protected static ?string $pluralModelLabel = 'Siparişler';
    protected static ?int $navigationSort = 1;

    // Sadece bu restoranın şubelerine ait siparişler
    public static function getEloquentQuery(): Builder
    {
        $user = auth()->user();

        return parent::getEloquentQuery()
            ->whereHas('branch', fn (Builder $q) =>
                $q->where('restaurant_id', $user->restaurant_id)
            )
            ->with(['customer', 'branch', 'items', 'latestPayment'])
            ->latest();
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Sipariş Detayı')->schema([
                Forms\Components\TextInput::make('id')->label('Sipariş No')->disabled(),
                Forms\Components\TextInput::make('customer.name')->label('Müşteri')->disabled(),
                Forms\Components\TextInput::make('delivery_address')->label('Teslimat Adresi')->disabled(),
                Forms\Components\TextInput::make('total_amount')->label('Toplam')->disabled()->suffix('KM'),
                Forms\Components\TextInput::make('payment_method')->label('Ödeme Yöntemi')->disabled(),
                Forms\Components\Textarea::make('notes')->label('Notlar')->disabled(),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->poll('15s') // 15 saniyede bir otomatik yenile
            ->columns([
                Tables\Columns\TextColumn::make('id')->label('#')->sortable(),
                Tables\Columns\TextColumn::make('customer.name')->label('Müşteri'),
                Tables\Columns\TextColumn::make('branch.name')->label('Şube'),
                Tables\Columns\TextColumn::make('items_count')
                    ->label('Ürün')
                    ->counts('items'),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Durum')
                    ->colors([
                        'warning' => OrderStatus::PENDING_RESTAURANT_APPROVAL->value,
                        'primary' => OrderStatus::SEARCHING_COURIER->value,
                        'info' => [OrderStatus::COURIER_ASSIGNED->value, OrderStatus::OUT_FOR_DELIVERY->value],
                        'success' => OrderStatus::DELIVERED->value,
                        'danger' => [OrderStatus::REJECTED->value, OrderStatus::CANCELLED->value],
                    ]),
                Tables\Columns\TextColumn::make('total_amount')->label('Toplam')->suffix(' KM'),
                Tables\Columns\TextColumn::make('created_at')->label('Saat')->dateTime('H:i')->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->label('Durum')
                    ->options(collect(OrderStatus::cases())->mapWithKeys(fn ($s) => [$s->value => $s->value])),
                Tables\Filters\Filter::make('today')
                    ->label('Sadece Bugün')
                    ->default()
                    ->query(fn (Builder $q) => $q->whereDate('created_at', today())),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\Action::make('approve')
                    ->label('Onayla')
                    ->icon('heroicon-o-check-circle')
                    ->color('success')
                    ->visible(fn (Order $r) => $r->status === OrderStatus::PENDING_RESTAURANT_APPROVAL)
                    ->action(fn (Order $record) => app(OrderService::class)->approve(auth()->user(), $record))
                    ->requiresConfirmation(),
                Tables\Actions\Action::make('reject')
                    ->label('Reddet')
                    ->icon('heroicon-o-x-circle')
                    ->color('danger')
                    ->visible(fn (Order $r) => $r->status === OrderStatus::PENDING_RESTAURANT_APPROVAL)
                    ->form([
                        Forms\Components\Textarea::make('reason')->label('Red Nedeni')->required(),
                    ])
                    ->action(function (Order $record, array $data) {
                        app(OrderService::class)->reject(auth()->user(), $record, $data['reason']);
                    }),
            ])
            ->bulkActions([]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListRestaurantOrders::route('/'),
            'view' => Pages\ViewRestaurantOrder::route('/{record}'),
        ];
    }
}
