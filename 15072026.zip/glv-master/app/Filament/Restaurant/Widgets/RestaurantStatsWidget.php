<?php

namespace App\Filament\Restaurant\Widgets;

use App\Enums\OrderStatus;
use App\Models\Order;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use Illuminate\Database\Eloquent\Builder;

class RestaurantStatsWidget extends BaseWidget
{
    protected static ?int $sort = 1;

    protected function getStats(): array
    {
        $restaurantId = auth()->user()->restaurant_id;

        $baseQuery = fn () => Order::whereHas('branch', fn (Builder $q) =>
            $q->where('restaurant_id', $restaurantId)
        );

        $todayOrders = $baseQuery()->whereDate('created_at', today())->count();

        $todayRevenue = $baseQuery()
            ->whereDate('created_at', today())
            ->where('payment_status', 'paid')
            ->sum('total_amount');

        $pending = $baseQuery()
            ->where('status', OrderStatus::PENDING_RESTAURANT_APPROVAL)
            ->count();

        $monthRevenue = $baseQuery()
            ->whereMonth('created_at', now()->month)
            ->whereYear('created_at', now()->year)
            ->where('payment_status', 'paid')
            ->sum('total_amount');

        return [
            Stat::make('Bugünkü Siparişler', $todayOrders)
                ->description('Toplam sipariş')
                ->color('primary'),

            Stat::make('Bugünkü Kazanç', number_format($todayRevenue, 2) . ' KM')
                ->description('Ödenen siparişler')
                ->color('success'),

            Stat::make('Bekleyen', $pending)
                ->description('Onay bekliyor')
                ->color('warning'),

            Stat::make('Bu Ay', number_format($monthRevenue, 2) . ' KM')
                ->description(now()->format('F Y'))
                ->color('info'),
        ];
    }
}
