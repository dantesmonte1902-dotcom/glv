<?php

namespace App\Filament\Restaurant\Widgets;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Services\Orders\OrderService;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;
use Illuminate\Database\Eloquent\Builder;

class ActiveOrdersWidget extends BaseWidget
{
    protected static ?int $sort = 2;
    protected static ?string $heading = 'Bekleyen Siparişler';
    protected int|string|array $columnSpan = 'full';
    protected static bool $isLazy = false;

    // 20 saniyede bir otomatik yenile
    protected static ?string $pollingInterval = '20s';

    public function table(Table $table): Table
    {
        $restaurantId = auth()->user()->restaurant_id;

        return $table
            ->query(
                Order::query()
                    ->whereHas('branch', fn (Builder $q) =>
                        $q->where('restaurant_id', $restaurantId)
                    )
                    ->where('status', OrderStatus::PENDING_RESTAURANT_APPROVAL)
                    ->with(['customer', 'items'])
                    ->latest()
            )
            ->columns([
                Tables\Columns\TextColumn::make('id')->label('#'),
                Tables\Columns\TextColumn::make('customer.name')->label('Müşteri'),
                Tables\Columns\TextColumn::make('items_count')
                    ->label('Ürün')
                    ->counts('items'),
                Tables\Columns\TextColumn::make('total_amount')->label('Toplam')->suffix(' KM'),
                Tables\Columns\TextColumn::make('payment_method')
                    ->label('Ödeme')
                    ->formatStateUsing(fn ($s) => $s?->label() ?? '-'),
                Tables\Columns\TextColumn::make('created_at')->label('Geldi')->since(),
            ])
            ->actions([
                Tables\Actions\Action::make('approve')
                    ->label('Onayla')
                    ->icon('heroicon-o-check-circle')
                    ->color('success')
                    ->action(fn (Order $record) => app(OrderService::class)->approve(auth()->user(), $record))
                    ->requiresConfirmation(),
                Tables\Actions\Action::make('reject')
                    ->label('Reddet')
                    ->icon('heroicon-o-x-circle')
                    ->color('danger')
                    ->form([
                        \Filament\Forms\Components\Textarea::make('reason')->label('Red Nedeni')->required(),
                    ])
                    ->action(function (Order $record, array $data) {
                        app(OrderService::class)->reject(auth()->user(), $record, $data['reason']);
                    }),
            ])
            ->emptyStateHeading('Bekleyen sipariş yok')
            ->emptyStateDescription('Tüm siparişler işlendi.')
            ->emptyStateIcon('heroicon-o-check-circle');
    }
}
