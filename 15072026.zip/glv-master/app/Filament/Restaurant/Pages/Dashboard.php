<?php

namespace App\Filament\Restaurant\Pages;

use Filament\Pages\Dashboard as BaseDashboard;

class Dashboard extends BaseDashboard
{
    protected static ?string $navigationIcon = 'heroicon-o-home';
    protected static ?string $navigationLabel = 'Gösterge Paneli';
    protected static ?string $title = 'Restoran Paneli';
}
