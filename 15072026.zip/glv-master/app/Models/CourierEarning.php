<?php

namespace App\Models;

use App\Enums\CourierEarningStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CourierEarning extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'courier_id',
        'courier_payout_id',
        'distance_km',
        'base_fee',
        'distance_fee',
        'surge_fee',
        'tip_amount',
        'total_earning',
        'status',
        'earned_at',
    ];

    protected function casts(): array
    {
        return [
            'distance_km' => 'float',
            'base_fee' => 'float',
            'distance_fee' => 'float',
            'surge_fee' => 'float',
            'tip_amount' => 'float',
            'total_earning' => 'float',
            'status' => CourierEarningStatus::class,
            'earned_at' => 'datetime',
        ];
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function courier(): BelongsTo
    {
        return $this->belongsTo(User::class, 'courier_id');
    }

    public function payout(): BelongsTo
    {
        return $this->belongsTo(CourierPayout::class, 'courier_payout_id');
    }
}
