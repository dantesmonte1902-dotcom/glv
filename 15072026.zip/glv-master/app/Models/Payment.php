<?php

namespace App\Models;

use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Payment extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'user_id',
        'method',
        'status',
        'amount',
        'currency',
        'stripe_payment_intent_id',
        'stripe_client_secret',
        'stripe_charge_id',
        'refunded_amount',
        'refund_reason',
        'refunded_at',
        'paid_at',
        'failure_message',
    ];

    protected function casts(): array
    {
        return [
            'method' => PaymentMethod::class,
            'status' => PaymentStatus::class,
            'amount' => 'float',
            'refunded_amount' => 'float',
            'paid_at' => 'datetime',
            'refunded_at' => 'datetime',
        ];
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function isSucceeded(): bool
    {
        return $this->status === PaymentStatus::SUCCEEDED;
    }

    public function isCashOnDelivery(): bool
    {
        return $this->method === PaymentMethod::CASH_ON_DELIVERY;
    }

    public function refundableAmount(): float
    {
        return round($this->amount - $this->refunded_amount, 2);
    }
}
