<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CourierProfile extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'is_online',
        'vehicle_type',
        'last_lat',
        'last_lng',
        'last_seen_at',
    ];

    protected function casts(): array
    {
        return [
            'is_online' => 'boolean',
            'last_lat' => 'float',
            'last_lng' => 'float',
            'last_seen_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Araç tipine göre kuryenin aynı anda taşıyabileceği maksimum sipariş sayısı.
     * Rota optimizasyonu / çoklu teslimat (batching) bu değere göre sınırlanır.
     */
    public function maxConcurrentOrders(): int
    {
        return match ($this->vehicle_type) {
            'car' => 3,
            'scooter' => 2,
            'bike' => 2,
            default => 1, // on_foot vb.
        };
    }
}
