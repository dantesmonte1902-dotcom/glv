<?php

namespace App\Models;

use App\Enums\CampaignSegmentType;
use App\Enums\CampaignStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Campaign extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'message_title',
        'message_body',
        'segment_type',
        'segment_params',
        'status',
        'recipient_count',
        'sent_at',
        'created_by',
    ];

    protected function casts(): array
    {
        return [
            'segment_type' => CampaignSegmentType::class,
            'segment_params' => 'array',
            'status' => CampaignStatus::class,
            'recipient_count' => 'integer',
            'sent_at' => 'datetime',
        ];
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
