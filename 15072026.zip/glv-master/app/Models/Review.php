<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Review extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'customer_id',
        'restaurant_id',
        'branch_id',
        'food_rating',
        'delivery_rating',
        'comment',
        'is_visible',
        'reply',
        'replied_at',
    ];

    protected function casts(): array
    {
        return [
            'food_rating' => 'integer',
            'delivery_rating' => 'integer',
            'is_visible' => 'boolean',
            'replied_at' => 'datetime',
        ];
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(RestaurantBranch::class, 'branch_id');
    }

    /** Genel puan ortalaması */
    public function averageRating(): float
    {
        return round(($this->food_rating + $this->delivery_rating) / 2, 1);
    }
}
