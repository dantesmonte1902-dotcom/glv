<?php

namespace App\Models;

use App\Enums\CourierPayoutStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CourierPayout extends Model
{
    use HasFactory;

    protected $fillable = [
        'courier_id',
        'period_start',
        'period_end',
        'order_count',
        'total_amount',
        'status',
        'paid_at',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'period_start' => 'date',
            'period_end' => 'date',
            'order_count' => 'integer',
            'total_amount' => 'float',
            'status' => CourierPayoutStatus::class,
            'paid_at' => 'datetime',
        ];
    }

    public function courier(): BelongsTo
    {
        return $this->belongsTo(User::class, 'courier_id');
    }

    public function earnings(): HasMany
    {
        return $this->hasMany(CourierEarning::class);
    }
}
