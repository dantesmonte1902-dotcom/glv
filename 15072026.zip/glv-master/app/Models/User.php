<?php

namespace App\Models;

use App\Enums\UserRole;
use Database\Factories\UserFactory;
use Filament\Models\Contracts\FilamentUser;
use Filament\Panel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable implements FilamentUser
{
    /** @use HasFactory<UserFactory> */
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'city_id',
        'restaurant_id',
        'name',
        'email',
        'phone',
        'password',
        'role',
        'is_active',
        'referral_code',
        'referred_by_id',
        'loyalty_points_balance',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'is_active' => 'boolean',
            'role' => UserRole::class,
            'loyalty_points_balance' => 'integer',
        ];
    }

    // ─── Filament panel erişim kontrolü ──────────────────────────────────────

    public function canAccessPanel(Panel $panel): bool
    {
        if (! $this->is_active) {
            return false;
        }

        return match ($panel->getId()) {
            'admin' => $this->role === UserRole::ADMIN,
            'restaurant' => $this->role === UserRole::RESTAURANT,
            default => false,
        };
    }

    // ─── İlişkiler ────────────────────────────────────────────────────────────

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }

    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class);
    }

    public function courierProfile(): HasOne
    {
        return $this->hasOne(CourierProfile::class);
    }

    public function customerOrders(): HasMany
    {
        return $this->hasMany(Order::class, 'customer_id');
    }

    public function courierAssignments(): HasMany
    {
        return $this->hasMany(CourierAssignment::class, 'courier_id');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function courierEarnings(): HasMany
    {
        return $this->hasMany(CourierEarning::class, 'courier_id');
    }

    public function courierPayouts(): HasMany
    {
        return $this->hasMany(CourierPayout::class, 'courier_id');
    }

    public function referredBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'referred_by_id');
    }

    public function referrals(): HasMany
    {
        return $this->hasMany(User::class, 'referred_by_id');
    }

    public function loyaltyTransactions(): HasMany
    {
        return $this->hasMany(LoyaltyPointTransaction::class);
    }

    public function disputes(): HasMany
    {
        return $this->hasMany(Dispute::class, 'customer_id');
    }

    /**
     * Benzersiz, kolay okunur bir referans kodu üretir (örn. "GLV7K2Q").
     */
    public static function generateUniqueReferralCode(): string
    {
        do {
            $code = 'GLV'.strtoupper(substr(bin2hex(random_bytes(4)), 0, 5));
        } while (self::query()->where('referral_code', $code)->exists());

        return $code;
    }

    // ─── Yardımcı metotlar ────────────────────────────────────────────────────

    public function ownsRestaurant(Restaurant $restaurant): bool
    {
        return $this->ownsRestaurantId($restaurant->getKey());
    }

    public function ownsRestaurantId(?int $restaurantId): bool
    {
        return $this->restaurant_id !== null && (int) $this->restaurant_id === (int) $restaurantId;
    }

    public function belongsToCity(?int $cityId): bool
    {
        return $this->city_id !== null && (int) $this->city_id === (int) $cityId;
    }

    public function isAdmin(): bool
    {
        return $this->role === UserRole::ADMIN;
    }

    public function isRestaurant(): bool
    {
        return $this->role === UserRole::RESTAURANT;
    }
}
