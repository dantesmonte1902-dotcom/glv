<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class RestaurantBranch extends Model
{
    use HasFactory;

    protected $fillable = [
        'restaurant_id',
        'city_id',
        'name',
        'address',
        'lat',
        'lng',
        'service_radius_km',
        'is_active',
        'is_open',
        'opens_at',
        'closes_at',
        'minimum_order_amount',
        'estimated_delivery_minutes',
    ];

    protected function casts(): array
    {
        return [
            'lat' => 'float',
            'lng' => 'float',
            'service_radius_km' => 'float',
            'is_active' => 'boolean',
            'is_open' => 'boolean',
            'minimum_order_amount' => 'float',
            'estimated_delivery_minutes' => 'integer',
        ];
    }

    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class);
    }

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class, 'branch_id');
    }
}
