<?php

namespace App\Services\Branch;

use App\Models\RestaurantBranch;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

class BranchScheduleService
{
    /**
     * Tüm aktif şubeleri çalışma saatlerine göre aç/kapat.
     * Her dakika çalışır (Scheduler tarafından tetiklenir).
     */
    public function syncOpenStatus(): void
    {
        $now = Carbon::now();
        $branches = RestaurantBranch::query()
            ->where('is_active', true)
            ->whereNotNull('opens_at')
            ->whereNotNull('closes_at')
            ->get();

        $opened = 0;
        $closed = 0;

        foreach ($branches as $branch) {
            $shouldBeOpen = $this->shouldBeOpen($branch, $now);

            if ($branch->is_open !== $shouldBeOpen) {
                $branch->update(['is_open' => $shouldBeOpen]);
                $shouldBeOpen ? $opened++ : $closed++;

                Log::info('Şube durumu değişti', [
                    'branch_id' => $branch->id,
                    'branch_name' => $branch->name,
                    'status' => $shouldBeOpen ? 'açıldı' : 'kapandı',
                    'time' => $now->toTimeString(),
                ]);
            }
        }

        if ($opened > 0 || $closed > 0) {
            Log::info("Şube güncelleme: {$opened} açıldı, {$closed} kapandı.");
        }
    }

    /**
     * Şubenin şu an açık olup olmayacağını hesaplar.
     * Gece yarısını geçen saatleri destekler (22:00 → 02:00 gibi).
     */
    public function shouldBeOpen(RestaurantBranch $branch, ?Carbon $at = null): bool
    {
        if (! $branch->is_active) {
            return false;
        }

        if (! $branch->opens_at || ! $branch->closes_at) {
            return $branch->is_open; // Saat tanımlanmamışsa mevcut durumu koru
        }

        $now = ($at ?? Carbon::now())->copy();
        $opens = Carbon::createFromTimeString($branch->opens_at);
        $closes = Carbon::createFromTimeString($branch->closes_at);

        // Gece yarısını geçen durum (örn: 22:00 → 02:00)
        if ($closes->lessThan($opens)) {
            return $now->greaterThanOrEqualTo($opens) || $now->lessThan($closes);
        }

        return $now->between($opens, $closes);
    }
}
