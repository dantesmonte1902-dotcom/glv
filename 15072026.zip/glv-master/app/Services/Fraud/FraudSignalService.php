<?php

namespace App\Services\Fraud;

use App\Enums\CourierAssignmentStatus;
use App\Enums\OrderStatus;
use App\Enums\UserRole;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;

/**
 * Basit, kural bazlı anormallik tespiti. Makine öğrenmesi yerine şeffaf,
 * açıklanabilir eşikler kullanır — admin panelinde "neden işaretlendi"
 * sorusuna her zaman net bir cevap olur.
 *
 * Bu bir otomatik engelleme sistemi DEĞİLDİR — yalnızca admin'in dikkatini
 * çekecek adaylar üretir, nihai karar her zaman insan tarafından verilir.
 */
class FraudSignalService
{
    private const LOOKBACK_DAYS = 30;
    private const MIN_ORDERS_FOR_CUSTOMER_SIGNAL = 3;
    private const MIN_OFFERS_FOR_COURIER_SIGNAL = 5;

    /**
     * Son 30 günde iptal/itiraz oranı yüksek müşteriler.
     * risk_score = iptal_sayısı*2 + itiraz_sayısı*3
     */
    public function flaggedCustomersQuery(): Builder
    {
        $since = now()->subDays(self::LOOKBACK_DAYS);

        return User::query()
            ->where('role', UserRole::CUSTOMER)
            ->withCount([
                'customerOrders as total_orders_count' => fn ($q) => $q->where('created_at', '>=', $since),
                'customerOrders as cancelled_orders_count' => fn ($q) => $q->where('created_at', '>=', $since)
                    ->where('status', OrderStatus::CANCELLED),
                'disputes as disputes_count' => fn ($q) => $q->where('created_at', '>=', $since),
            ])
            ->havingRaw('total_orders_count >= ?', [self::MIN_ORDERS_FOR_CUSTOMER_SIGNAL])
            ->havingRaw('(cancelled_orders_count * 2 + disputes_count * 3) >= 6')
            ->selectRaw('*, (cancelled_orders_count * 2 + disputes_count * 3) as risk_score')
            ->orderByDesc('risk_score');
    }

    /**
     * Son 30 günde teklif reddetme oranı yüksek kuryeler.
     * (Sürekli teklif reddeden kurye, platformun eşleştirme verimliliğini düşürür
     * ve bazen belirli bölge/siparişleri seçici şekilde ayıklıyor olabilir.)
     */
    public function flaggedCouriersQuery(): Builder
    {
        $since = now()->subDays(self::LOOKBACK_DAYS);

        return User::query()
            ->where('role', UserRole::COURIER)
            ->withCount([
                'courierAssignments as total_offers_count' => fn ($q) => $q->where('created_at', '>=', $since),
                'courierAssignments as rejected_offers_count' => fn ($q) => $q->where('created_at', '>=', $since)
                    ->where('status', CourierAssignmentStatus::REJECTED),
            ])
            ->havingRaw('total_offers_count >= ?', [self::MIN_OFFERS_FOR_COURIER_SIGNAL])
            ->selectRaw('*, ROUND(rejected_offers_count * 100.0 / NULLIF(total_offers_count, 0)) as rejection_rate')
            ->havingRaw('(rejected_offers_count * 100.0 / NULLIF(total_offers_count, 0)) >= 50')
            ->orderByDesc('rejection_rate');
    }
}
