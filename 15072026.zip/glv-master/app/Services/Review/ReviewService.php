<?php

namespace App\Services\Review;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Models\Review;
use App\Models\RestaurantBranch;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Validation\ValidationException;

class ReviewService
{
    /**
     * Teslim edilen bir sipariş için değerlendirme oluşturur.
     * Her sipariş için yalnızca 1 değerlendirme yapılabilir.
     */
    public function create(User $customer, Order $order, array $data): Review
    {
        // Sipariş müşteriye ait mi?
        if ($order->customer_id !== $customer->id) {
            abort(403, 'Bu siparişi değerlendirme yetkiniz yok.');
        }

        // Sadece teslim edilen siparişler değerlendirilebilir
        if ($order->status !== OrderStatus::DELIVERED) {
            throw ValidationException::withMessages([
                'order' => 'Yalnızca teslim edilen siparişler değerlendirilebilir.',
            ]);
        }

        // Daha önce değerlendirme yapılmış mı?
        if (Review::where('order_id', $order->id)->exists()) {
            throw ValidationException::withMessages([
                'order' => 'Bu sipariş daha önce değerlendirilmiş.',
            ]);
        }

        $review = Review::create([
            'order_id' => $order->id,
            'customer_id' => $customer->id,
            'restaurant_id' => $order->branch->restaurant_id,
            'branch_id' => $order->branch_id,
            'food_rating' => $data['food_rating'],
            'delivery_rating' => $data['delivery_rating'],
            'comment' => $data['comment'] ?? null,
            'is_visible' => true,
        ]);

        // Şube ortalama puanını güncelle
        $this->recalculateBranchRating($order->branch_id);

        return $review->load('customer:id,name');
    }

    /**
     * Restoran kendi şubesinin değerlendirmelerine yanıt verir.
     */
    public function reply(User $actor, Review $review, string $reply): Review
    {
        $role = $actor->role->value ?? $actor->role;

        $canReply = $role === 'admin'
            || ($role === 'restaurant' && $actor->restaurant_id === $review->restaurant_id);

        if (! $canReply) {
            abort(403, 'Bu değerlendirmeye yanıt verme yetkiniz yok.');
        }

        $review->update([
            'reply' => $reply,
            'replied_at' => now(),
        ]);

        return $review->fresh();
    }

    /**
     * Şubenin değerlendirmelerini listeler.
     */
    public function listForBranch(int $branchId, int $perPage = 10): LengthAwarePaginator
    {
        return Review::query()
            ->where('branch_id', $branchId)
            ->where('is_visible', true)
            ->with('customer:id,name')
            ->orderByDesc('created_at')
            ->paginate($perPage);
    }

    /**
     * Müşterinin kendi değerlendirmelerini listeler.
     */
    public function listForCustomer(User $customer, int $perPage = 10): LengthAwarePaginator
    {
        return Review::query()
            ->where('customer_id', $customer->id)
            ->with(['branch.restaurant'])
            ->orderByDesc('created_at')
            ->paginate($perPage);
    }

    /**
     * Admin: değerlendirmeyi gizler/gösterir.
     */
    public function toggleVisibility(Review $review): Review
    {
        $review->update(['is_visible' => ! $review->is_visible]);

        $this->recalculateBranchRating($review->branch_id);

        return $review->fresh();
    }

    /**
     * Şubenin ortalama puanını ve toplam değerlendirme sayısını günceller.
     */
    private function recalculateBranchRating(int $branchId): void
    {
        $stats = Review::query()
            ->where('branch_id', $branchId)
            ->where('is_visible', true)
            ->selectRaw('AVG(food_rating) as avg_food, AVG(delivery_rating) as avg_delivery, COUNT(*) as total')
            ->first();

        RestaurantBranch::where('id', $branchId)->update([
            'avg_food_rating' => round($stats->avg_food ?? 0, 2),
            'avg_delivery_rating' => round($stats->avg_delivery ?? 0, 2),
            'review_count' => $stats->total ?? 0,
        ]);
    }
}
