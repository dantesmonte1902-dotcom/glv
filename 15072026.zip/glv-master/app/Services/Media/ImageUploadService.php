<?php

namespace App\Services\Media;

use App\Models\Product;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ImageUploadService
{
    private string $disk;

    public function __construct()
    {
        // Production'da 's3', geliştirmede 'public'
        $this->disk = config('filesystems.default', 'public');
    }

    /**
     * Ürün resmi yükler, eskisini siler ve URL'yi döner.
     */
    public function uploadProductImage(Product $product, UploadedFile $file): string
    {
        // Eski resmi sil
        if ($product->image_path) {
            Storage::disk($this->disk)->delete($product->image_path);
        }

        $path = $this->store($file, "products/{$product->restaurant_id}");

        $product->update([
            'image_path' => $path,
            'image_url' => Storage::disk($this->disk)->url($path),
        ]);

        return Storage::disk($this->disk)->url($path);
    }

    /**
     * Dosyayı verilen klasöre kaydeder, benzersiz isim üretir.
     */
    private function store(UploadedFile $file, string $folder): string
    {
        $extension = $file->getClientOriginalExtension();
        $filename = Str::uuid() . '.' . $extension;

        return $file->storeAs($folder, $filename, [
            'disk' => $this->disk,
            'visibility' => 'public',
        ]);
    }

    /**
     * Dosyayı siler.
     */
    public function delete(?string $path): void
    {
        if ($path) {
            Storage::disk($this->disk)->delete($path);
        }
    }
}
