<?php

namespace App\Services\Analytics;

use App\Models\Order;
use App\Models\Review;
use App\Models\User;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class AnalyticsService
{
    /**
     * Restoran için belirli tarih aralığında sipariş ve gelir özeti.
     */
    public function restaurantSummary(int $restaurantId, Carbon $from, Carbon $to): array
    {
        $orders = Order::query()
            ->whereHas('branch', fn ($q) => $q->where('restaurant_id', $restaurantId))
            ->whereBetween('created_at', [$from, $to]);

        $totalOrders = (clone $orders)->count();
        $deliveredOrders = (clone $orders)->where('status', 'delivered')->count();
        $totalRevenue = (clone $orders)->where('payment_status', 'paid')->sum('total_amount');
        $avgOrderValue = $deliveredOrders > 0 ? round($totalRevenue / $deliveredOrders, 2) : 0;

        // Günlük dağılım
        $dailyStats = (clone $orders)
            ->where('payment_status', 'paid')
            ->select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as order_count'),
                DB::raw('SUM(total_amount) as revenue')
            )
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        // En çok sipariş edilen ürünler
        $topProducts = DB::table('order_items')
            ->join('orders', 'order_items.order_id', '=', 'orders.id')
            ->join('restaurant_branches', 'orders.branch_id', '=', 'restaurant_branches.id')
            ->where('restaurant_branches.restaurant_id', $restaurantId)
            ->whereBetween('orders.created_at', [$from, $to])
            ->select('order_items.item_name', DB::raw('SUM(order_items.quantity) as total_qty'), DB::raw('SUM(order_items.line_total) as total_revenue'))
            ->groupBy('order_items.item_name')
            ->orderByDesc('total_qty')
            ->limit(5)
            ->get();

        // Değerlendirme ortalamaları
        $ratings = Review::query()
            ->where('restaurant_id', $restaurantId)
            ->whereBetween('created_at', [$from, $to])
            ->where('is_visible', true)
            ->select(
                DB::raw('AVG(food_rating) as avg_food'),
                DB::raw('AVG(delivery_rating) as avg_delivery'),
                DB::raw('COUNT(*) as review_count')
            )
            ->first();

        return [
            'period' => ['from' => $from->toDateString(), 'to' => $to->toDateString()],
            'orders' => [
                'total' => $totalOrders,
                'delivered' => $deliveredOrders,
                'completion_rate' => $totalOrders > 0 ? round($deliveredOrders / $totalOrders * 100, 1) : 0,
            ],
            'revenue' => [
                'total' => round($totalRevenue, 2),
                'avg_order_value' => $avgOrderValue,
                'currency' => 'BAM',
            ],
            'daily_stats' => $dailyStats,
            'top_products' => $topProducts,
            'ratings' => [
                'avg_food' => round($ratings->avg_food ?? 0, 2),
                'avg_delivery' => round($ratings->avg_delivery ?? 0, 2),
                'review_count' => $ratings->review_count ?? 0,
            ],
        ];
    }

    /**
     * Admin için platform geneli özet.
     */
    public function platformSummary(Carbon $from, Carbon $to): array
    {
        $orders = Order::whereBetween('created_at', [$from, $to]);

        return [
            'period' => ['from' => $from->toDateString(), 'to' => $to->toDateString()],
            'total_orders' => (clone $orders)->count(),
            'delivered_orders' => (clone $orders)->where('status', 'delivered')->count(),
            'total_revenue' => round((clone $orders)->where('payment_status', 'paid')->sum('total_amount'), 2),
            'new_customers' => User::where('role', 'customer')->whereBetween('created_at', [$from, $to])->count(),
            'active_restaurants' => \App\Models\Restaurant::where('is_active', true)->count(),
            'daily_stats' => (clone $orders)
                ->where('payment_status', 'paid')
                ->select(DB::raw('DATE(created_at) as date'), DB::raw('COUNT(*) as orders'), DB::raw('SUM(total_amount) as revenue'))
                ->groupBy('date')
                ->orderBy('date')
                ->get(),
        ];
    }
}
