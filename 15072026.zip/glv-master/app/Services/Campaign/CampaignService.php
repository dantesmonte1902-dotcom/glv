<?php

namespace App\Services\Campaign;

use App\Enums\CampaignSegmentType;
use App\Enums\CampaignStatus;
use App\Enums\UserRole;
use App\Jobs\Notification\SendCampaignJob;
use App\Models\Campaign;
use App\Models\User;
use Illuminate\Support\Collection;

class CampaignService
{
    /**
     * Kampanyanın segment tanımına göre alıcı kullanıcı ID listesini üretir.
     *
     * @return Collection<int, int>
     */
    public function resolveRecipientIds(Campaign $campaign): Collection
    {
        $params = $campaign->segment_params ?? [];

        $query = User::query()
            ->where('role', UserRole::CUSTOMER)
            ->where('is_active', true);

        match ($campaign->segment_type) {
            CampaignSegmentType::CITY => $query->where('city_id', $params['city_id'] ?? 0),
            CampaignSegmentType::INACTIVE_CUSTOMERS => $query->where(function ($q) use ($params): void {
                $days = (int) ($params['inactive_days'] ?? 30);
                $cutoff = now()->subDays($days);

                // Son N gün içinde siparişi olmayan (hiç sipariş vermemiş olanlar dahil)
                $q->whereDoesntHave('customerOrders', fn ($oq) => $oq->where('created_at', '>=', $cutoff));
            }),
            default => null, // 'all' → ek filtre yok
        };

        return $query->pluck('id');
    }

    /**
     * Kampanyayı alıcı listesine gönderir. Gerçek FCM gönderimi kuyruğa alınır
     * (SendCampaignJob), böylece admin panelini bloklamaz.
     */
    public function send(Campaign $campaign): int
    {
        $recipientIds = $this->resolveRecipientIds($campaign);

        $campaign->forceFill([
            'status' => CampaignStatus::SENT,
            'recipient_count' => $recipientIds->count(),
            'sent_at' => now(),
        ])->save();

        foreach ($recipientIds->chunk(200) as $chunk) {
            SendCampaignJob::dispatch($campaign->id, $chunk->all());
        }

        return $recipientIds->count();
    }
}
