<?php

namespace App\Services\Cart;

use App\Models\Order;
use App\Models\Product;
use App\Models\ProductOption;
use App\Models\RestaurantBranch;
use App\Models\User;
use App\Services\Courier\DeliveryPricingService;
use App\Services\Loyalty\LoyaltyService;
use App\Services\Pricing\ServiceFeeCalculator;
use Illuminate\Support\Facades\Redis;
use Illuminate\Validation\ValidationException;

/**
 * Redis tabanlı sepet servisi.
 *
 * Her kullanıcının sepeti Redis'te JSON olarak saklanır:
 * Key: cart:user:{user_id}
 * TTL: 2 saat (kullanıcı aktifse yenilenir)
 *
 * Sepet yapısı:
 * {
 *   "branch_id": 1,
 *   "restaurant_id": 1,
 *   "city_id": 1,
 *   "items": [
 *     {
 *       "cart_item_id": "uuid",
 *       "product_id": 5,
 *       "product_name": "Classic Burger",
 *       "quantity": 2,
 *       "base_price": 14.90,
 *       "selected_options": [
 *         {"option_id": 101, "group_name": "Boy", "option_name": "Menü", "price_modifier": 7.00}
 *       ],
 *       "unit_price": 21.90,
 *       "line_total": 43.80
 *     }
 *   ]
 * }
 */
class CartService
{
    private const TTL_SECONDS = 7200; // 2 saat

    public function __construct(
        private readonly DeliveryPricingService $deliveryPricingService,
        private readonly ServiceFeeCalculator $serviceFeeCalculator,
        private readonly LoyaltyService $loyaltyService,
    ) {}

    // ─── Sepet okuma ──────────────────────────────────────────────────────────

    public function getCart(User $user): array
    {
        $data = Redis::get($this->key($user));

        if (! $data) {
            return $this->emptyCart();
        }

        $cart = json_decode($data, true);
        $cart['summary'] = $this->buildSummary($cart);

        return $cart;
    }

    // ─── Ürün ekleme ──────────────────────────────────────────────────────────

    public function addItem(User $user, array $payload): array
    {
        $cart = $this->getRaw($user);

        $product = Product::query()
            ->where('is_active', true)
            ->where('is_available', true)
            ->with(['optionGroups.activeOptions', 'category'])
            ->findOrFail($payload['product_id']);

        // Sepet başka bir şubeden ürün içeriyorsa hata ver
        if (! empty($cart['branch_id']) && (int) $cart['branch_id'] !== (int) $payload['branch_id']) {
            throw ValidationException::withMessages([
                'branch_id' => 'Sepetinizde başka bir şubeye ait ürün var. Önce sepeti temizleyin.',
            ]);
        }

        $branch = RestaurantBranch::query()->findOrFail($payload['branch_id']);

        // Opsiyonları doğrula ve fiyatı hesapla
        $resolvedOptions = $this->resolveOptions($product, $payload['selected_options'] ?? []);
        $optionsPrice = collect($resolvedOptions)->sum('price_modifier');
        $unitPrice = round($product->base_price + $optionsPrice, 2);

        // Aynı ürün + aynı opsiyonlar varsa miktarı artır
        $existingKey = $this->findMatchingItem($cart, $product->id, $resolvedOptions);

        if ($existingKey !== null) {
            $cart['items'][$existingKey]['quantity'] += $payload['quantity'];
            $cart['items'][$existingKey]['line_total'] = round(
                $cart['items'][$existingKey]['unit_price'] * $cart['items'][$existingKey]['quantity'],
                2
            );
        } else {
            $cart['items'][] = [
                'cart_item_id' => (string) \Illuminate\Support\Str::uuid(),
                'product_id' => $product->id,
                'product_name' => $product->name,
                'quantity' => $payload['quantity'],
                'base_price' => $product->base_price,
                'selected_options' => $resolvedOptions,
                'unit_price' => $unitPrice,
                'line_total' => round($unitPrice * $payload['quantity'], 2),
            ];
        }

        // Sepet meta bilgilerini güncelle/doldur
        $cart['branch_id'] = $branch->id;
        $cart['restaurant_id'] = $branch->restaurant_id;
        $cart['city_id'] = $branch->city_id;

        $this->save($user, $cart);

        $cart['summary'] = $this->buildSummary($cart);

        return $cart;
    }

    // ─── Miktar güncelleme ────────────────────────────────────────────────────

    public function updateItem(User $user, string $cartItemId, int $quantity): array
    {
        $cart = $this->getRaw($user);

        $key = $this->findByCartItemId($cart, $cartItemId);

        if ($key === null) {
            throw ValidationException::withMessages([
                'cart_item_id' => 'Sepette böyle bir ürün bulunamadı.',
            ]);
        }

        if ($quantity <= 0) {
            return $this->removeItem($user, $cartItemId);
        }

        $cart['items'][$key]['quantity'] = $quantity;
        $cart['items'][$key]['line_total'] = round(
            $cart['items'][$key]['unit_price'] * $quantity,
            2
        );

        $this->save($user, $cart);

        $cart['summary'] = $this->buildSummary($cart);

        return $cart;
    }

    // ─── Ürün silme ───────────────────────────────────────────────────────────

    public function removeItem(User $user, string $cartItemId): array
    {
        $cart = $this->getRaw($user);

        $key = $this->findByCartItemId($cart, $cartItemId);

        if ($key !== null) {
            array_splice($cart['items'], $key, 1);
        }

        // Sepet boşaldıysa sıfırla
        if (empty($cart['items'])) {
            $cart = $this->emptyCart();
        }

        $this->save($user, $cart);

        $cart['summary'] = $this->buildSummary($cart);

        return $cart;
    }

    // ─── Sepeti temizle ───────────────────────────────────────────────────────

    public function clearCart(User $user): void
    {
        Redis::del($this->key($user));
    }

    // ─── Checkout öncesi özet (fiyat hesaplama) ───────────────────────────────

    /**
     * Sipariş vermeden önce tam fiyat dökümü döner.
     * Kupon kodu varsa uygulanır.
     */
    public function buildCheckoutSummary(
        User $user,
        ?string $couponCode = null,
        ?float $deliveryLat = null,
        ?float $deliveryLng = null,
        int $redeemPoints = 0,
    ): array {
        $cart = $this->getRaw($user);

        if (empty($cart['items'])) {
            throw ValidationException::withMessages([
                'cart' => 'Sepetiniz boş.',
            ]);
        }

        $branch = RestaurantBranch::query()->findOrFail($cart['branch_id']);

        if (! $branch->is_open) {
            throw ValidationException::withMessages([
                'branch' => 'Bu şube şu an kapalı.',
            ]);
        }

        $subtotal = collect($cart['items'])->sum('line_total');

        if ($subtotal < $branch->minimum_order_amount) {
            throw ValidationException::withMessages([
                'cart' => "Minimum sipariş tutarı {$branch->minimum_order_amount} KM. Şu an: {$subtotal} KM.",
            ]);
        }

        $pricingQuote = $this->deliveryPricingService->quote($branch, $deliveryLat, $deliveryLng, 'food');
        $deliveryFee = $pricingQuote['delivery_fee'];
        $serviceFee = $this->serviceFeeCalculator->calculate($subtotal);
        $discountAmount = 0.0;
        $coupon = null;

        if ($couponCode) {
            [$coupon, $discountAmount] = $this->applyCoupon($couponCode, $subtotal, $user, $branch->restaurant_id);
        }

        $pointsQuote = ['points_used' => 0, 'discount_amount' => 0.0];
        if ($redeemPoints > 0) {
            $pointsQuote = $this->loyaltyService->quoteRedemption($user, $redeemPoints, $subtotal - $discountAmount);
            $discountAmount = round($discountAmount + $pointsQuote['discount_amount'], 2);
        }

        $total = round($subtotal + $deliveryFee + $serviceFee - $discountAmount, 2);

        return [
            'branch' => [
                'id' => $branch->id,
                'name' => $branch->name,
                'estimated_delivery_minutes' => $branch->estimated_delivery_minutes,
            ],
            'items' => $cart['items'],
            'subtotal' => $subtotal,
            'delivery_fee' => $deliveryFee,
            'delivery_pricing' => [
                'distance_km' => $pricingQuote['distance_km'],
                'surge_multiplier' => $pricingQuote['surge_multiplier'],
                'surge_active' => $pricingQuote['surge_multiplier'] > 1.0,
            ],
            'service_fee' => $serviceFee,
            'discount_amount' => $discountAmount,
            'loyalty' => [
                'available_points' => $user->loyalty_points_balance,
                'points_used' => $pointsQuote['points_used'],
                'points_discount' => $pointsQuote['discount_amount'],
            ],
            'total' => $total,
            'coupon' => $coupon ? [
                'code' => $coupon->code,
                'type' => $coupon->type,
                'value' => $coupon->value,
                'discount_applied' => $discountAmount,
            ] : null,
            'payment_methods' => ['cash', 'card'],
        ];
    }

    // ─── Sipariş sonrası sepeti boşalt ───────────────────────────────────────

    public function clearAfterOrder(User $user): void
    {
        $this->clearCart($user);
    }

    /**
     * Geçmiş bir siparişteki ürünleri sepete yeniden ekler ("Yeniden Sipariş Ver").
     * Mevcut sepet önce temizlenir (farklı şubeden ürün varsa addItem zaten
     * hata verirdi — kullanıcı deneyimi için baştan temiz bir sepetle başlanır).
     *
     * Üründen artık aktif/mevcut olmayanlar sessizce atlanır ve `skipped`
     * listesinde nedenleriyle birlikte döner ki kullanıcı neyin eklenmediğini görsün.
     *
     * @return array{cart: array, skipped: array<int, array{item_name: string, reason: string}>}
     */
    public function reorder(User $user, Order $order): array
    {
        $order->loadMissing('items', 'branch');

        $this->clearCart($user);

        $skipped = [];

        foreach ($order->items as $item) {
            if (! $item->product_id) {
                $skipped[] = ['item_name' => $item->item_name, 'reason' => 'Ürün artık menüde bulunmuyor.'];
                continue;
            }

            $optionIds = collect($item->selected_options ?? [])->pluck('option_id')->filter()->values()->all();

            try {
                $this->addItem($user, [
                    'branch_id' => $order->branch_id,
                    'product_id' => $item->product_id,
                    'quantity' => $item->quantity,
                    'selected_options' => $optionIds,
                ]);
            } catch (\Throwable $e) {
                $skipped[] = ['item_name' => $item->item_name, 'reason' => 'Bu ürün artık mevcut değil veya seçenekleri değişti.'];
            }
        }

        return [
            'cart' => $this->getCart($user),
            'skipped' => $skipped,
            'branch_is_open' => (bool) ($order->branch->is_open ?? false),
        ];
    }

    // ─── Yardımcı metodlar ────────────────────────────────────────────────────

    private function key(User $user): string
    {
        return "cart:user:{$user->id}";
    }

    private function getRaw(User $user): array
    {
        $data = Redis::get($this->key($user));

        return $data ? json_decode($data, true) : $this->emptyCart();
    }

    private function save(User $user, array $cart): void
    {
        Redis::setex($this->key($user), self::TTL_SECONDS, json_encode($cart));
    }

    private function emptyCart(): array
    {
        return [
            'branch_id' => null,
            'restaurant_id' => null,
            'city_id' => null,
            'items' => [],
        ];
    }

    private function buildSummary(array $cart): array
    {
        $subtotal = collect($cart['items'])->sum('line_total');
        $itemCount = collect($cart['items'])->sum('quantity');

        return [
            'item_count' => $itemCount,
            'subtotal' => round($subtotal, 2),
        ];
    }

    private function findMatchingItem(array $cart, int $productId, array $resolvedOptions): ?int
    {
        $newOptionIds = collect($resolvedOptions)->pluck('option_id')->sort()->values()->toArray();

        foreach ($cart['items'] as $key => $item) {
            if ((int) $item['product_id'] !== $productId) {
                continue;
            }

            $existingOptionIds = collect($item['selected_options'])->pluck('option_id')->sort()->values()->toArray();

            if ($existingOptionIds === $newOptionIds) {
                return $key;
            }
        }

        return null;
    }

    private function findByCartItemId(array $cart, string $cartItemId): ?int
    {
        foreach ($cart['items'] as $key => $item) {
            if ($item['cart_item_id'] === $cartItemId) {
                return $key;
            }
        }

        return null;
    }

    private function resolveOptions(
        \App\Models\Product $product,
        array $selectedOptionIds
    ): array {
        $resolved = [];

        foreach ($product->optionGroups as $group) {
            $groupOptionIds = $group->activeOptions->pluck('id')->toArray();
            $chosen = array_intersect($selectedOptionIds, $groupOptionIds);

            if ($group->is_required && count($chosen) < $group->min_selections) {
                throw ValidationException::withMessages([
                    'selected_options' => "'{$group->name}' grubu için en az {$group->min_selections} seçenek seçilmeli.",
                ]);
            }

            if (! $group->is_multiple && count($chosen) > 1) {
                throw ValidationException::withMessages([
                    'selected_options' => "'{$group->name}' grubundan yalnızca 1 seçenek seçilebilir.",
                ]);
            }

            foreach ($group->activeOptions as $option) {
                if (in_array($option->id, $chosen)) {
                    $resolved[] = [
                        'option_id' => $option->id,
                        'group_name' => $group->name,
                        'option_name' => $option->name,
                        'price_modifier' => $option->price_modifier,
                    ];
                }
            }
        }

        return $resolved;
    }

    private function applyCoupon(string $code, float $subtotal, User $user, int $restaurantId): array
    {
        $coupon = \App\Models\Coupon::query()
            ->where('code', strtoupper($code))
            ->first();

        if (! $coupon || ! $coupon->isValid()) {
            throw ValidationException::withMessages([
                'coupon_code' => 'Geçersiz veya süresi dolmuş kupon kodu.',
            ]);
        }

        // Restorana özel kupon kontrolü
        if ($coupon->restaurant_id && $coupon->restaurant_id !== $restaurantId) {
            throw ValidationException::withMessages([
                'coupon_code' => 'Bu kupon bu restoran için geçerli değil.',
            ]);
        }

        // Minimum tutar kontrolü
        if ($subtotal < $coupon->minimum_order_amount) {
            throw ValidationException::withMessages([
                'coupon_code' => "Bu kupon için minimum sipariş tutarı {$coupon->minimum_order_amount} KM.",
            ]);
        }

        // Kullanıcı bazlı kullanım kontrolü
        $userUsageCount = $coupon->usages()->where('user_id', $user->id)->count();

        if ($userUsageCount >= $coupon->per_user_limit) {
            throw ValidationException::withMessages([
                'coupon_code' => 'Bu kuponu daha önce kullandınız.',
            ]);
        }

        $discountAmount = $coupon->calculateDiscount($subtotal);

        return [$coupon, $discountAmount];
    }

}
