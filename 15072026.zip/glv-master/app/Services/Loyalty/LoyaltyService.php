<?php

namespace App\Services\Loyalty;

use App\Enums\LoyaltyPointTransactionType;
use App\Enums\OrderStatus;
use App\Models\LoyaltyPointTransaction;
use App\Models\Order;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Sadakat puanı kazanma/harcama ve referans (arkadaşını davet et) ödül mantığı.
 *
 * Kazanım: teslim edilen her siparişin subtotal'ı üzerinden 1 KM = 1 puan.
 * Harcama: 100 puan = 1 KM indirim, sepet tutarının en fazla %50'si puanla karşılanabilir.
 * Referans: davet edilen kişi ilk siparişini TESLİM ALDIĞINDA hem davet eden hem
 *           davet edilen bonus puan kazanır (tek seferlik, order->customer'ın
 *           delivered ilk siparişi olup olmadığı kontrol edilerek).
 */
class LoyaltyService
{
    private const POINTS_PER_KM_SPENT = 1;
    private const POINTS_TO_KM_RATE = 100; // 100 puan = 1 KM
    private const MAX_REDEEMABLE_SHARE_OF_SUBTOTAL = 0.5; // sepetin en fazla %50'si puanla ödenebilir

    private const REFERRAL_BONUS_REFERRER = 500; // ~5 KM değerinde
    private const REFERRAL_BONUS_NEW_USER = 200; // ~2 KM değerinde

    public function balance(User $user): int
    {
        return $user->loyalty_points_balance;
    }

    /**
     * Kullanıcının şu an sepeti için en fazla kaç puan kullanabileceğini ve
     * bunun karşılığı KM indirimini hesaplar (checkout önizlemesi için).
     */
    public function quoteRedemption(User $user, int $requestedPoints, float $subtotal): array
    {
        if ($requestedPoints <= 0) {
            return ['points_used' => 0, 'discount_amount' => 0.0];
        }

        $maxByBalance = $user->loyalty_points_balance;
        $maxDiscountValue = round($subtotal * self::MAX_REDEEMABLE_SHARE_OF_SUBTOTAL, 2);
        $maxByOrderCap = (int) floor($maxDiscountValue * self::POINTS_TO_KM_RATE);

        $pointsUsed = min($requestedPoints, $maxByBalance, $maxByOrderCap);
        $pointsUsed = max($pointsUsed, 0);

        $discountAmount = round($pointsUsed / self::POINTS_TO_KM_RATE, 2);

        return ['points_used' => $pointsUsed, 'discount_amount' => $discountAmount];
    }

    /**
     * Sipariş oluşturulurken puanı düşer (siparişin points_redeemed alanına
     * yazılması çağıran tarafın sorumluluğundadır).
     */
    public function redeem(User $user, ?Order $order, int $points, string $description = 'Sipariş indirimi'): void
    {
        if ($points <= 0) {
            return;
        }

        DB::transaction(function () use ($user, $order, $points, $description): void {
            $fresh = User::query()->lockForUpdate()->findOrFail($user->id);

            if ($fresh->loyalty_points_balance < $points) {
                throw ValidationException::withMessages(['redeem_points' => 'Yetersiz sadakat puanı bakiyesi.']);
            }

            $newBalance = $fresh->loyalty_points_balance - $points;
            $fresh->forceFill(['loyalty_points_balance' => $newBalance])->save();

            LoyaltyPointTransaction::query()->create([
                'user_id' => $fresh->id,
                'order_id' => $order?->id,
                'type' => LoyaltyPointTransactionType::REDEEM,
                'points' => -$points,
                'balance_after' => $newBalance,
                'description' => $description,
            ]);
        });
    }

    /**
     * Sipariş reddedilir/iptal edilirse kullanılan puanları iade eder.
     */
    public function refund(Order $order): void
    {
        if ($order->points_redeemed <= 0) {
            return;
        }

        $this->addPoints(
            $order->customer_id,
            $order->points_redeemed,
            LoyaltyPointTransactionType::REFUND,
            $order,
            'Sipariş iptali — puan iadesi',
        );
    }

    /**
     * Teslimat tamamlandığında kazanılan puanı ekler.
     */
    public function earnForOrder(Order $order): int
    {
        if ($order->points_earned > 0) {
            return $order->points_earned; // zaten işlenmiş
        }

        $earned = (int) floor($order->subtotal_amount * self::POINTS_PER_KM_SPENT);

        if ($earned <= 0) {
            return 0;
        }

        $this->addPoints($order->customer_id, $earned, LoyaltyPointTransactionType::EARN, $order, 'Sipariş kazancı');

        $order->forceFill(['points_earned' => $earned])->save();

        return $earned;
    }

    /**
     * Davet edilen kullanıcının İLK teslim edilen siparişinde, hem kendisine
     * hem davet edene bonus puan verir. Sonraki siparişlerde tekrar tetiklenmez.
     */
    public function grantReferralBonusIfEligible(Order $order): void
    {
        $customer = $order->customer;

        if (! $customer || ! $customer->referred_by_id) {
            return;
        }

        $isFirstDeliveredOrder = Order::query()
            ->where('customer_id', $customer->id)
            ->where('status', OrderStatus::DELIVERED)
            ->count() === 1; // bu sipariş zaten 'delivered' olarak kaydedildikten sonra çağrılır

        if (! $isFirstDeliveredOrder) {
            return;
        }

        $alreadyGranted = LoyaltyPointTransaction::query()
            ->where('user_id', $customer->id)
            ->where('type', LoyaltyPointTransactionType::REFERRAL_SIGNUP_BONUS)
            ->exists();

        if ($alreadyGranted) {
            return;
        }

        $this->addPoints($customer->id, self::REFERRAL_BONUS_NEW_USER, LoyaltyPointTransactionType::REFERRAL_SIGNUP_BONUS, $order, 'Referans ile katılım bonusu');
        $this->addPoints($customer->referred_by_id, self::REFERRAL_BONUS_REFERRER, LoyaltyPointTransactionType::REFERRAL_BONUS, $order, "Davet ettiğiniz {$customer->name} ilk siparişini tamamladı");
    }

    /**
     * Admin tarafından bir itirazın çözümü olarak verilen telafi puanı.
     */
    public function compensate(User $user, int $points, ?Order $order, string $description): void
    {
        if ($points <= 0) {
            return;
        }

        $this->addPoints($user->id, $points, LoyaltyPointTransactionType::ADJUSTMENT, $order, $description);
    }

    public function referralStats(User $user): array
    {
        $referrals = $user->referrals()->withCount([
            'customerOrders as delivered_orders_count' => fn ($q) => $q->where('status', OrderStatus::DELIVERED),
        ])->get(['id', 'name', 'created_at']);

        return [
            'referral_code' => $user->referral_code,
            'total_invited' => $referrals->count(),
            'completed_first_order' => $referrals->filter(fn ($r) => $r->delivered_orders_count > 0)->count(),
            'referrals' => $referrals->map(fn ($r) => [
                'name' => $r->name,
                'joined_at' => $r->created_at,
                'has_ordered' => $r->delivered_orders_count > 0,
            ]),
        ];
    }

    public function history(User $user, int $perPage = 20)
    {
        return LoyaltyPointTransaction::query()
            ->where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->paginate($perPage);
    }

    private function addPoints(int $userId, int $points, LoyaltyPointTransactionType $type, ?Order $order, string $description): void
    {
        DB::transaction(function () use ($userId, $points, $type, $order, $description): void {
            $user = User::query()->lockForUpdate()->findOrFail($userId);
            $newBalance = $user->loyalty_points_balance + $points;

            $user->forceFill(['loyalty_points_balance' => $newBalance])->save();

            LoyaltyPointTransaction::query()->create([
                'user_id' => $userId,
                'order_id' => $order?->id,
                'type' => $type,
                'points' => $points,
                'balance_after' => $newBalance,
                'description' => $description,
            ]);
        });
    }
}
