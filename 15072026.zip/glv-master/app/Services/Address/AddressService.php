<?php

namespace App\Services\Address;

use App\Models\CustomerAddress;
use App\Models\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Validation\ValidationException;

class AddressService
{
    /** Kullanıcının tüm adreslerini döner. */
    public function list(User $user): Collection
    {
        return CustomerAddress::query()
            ->where('user_id', $user->id)
            ->orderByDesc('is_default')
            ->orderByDesc('updated_at')
            ->get();
    }

    /** Yeni adres oluşturur. İlk adres otomatik varsayılan olur. */
    public function create(User $user, array $data): CustomerAddress
    {
        $isFirst = ! CustomerAddress::where('user_id', $user->id)->exists();

        if (! empty($data['is_default']) || $isFirst) {
            $this->clearDefault($user->id);
            $data['is_default'] = true;
        }

        return CustomerAddress::create(array_merge($data, ['user_id' => $user->id]));
    }

    /** Adresi günceller. */
    public function update(User $user, CustomerAddress $address, array $data): CustomerAddress
    {
        $this->authorizeOwner($user, $address);

        if (! empty($data['is_default'])) {
            $this->clearDefault($user->id);
        }

        $address->update($data);

        return $address->fresh();
    }

    /** Adresi siler. Varsayılansa bir sonrakini varsayılan yapar. */
    public function delete(User $user, CustomerAddress $address): void
    {
        $this->authorizeOwner($user, $address);
        $wasDefault = $address->is_default;
        $address->delete();

        if ($wasDefault) {
            CustomerAddress::where('user_id', $user->id)
                ->latest()
                ->first()
                ?->update(['is_default' => true]);
        }
    }

    /** Bir adresi varsayılan yapar. */
    public function setDefault(User $user, CustomerAddress $address): CustomerAddress
    {
        $this->authorizeOwner($user, $address);
        $this->clearDefault($user->id);
        $address->update(['is_default' => true]);

        return $address->fresh();
    }

    // ─── Yardımcı ────────────────────────────────────────────────────────────

    private function clearDefault(int $userId): void
    {
        CustomerAddress::where('user_id', $userId)
            ->where('is_default', true)
            ->update(['is_default' => false]);
    }

    private function authorizeOwner(User $user, CustomerAddress $address): void
    {
        if ($address->user_id !== $user->id) {
            abort(403, 'Bu adrese erişim yetkiniz yok.');
        }
    }
}
