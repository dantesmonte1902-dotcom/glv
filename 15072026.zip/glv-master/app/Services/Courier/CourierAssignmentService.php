<?php

namespace App\Services\Courier;

use App\Enums\CourierAssignmentStatus;
use App\Enums\OrderStatus;
use App\Enums\UserRole;
use App\Events\Courier\CourierAssigned;
use App\Events\Courier\CourierLocationUpdated;
use App\Events\Orders\OrderStatusUpdated;
use App\Jobs\Orders\AssignCourierJob;
use App\Models\CourierAssignment;
use App\Models\CourierProfile;
use App\Models\Order;
use App\Models\User;
use App\Support\Geo;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CourierAssignmentService
{
    public function assignBestCourier(Order $order, ?int $excludedCourierId = null): CourierAssignment
    {
        $order->loadMissing('customer', 'branch', 'courierAssignment');

        return DB::transaction(function () use ($order, $excludedCourierId): CourierAssignment {
            $assignment = $order->courierAssignment()->firstOrCreate([], [
                'status' => CourierAssignmentStatus::SEARCHING,
                'search_started_at' => now(),
            ]);

            $profile = $this->pickBestCandidate($order, $excludedCourierId);

            if (! $profile) {
                $assignment->forceFill([
                    'courier_id' => null,
                    'status' => CourierAssignmentStatus::SEARCHING,
                    'search_started_at' => $assignment->search_started_at ?? now(),
                ])->save();

                $order->forceFill([
                    'status' => OrderStatus::SEARCHING_COURIER,
                ])->save();

                return $assignment->fresh();
            }

            $assignment->forceFill([
                'courier_id' => $profile->user_id,
                'status' => CourierAssignmentStatus::OFFERED,
                'search_started_at' => $assignment->search_started_at ?? now(),
                'assigned_at' => now(),
                'last_offered_at' => now(),
            ])->save();

            $order->forceFill([
                'status' => OrderStatus::COURIER_ASSIGNED,
            ])->save();

            CourierAssigned::dispatch($order->fresh()->load('courierAssignment.courier'));

            return $assignment->fresh('courier');
        });
    }

    /**
     * En uygun kuryeyi seçer. İki faktörü dengeler:
     *  1) Kuryenin şubeye (teslim alma noktasına) uzaklığı — asıl kıstas budur,
     *     müşteriye değil, önce restorana gidileceği için.
     *  2) "Batching" bonusu — kuryenin zaten üzerinde, bu şubeye yakın (aynı/civar
     *     restoran) aktif bir siparişi varsa, yeni siparişi de aynı kuryeye teklif
     *     etmek rota verimliliğini artırır (tek çıkışta iki teslimat).
     * Kapasitesi dolu (araç tipine göre maksimum eşzamanlı sipariş) kuryeler elenir.
     */
    private function pickBestCandidate(Order $order, ?int $excludedCourierId): ?CourierProfile
    {
        if ($order->branch?->lat === null || $order->branch?->lng === null) {
            return $this->pickByLastSeen($order, $excludedCourierId);
        }

        $branchLat = (float) $order->branch->lat;
        $branchLng = (float) $order->branch->lng;

        $candidates = CourierProfile::query()
            ->where('is_online', true)
            ->whereNotNull('last_lat')
            ->whereNotNull('last_lng')
            ->whereHas('user', function ($builder) use ($order, $excludedCourierId): void {
                $builder->where('role', UserRole::COURIER)
                    ->where('is_active', true)
                    ->where('city_id', $order->city_id);

                if ($excludedCourierId) {
                    $builder->whereKeyNot($excludedCourierId);
                }
            })
            ->with(['user.courierAssignments' => function ($q): void {
                $q->whereIn('status', [CourierAssignmentStatus::OFFERED, CourierAssignmentStatus::ACCEPTED])
                    ->with('order.branch:id,lat,lng');
            }])
            ->get();

        $best = $candidates
            ->filter(fn (CourierProfile $c) => $c->user->courierAssignments->count() < $c->maxConcurrentOrders())
            ->map(function (CourierProfile $c) use ($branchLat, $branchLng): array {
                $distanceToBranch = Geo::distanceKm((float) $c->last_lat, (float) $c->last_lng, $branchLat, $branchLng);

                $hasNearbyActiveBranch = $c->user->courierAssignments->contains(function ($assignment) use ($branchLat, $branchLng): bool {
                    $activeBranch = $assignment->order?->branch;
                    if (! $activeBranch || $activeBranch->lat === null || $activeBranch->lng === null) {
                        return false;
                    }

                    return Geo::distanceKm((float) $activeBranch->lat, (float) $activeBranch->lng, $branchLat, $branchLng) <= 1.2;
                });

                // Batching bonusu: skor küçültülerek (mesafe azaltılmış gibi) öncelik verilir.
                $score = $distanceToBranch - ($hasNearbyActiveBranch ? 2.0 : 0.0);

                return ['profile' => $c, 'score' => $score];
            })
            ->sortBy('score')
            ->first();

        return $best['profile'] ?? null;
    }

    private function pickByLastSeen(Order $order, ?int $excludedCourierId): ?CourierProfile
    {
        $query = CourierProfile::query()
            ->where('is_online', true)
            ->whereNotNull('last_lat')
            ->whereNotNull('last_lng')
            ->whereHas('user', function ($builder) use ($order, $excludedCourierId): void {
                $builder->where('role', UserRole::COURIER)
                    ->where('is_active', true)
                    ->where('city_id', $order->city_id);

                if ($excludedCourierId) {
                    $builder->whereKeyNot($excludedCourierId);
                }
            })
            ->with(['user.courierAssignments' => fn ($q) => $q->whereIn('status', [CourierAssignmentStatus::OFFERED, CourierAssignmentStatus::ACCEPTED])])
            ->orderByDesc('last_seen_at');

        return $query->get()
            ->first(fn (CourierProfile $c) => $c->user->courierAssignments->count() < $c->maxConcurrentOrders());
    }

    public function acceptOrder(User $courier, Order $order): CourierAssignment
    {
        $assignment = $this->getCourierAssignment($courier, $order, CourierAssignmentStatus::OFFERED);

        $assignment->forceFill([
            'status' => CourierAssignmentStatus::ACCEPTED,
            'accepted_at' => now(),
        ])->save();

        $order->forceFill([
            'status' => OrderStatus::OUT_FOR_DELIVERY,
        ])->save();

        OrderStatusUpdated::dispatch($order->fresh()->load('branch.restaurant', 'courierAssignment'));

        return $assignment->fresh('courier');
    }

    public function rejectOrder(User $courier, Order $order): CourierAssignment
    {
        $assignment = $this->getCourierAssignment($courier, $order, CourierAssignmentStatus::OFFERED);
        $excludedCourierId = $courier->id;

        $assignment->forceFill([
            'status' => CourierAssignmentStatus::REJECTED,
            'last_rejected_at' => now(),
        ])->save();

        $order->forceFill([
            'status' => OrderStatus::SEARCHING_COURIER,
        ])->save();

        OrderStatusUpdated::dispatch($order->fresh()->load('branch.restaurant', 'courierAssignment'));

        AssignCourierJob::dispatch($order->id, $excludedCourierId);

        return $assignment->fresh();
    }

    public function updateLocation(User $courier, array $payload): array
    {
        $profile = $courier->courierProfile()->firstOrCreate([], [
            'vehicle_type' => 'bike',
            'is_online' => false,
        ]);

        $profile->forceFill([
            'last_lat' => $payload['lat'],
            'last_lng' => $payload['lng'],
            'is_online' => $payload['is_online'] ?? $profile->is_online,
            'last_seen_at' => now(),
        ])->save();

        $activeOrderIds = $courier->courierAssignments()
            ->whereIn('status', [CourierAssignmentStatus::OFFERED, CourierAssignmentStatus::ACCEPTED])
            ->pluck('order_id')
            ->all();

        CourierLocationUpdated::dispatch($courier, $profile, $activeOrderIds);

        return [
            'courier_id' => $courier->id,
            'is_online' => $profile->is_online,
            'last_lat' => $profile->last_lat,
            'last_lng' => $profile->last_lng,
            'last_seen_at' => $profile->last_seen_at,
            'active_order_ids' => $activeOrderIds,
        ];
    }

    public function updateAvailability(User $courier, bool $isOnline): CourierProfile
    {
        $profile = $courier->courierProfile()->firstOrCreate([], [
            'vehicle_type' => 'bike',
            'is_online' => false,
        ]);

        $profile->forceFill([
            'is_online' => $isOnline,
            'last_seen_at' => now(),
        ])->save();

        return $profile;
    }

    private function getCourierAssignment(User $courier, Order $order, CourierAssignmentStatus $expectedStatus): CourierAssignment
    {
        $assignment = $order->courierAssignment;

        if (! $assignment
            || $assignment->courier_id !== $courier->id
            || ($assignment->status->value ?? $assignment->status) !== $expectedStatus->value
            || ! $courier->belongsToCity($order->city_id)) {
            throw ValidationException::withMessages([
                'order' => 'This order is not currently assigned to the courier in the expected state.',
            ]);
        }

        return $assignment;
    }
}
