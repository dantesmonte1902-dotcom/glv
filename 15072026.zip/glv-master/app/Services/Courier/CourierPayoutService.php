<?php

namespace App\Services\Courier;

use App\Enums\CourierEarningStatus;
use App\Enums\CourierPayoutStatus;
use App\Models\CourierEarning;
use App\Models\CourierPayout;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Belirli bir dönem (varsayılan: haftalık) için ödenmemiş kurye kazançlarını
 * kurye başına gruplayıp ödeme (payout) kaydı oluşturur. Admin panelinden tetiklenir.
 */
class CourierPayoutService
{
    /**
     * @return Collection<int, CourierPayout>
     */
    public function generateBatch(Carbon $periodStart, Carbon $periodEnd): Collection
    {
        return DB::transaction(function () use ($periodStart, $periodEnd): Collection {
            $grouped = CourierEarning::query()
                ->where('status', CourierEarningStatus::PENDING)
                ->whereBetween('earned_at', [$periodStart, $periodEnd])
                ->get()
                ->groupBy('courier_id');

            return $grouped->map(function (Collection $earnings, int $courierId) use ($periodStart, $periodEnd): CourierPayout {
                $payout = CourierPayout::query()->create([
                    'courier_id' => $courierId,
                    'period_start' => $periodStart->toDateString(),
                    'period_end' => $periodEnd->toDateString(),
                    'order_count' => $earnings->count(),
                    'total_amount' => round($earnings->sum('total_earning'), 2),
                    'status' => CourierPayoutStatus::PENDING,
                ]);

                CourierEarning::query()
                    ->whereIn('id', $earnings->pluck('id'))
                    ->update(['courier_payout_id' => $payout->id]);

                return $payout;
            })->values();
        });
    }

    public function markPaid(CourierPayout $payout): CourierPayout
    {
        $payout->forceFill([
            'status' => CourierPayoutStatus::PAID,
            'paid_at' => now(),
        ])->save();

        $payout->earnings()->update(['status' => CourierEarningStatus::PAID]);

        return $payout->fresh();
    }
}
