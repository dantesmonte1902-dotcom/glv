<?php

namespace App\Services\Courier;

use App\Models\CourierProfile;
use App\Models\Order;
use App\Models\RestaurantBranch;
use App\Support\Geo;

/**
 * Müşteriye yansıyan teslimat ücretini hesaplar:
 *   ücret = taban_ücret(domain) + mesafe_ücreti(km) , sonra talep_yoğunluğu çarpanı uygulanır.
 *
 * Bu servis, önceden OrderService ve CartService içine ayrı ayrı yazılmış olan
 * (ve şube yarıçapına dayanan, gerçek mesafeyi hesaba katmayan) hesaplamanın
 * yerine geçer. Tek bir yerden yönetildiği için müşteri artık sepet önizlemesinde
 * gördüğü ücretle sipariş sırasında ödediği ücretin birebir aynı olduğundan emin olur.
 */
class DeliveryPricingService
{
    /** Şehir bazlı taban km ücreti (KM/km) */
    private const PER_KM_RATE = 0.45;

    /** İlk X km ücretsiz/dahil (taban ücrete dahil) */
    private const INCLUDED_KM = 2.0;

    /** Sürpriz (surge) çarpanı üst sınırı */
    private const MAX_SURGE_MULTIPLIER = 1.6;

    public function quote(RestaurantBranch $branch, ?float $deliveryLat, ?float $deliveryLng, string $domainType): array
    {
        $baseFee = match ($domainType) {
            'market' => 5.5,
            'pharmacy' => 4.5,
            default => 3.5,
        };

        $distanceKm = $this->resolveDistanceKm($branch, $deliveryLat, $deliveryLng);

        $extraKm = max($distanceKm - self::INCLUDED_KM, 0);
        $distanceFee = round($extraKm * self::PER_KM_RATE, 2);

        $surgeMultiplier = $this->surgeMultiplier((int) $branch->city_id);
        $subtotalBeforeSurge = round($baseFee + $distanceFee, 2);
        $surgeFee = round($subtotalBeforeSurge * ($surgeMultiplier - 1), 2);

        $total = round($subtotalBeforeSurge + $surgeFee, 2);

        return [
            'distance_km' => $distanceKm,
            'base_fee' => $baseFee,
            'distance_fee' => $distanceFee,
            'surge_multiplier' => $surgeMultiplier,
            'surge_fee' => $surgeFee,
            'delivery_fee' => $total,
        ];
    }

    /**
     * Sadece toplam ücreti döner — mevcut OrderService/CartService imzasıyla uyumlu kısayol.
     */
    public function calculate(RestaurantBranch $branch, ?float $deliveryLat, ?float $deliveryLng, string $domainType): float
    {
        return $this->quote($branch, $deliveryLat, $deliveryLng, $domainType)['delivery_fee'];
    }

    /**
     * Şehirdeki aktif (teslimat aşamasındaki) sipariş sayısının, o an müsait
     * (online) kurye sayısına oranına göre bir çarpan üretir.
     * Kurye arzı talebi karşılıyorsa 1.0 (normal fiyat), talep arzı aşıyorsa kademeli artar.
     */
    public function surgeMultiplier(int $cityId): float
    {
        $activeOrders = Order::query()
            ->where('city_id', $cityId)
            ->whereIn('status', ['searching_courier', 'courier_assigned', 'out_for_delivery'])
            ->count();

        $onlineCouriers = CourierProfile::query()
            ->where('is_online', true)
            ->whereHas('user', fn ($q) => $q->where('city_id', $cityId)->where('role', 'courier')->where('is_active', true))
            ->count();

        if ($onlineCouriers === 0) {
            return $activeOrders > 0 ? self::MAX_SURGE_MULTIPLIER : 1.0;
        }

        $ratio = $activeOrders / $onlineCouriers;

        $multiplier = match (true) {
            $ratio >= 3.0 => 1.6,
            $ratio >= 2.0 => 1.35,
            $ratio >= 1.2 => 1.15,
            default => 1.0,
        };

        return min($multiplier, self::MAX_SURGE_MULTIPLIER);
    }

    private function resolveDistanceKm(RestaurantBranch $branch, ?float $deliveryLat, ?float $deliveryLng): float
    {
        if ($deliveryLat === null || $deliveryLng === null || $branch->lat === null || $branch->lng === null) {
            // Koordinat yoksa şubenin servis yarıçapını muhafazakâr bir tahmin olarak kullan.
            return (float) ($branch->service_radius_km ?? 3.0);
        }

        return Geo::distanceKm((float) $branch->lat, (float) $branch->lng, $deliveryLat, $deliveryLng);
    }
}
