<?php

namespace App\Services\Courier;

use App\Enums\CourierAssignmentStatus;
use App\Models\User;
use App\Support\Geo;
use Illuminate\Support\Collection;

/**
 * Bir kuryenin üzerindeki tüm aktif (kabul edilmiş) siparişler için en verimli
 * durak sırasını hesaplar.
 *
 * Yöntem: "en yakın komşu" (nearest-neighbor) sezgisel algoritması, teslim alma
 * önceliği (precedence) kısıtıyla — bir siparişin teslim durağı, o siparişin
 * teslim alma durağından önce ziyaret edilemez. 2-4 duraklık gerçek dünya
 * kurye rotaları için tam TSP çözümü gereksiz karmaşıklık katar; bu sezgisel
 * pratikte optimuma çok yakın sonuç verir ve anlık hesaplanabilir.
 */
class RouteOptimizationService
{
    private const AVG_SPEED_KMH = 18.0; // ortalama kurye hızı (bisiklet/scooter karışık varsayım)
    private const HANDLING_MINUTES_PER_STOP = 3.0; // her durakta ürün alma/teslim etme için sabit süre

    /**
     * @return array{stops: array<int, array>, total_distance_km: float, total_eta_minutes: int}
     */
    public function buildRoute(User $courier): array
    {
        $courier->loadMissing('courierProfile');
        $profile = $courier->courierProfile;

        if (! $profile || $profile->last_lat === null || $profile->last_lng === null) {
            return ['stops' => [], 'total_distance_km' => 0, 'total_eta_minutes' => 0];
        }

        $assignments = $courier->courierAssignments()
            ->where('status', CourierAssignmentStatus::ACCEPTED)
            ->with(['order.branch'])
            ->get();

        $stops = collect();

        foreach ($assignments as $assignment) {
            $order = $assignment->order;
            if (! $order) {
                continue;
            }

            if ($order->branch && $order->branch->lat !== null && $order->branch->lng !== null) {
                $stops->push([
                    'type' => 'pickup',
                    'order_id' => $order->id,
                    'label' => $order->branch->name,
                    'address' => $order->branch->address,
                    'lat' => (float) $order->branch->lat,
                    'lng' => (float) $order->branch->lng,
                ]);
            }

            if ($order->delivery_lat !== null && $order->delivery_lng !== null) {
                $stops->push([
                    'type' => 'dropoff',
                    'order_id' => $order->id,
                    'label' => 'Teslimat: '.$order->delivery_address,
                    'address' => $order->delivery_address,
                    'lat' => (float) $order->delivery_lat,
                    'lng' => (float) $order->delivery_lng,
                ]);
            }
        }

        if ($stops->isEmpty()) {
            return ['stops' => [], 'total_distance_km' => 0, 'total_eta_minutes' => 0];
        }

        return $this->sequence($stops, (float) $profile->last_lat, (float) $profile->last_lng);
    }

    private function sequence(Collection $stops, float $startLat, float $startLng): array
    {
        $remaining = $stops->values()->all();
        $visitedPickupOrderIds = [];
        $sequence = [];

        $currentLat = $startLat;
        $currentLng = $startLng;
        $totalDistance = 0.0;

        while (! empty($remaining)) {
            $bestIndex = null;
            $bestDistance = null;

            foreach ($remaining as $index => $stop) {
                // Bir siparişin teslim durağı, aynı siparişin teslim alma durağı
                // ziyaret edilmeden seçilemez.
                if ($stop['type'] === 'dropoff' && ! in_array($stop['order_id'], $visitedPickupOrderIds, true)) {
                    continue;
                }

                $distance = Geo::distanceKm($currentLat, $currentLng, $stop['lat'], $stop['lng']);

                if ($bestDistance === null || $distance < $bestDistance) {
                    $bestDistance = $distance;
                    $bestIndex = $index;
                }
            }

            // Tüm kalan duraklar dropoff ama pickup'ı henüz seçilmemiş bir tutarsızlık
            // durumuna karşı güvenlik: hiçbir uygun durak bulunamazsa döngüyü kır.
            if ($bestIndex === null) {
                break;
            }

            $chosen = $remaining[$bestIndex];
            unset($remaining[$bestIndex]);
            $remaining = array_values($remaining);

            $totalDistance += $bestDistance;
            $currentLat = $chosen['lat'];
            $currentLng = $chosen['lng'];

            if ($chosen['type'] === 'pickup') {
                $visitedPickupOrderIds[] = $chosen['order_id'];
            }

            $sequence[] = array_merge($chosen, [
                'sequence' => count($sequence) + 1,
                'distance_from_previous_km' => round($bestDistance, 2),
            ]);
        }

        $etaMinutes = (int) ceil(
            ($totalDistance / self::AVG_SPEED_KMH) * 60
            + count($sequence) * self::HANDLING_MINUTES_PER_STOP
        );

        return [
            'stops' => $sequence,
            'total_distance_km' => round($totalDistance, 2),
            'total_eta_minutes' => $etaMinutes,
        ];
    }
}
