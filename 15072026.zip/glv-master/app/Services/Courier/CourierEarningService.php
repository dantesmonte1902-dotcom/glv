<?php

namespace App\Services\Courier;

use App\Enums\CourierEarningStatus;
use App\Models\CourierEarning;
use App\Models\Order;
use App\Models\User;
use App\Support\Geo;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * Bir siparişin teslimatı tamamlandığında kuryenin hak ettiği kazancı hesaplar
 * ve kaydeder. Kurye kazancı, müşteriden alınan teslimat ücretinden bağımsız bir
 * iç ücretlendirme yapısıdır (platform komisyonu farkı burada oluşur):
 *
 *   taban_ücret (sabit, sipariş alma/teslim etme başına)
 *   + mesafe_ücreti (km başına kurye tarifesi)
 *   + surge_bonus (o anki talep yoğunluğuna göre ekstra)
 */
class CourierEarningService
{
    private const COURIER_BASE_FEE = 2.00;
    private const COURIER_PER_KM_RATE = 0.60;

    public function __construct(private readonly DeliveryPricingService $pricingService) {}

    public function recordForOrder(Order $order): ?CourierEarning
    {
        $order->loadMissing('branch', 'courierAssignment', 'courierEarning');

        if ($order->courierEarning) {
            return $order->courierEarning;
        }

        $courierId = $order->courierAssignment?->courier_id;
        if (! $courierId) {
            return null;
        }

        $distanceKm = ($order->delivery_lat !== null && $order->delivery_lng !== null && $order->branch?->lat !== null)
            ? Geo::distanceKm((float) $order->branch->lat, (float) $order->branch->lng, (float) $order->delivery_lat, (float) $order->delivery_lng)
            : (float) ($order->branch->service_radius_km ?? 3.0);

        $baseFee = self::COURIER_BASE_FEE;
        $distanceFee = round($distanceKm * self::COURIER_PER_KM_RATE, 2);

        $surgeMultiplier = $this->pricingService->surgeMultiplier((int) $order->city_id);
        $surgeFee = round(($baseFee + $distanceFee) * ($surgeMultiplier - 1), 2);

        $total = round($baseFee + $distanceFee + $surgeFee, 2);

        return CourierEarning::query()->create([
            'order_id' => $order->id,
            'courier_id' => $courierId,
            'distance_km' => $distanceKm,
            'base_fee' => $baseFee,
            'distance_fee' => $distanceFee,
            'surge_fee' => $surgeFee,
            'tip_amount' => 0,
            'total_earning' => $total,
            'status' => CourierEarningStatus::PENDING,
            'earned_at' => now(),
        ]);
    }

    /**
     * Kuryenin belirli bir dönemdeki kazanç özeti (analitik servisiyle aynı period deseni).
     */
    public function summary(User $courier, Carbon $from, Carbon $to): array
    {
        $base = CourierEarning::query()
            ->where('courier_id', $courier->id)
            ->whereBetween('earned_at', [$from, $to]);

        $totalEarning = (clone $base)->sum('total_earning');
        $deliveryCount = (clone $base)->count();
        $pendingAmount = (clone $base)->where('status', CourierEarningStatus::PENDING)->sum('total_earning');
        $paidAmount = (clone $base)->where('status', CourierEarningStatus::PAID)->sum('total_earning');

        $dailyStats = (clone $base)
            ->select(
                DB::raw('DATE(earned_at) as date'),
                DB::raw('COUNT(*) as delivery_count'),
                DB::raw('SUM(total_earning) as total')
            )
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        return [
            'period' => ['from' => $from->toDateString(), 'to' => $to->toDateString()],
            'delivery_count' => $deliveryCount,
            'total_earning' => round($totalEarning, 2),
            'pending_amount' => round($pendingAmount, 2),
            'paid_amount' => round($paidAmount, 2),
            'avg_per_delivery' => $deliveryCount > 0 ? round($totalEarning / $deliveryCount, 2) : 0,
            'daily_stats' => $dailyStats,
            'currency' => 'BAM',
        ];
    }

    public function list(User $courier, Carbon $from, Carbon $to, int $perPage = 20)
    {
        return CourierEarning::query()
            ->where('courier_id', $courier->id)
            ->whereBetween('earned_at', [$from, $to])
            ->with('order:id,branch_id,delivered_at,delivery_address')
            ->orderByDesc('earned_at')
            ->paginate($perPage);
    }
}
