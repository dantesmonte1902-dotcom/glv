<?php

namespace App\Services\Payment;

use App\Enums\OrderStatus;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Models\Order;
use App\Models\Payment;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Stripe\Exception\ApiErrorException;
use Stripe\PaymentIntent;
use Stripe\Refund;
use Stripe\Stripe;

class PaymentService
{
    public function __construct()
    {
        Stripe::setApiKey(config('services.stripe.secret'));
    }

    // ─── Ödeme Intent Oluştur (kart ödemesi) ────────────────────────────────

    /**
     * Stripe PaymentIntent oluşturur ve client_secret döner.
     * Flutter/web bu secret ile ödemeyi tamamlar.
     *
     * @return array{payment_id: int, client_secret: string, payment_intent_id: string}
     */
    public function createPaymentIntent(Order $order, User $customer): array
    {
        if ($order->customer_id !== $customer->id) {
            abort(403, 'Bu sipariş size ait değil.');
        }

        if ($order->isPaid()) {
            throw ValidationException::withMessages(['order' => 'Bu sipariş zaten ödenmiş.']);
        }

        if ($order->status === OrderStatus::CANCELLED || $order->status === OrderStatus::REJECTED) {
            throw ValidationException::withMessages(['order' => 'İptal edilmiş sipariş için ödeme yapılamaz.']);
        }

        // Daha önce oluşturulmuş pending intent varsa döndür
        $existing = $order->payments()
            ->where('method', PaymentMethod::CARD->value)
            ->whereIn('status', [PaymentStatus::PENDING->value, PaymentStatus::PROCESSING->value])
            ->whereNotNull('stripe_payment_intent_id')
            ->latest()
            ->first();

        if ($existing) {
            return [
                'payment_id' => $existing->id,
                'client_secret' => $existing->stripe_client_secret,
                'payment_intent_id' => $existing->stripe_payment_intent_id,
            ];
        }

        try {
            // Stripe tutarı kuruş cinsinden (BAM için en küçük birim = fening = 0.01 BAM)
            $amountInCents = (int) round($order->total_amount * 100);

            $intent = PaymentIntent::create([
                'amount' => $amountInCents,
                'currency' => 'bam',
                'metadata' => [
                    'order_id' => $order->id,
                    'customer_id' => $customer->id,
                    'branch_id' => $order->branch_id,
                ],
                'description' => "GLV Sipariş #{$order->id}",
                'automatic_payment_methods' => ['enabled' => true],
            ]);

            $payment = Payment::query()->create([
                'order_id' => $order->id,
                'user_id' => $customer->id,
                'method' => PaymentMethod::CARD->value,
                'status' => PaymentStatus::PENDING->value,
                'amount' => $order->total_amount,
                'currency' => 'BAM',
                'stripe_payment_intent_id' => $intent->id,
                'stripe_client_secret' => $intent->client_secret,
            ]);

            return [
                'payment_id' => $payment->id,
                'client_secret' => $intent->client_secret,
                'payment_intent_id' => $intent->id,
            ];
        } catch (ApiErrorException $e) {
            Log::error('Stripe PaymentIntent hatası', [
                'order_id' => $order->id,
                'error' => $e->getMessage(),
            ]);

            throw ValidationException::withMessages(['payment' => 'Ödeme başlatılamadı. Lütfen tekrar deneyin.']);
        }
    }

    // ─── Kapıda Ödeme ────────────────────────────────────────────────────────

    /**
     * Kapıda ödeme seçilmişse ödeme kaydı oluşturur.
     * Gerçek tahsilat kurye teslim ettiğinde yapılır.
     */
    public function createCashPayment(Order $order): Payment
    {
        if (! $order->isCashOnDelivery()) {
            throw ValidationException::withMessages(['order' => 'Bu sipariş kapıda ödeme ile oluşturulmamış.']);
        }

        return Payment::query()->create([
            'order_id' => $order->id,
            'user_id' => $order->customer_id,
            'method' => PaymentMethod::CASH_ON_DELIVERY->value,
            'status' => PaymentStatus::PENDING->value,
            'amount' => $order->total_amount,
            'currency' => 'BAM',
        ]);
    }

    // ─── Kapıda Ödemeyi Tamamla (teslimat anında) ────────────────────────────

    /**
     * Kurye teslim ettiğinde kapıda ödemeyi tamamlandı olarak işaretle.
     */
    public function completeCashPayment(Order $order): Payment
    {
        $payment = $order->payments()
            ->where('method', PaymentMethod::CASH_ON_DELIVERY->value)
            ->where('status', PaymentStatus::PENDING->value)
            ->latest()
            ->firstOrFail();

        $payment->update([
            'status' => PaymentStatus::SUCCEEDED->value,
            'paid_at' => now(),
        ]);

        $order->update(['payment_status' => 'paid']);

        return $payment->fresh();
    }

    // ─── Stripe Webhook İşle ─────────────────────────────────────────────────

    /**
     * Stripe'tan gelen webhook event'ini işler.
     * payment_intent.succeeded veya payment_intent.payment_failed event'leri beklenir.
     */
    public function handleWebhook(array $payload): void
    {
        $eventType = $payload['type'] ?? '';
        $intentId = $payload['data']['object']['id'] ?? null;

        if (! $intentId) {
            return;
        }

        $payment = Payment::query()
            ->where('stripe_payment_intent_id', $intentId)
            ->first();

        if (! $payment) {
            Log::warning('Stripe webhook: payment kaydı bulunamadı', ['intent_id' => $intentId]);

            return;
        }

        match ($eventType) {
            'payment_intent.succeeded' => $this->markPaymentSucceeded($payment, $payload),
            'payment_intent.payment_failed' => $this->markPaymentFailed($payment, $payload),
            default => null,
        };
    }

    // ─── İade ────────────────────────────────────────────────────────────────

    /**
     * Kısmi veya tam iade yapar.
     *
     * @param  float|null  $amount  null ise tam iade
     */
    public function refund(Order $order, ?float $amount, string $reason): Payment
    {
        $payment = $order->payments()
            ->where('status', PaymentStatus::SUCCEEDED->value)
            ->latest()
            ->firstOrFail();

        $refundAmount = $amount ?? $payment->refundableAmount();

        if ($refundAmount <= 0 || $refundAmount > $payment->refundableAmount()) {
            throw ValidationException::withMessages([
                'amount' => "İade tutarı 0 ile {$payment->refundableAmount()} KM arasında olmalıdır.",
            ]);
        }

        DB::transaction(function () use ($payment, $order, $refundAmount, $reason): void {
            if ($payment->method === PaymentMethod::CARD) {
                try {
                    Refund::create([
                        'charge' => $payment->stripe_charge_id,
                        'amount' => (int) round($refundAmount * 100),
                        'reason' => 'requested_by_customer',
                        'metadata' => ['order_id' => $order->id, 'reason' => $reason],
                    ]);
                } catch (ApiErrorException $e) {
                    Log::error('Stripe iade hatası', [
                        'payment_id' => $payment->id,
                        'error' => $e->getMessage(),
                    ]);
                    throw ValidationException::withMessages(['payment' => 'İade işlemi başarısız oldu.']);
                }
            }

            $newRefunded = round($payment->refunded_amount + $refundAmount, 2);
            $isFullRefund = $newRefunded >= $payment->amount;

            $payment->update([
                'refunded_amount' => $newRefunded,
                'refund_reason' => $reason,
                'refunded_at' => now(),
                'status' => $isFullRefund
                    ? PaymentStatus::REFUNDED->value
                    : PaymentStatus::PARTIALLY_REFUNDED->value,
            ]);

            $order->update(['payment_status' => $isFullRefund ? 'refunded' : 'partially_refunded']);
        });

        return $payment->fresh();
    }

    // ─── Dahili yardımcılar ───────────────────────────────────────────────────

    private function markPaymentSucceeded(Payment $payment, array $payload): void
    {
        if ($payment->status->isTerminal()) {
            return;
        }

        $chargeId = $payload['data']['object']['latest_charge'] ?? null;

        $payment->update([
            'status' => PaymentStatus::SUCCEEDED->value,
            'stripe_charge_id' => $chargeId,
            'paid_at' => now(),
        ]);

        $payment->order->update(['payment_status' => 'paid']);

        Log::info('Ödeme başarılı', ['payment_id' => $payment->id, 'order_id' => $payment->order_id]);
    }

    private function markPaymentFailed(Payment $payment, array $payload): void
    {
        if ($payment->status->isTerminal()) {
            return;
        }

        $failureMessage = $payload['data']['object']['last_payment_error']['message'] ?? 'Ödeme başarısız.';

        $payment->update([
            'status' => PaymentStatus::FAILED->value,
            'failure_message' => $failureMessage,
        ]);

        Log::warning('Ödeme başarısız', ['payment_id' => $payment->id, 'order_id' => $payment->order_id]);
    }
}
