<?php

namespace App\Services\Pricing;

class ServiceFeeCalculator
{
    public function calculate(float $subtotal): float
    {
        return round(min(max($subtotal * 0.05, 1.0), 5.0), 2);
    }
}
