<?php

namespace App\Services\Support;

use App\Enums\SupportTicketStatus;
use App\Events\Support\SupportMessageSent;
use App\Models\SupportMessage;
use App\Models\SupportTicket;
use App\Models\User;
use App\Services\Notification\NotificationService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Validation\ValidationException;

class SupportService
{
    public function __construct(private readonly NotificationService $notificationService) {}

    public function createTicket(User $user, array $payload): SupportTicket
    {
        $ticket = SupportTicket::query()->create([
            'user_id' => $user->id,
            'order_id' => $payload['order_id'] ?? null,
            'subject' => $payload['subject'],
            'status' => SupportTicketStatus::OPEN,
            'last_message_at' => now(),
        ]);

        $this->postMessage($user, $ticket, $payload['message'], isStaff: false);

        return $ticket->fresh();
    }

    public function postMessage(User $sender, SupportTicket $ticket, string $message, bool $isStaff): SupportMessage
    {
        if (($ticket->status->value ?? $ticket->status) === SupportTicketStatus::CLOSED->value) {
            throw ValidationException::withMessages([
                'ticket' => 'Bu destek talebi kapatılmış. Yeni bir talep açabilirsiniz.',
            ]);
        }

        $supportMessage = SupportMessage::query()->create([
            'ticket_id' => $ticket->id,
            'sender_id' => $sender->id,
            'is_staff' => $isStaff,
            'message' => $message,
        ]);

        $ticket->forceFill([
            'last_message_at' => now(),
            'status' => $isStaff ? SupportTicketStatus::IN_PROGRESS : $ticket->status,
        ])->save();

        SupportMessageSent::dispatch($supportMessage);

        if ($isStaff) {
            $this->notificationService->sendCustom(
                $ticket->user_id,
                '💬 Destek Ekibinden Yanıt',
                $message,
                ['ticket_id' => (string) $ticket->id, 'screen' => 'support_ticket'],
            );
        }

        return $supportMessage;
    }

    public function close(SupportTicket $ticket): SupportTicket
    {
        $ticket->forceFill(['status' => SupportTicketStatus::CLOSED])->save();

        return $ticket->fresh();
    }

    public function listForUser(User $user): Builder
    {
        return SupportTicket::query()
            ->where('user_id', $user->id)
            ->orderByDesc('last_message_at');
    }
}
