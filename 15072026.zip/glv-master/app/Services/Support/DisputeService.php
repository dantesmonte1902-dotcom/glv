<?php

namespace App\Services\Support;

use App\Enums\DisputeResolutionType;
use App\Enums\DisputeStatus;
use App\Enums\OrderStatus;
use App\Enums\PaymentMethod;
use App\Models\Dispute;
use App\Models\Order;
use App\Models\User;
use App\Services\Loyalty\LoyaltyService;
use App\Services\Notification\NotificationService;
use App\Services\Payment\PaymentService;
use Illuminate\Validation\ValidationException;

class DisputeService
{
    /** İtiraz, teslimattan en fazla bu kadar saat sonrasına kadar açılabilir. */
    private const DISPUTE_WINDOW_HOURS = 72;

    public function __construct(
        private readonly PaymentService $paymentService,
        private readonly LoyaltyService $loyaltyService,
        private readonly NotificationService $notificationService,
    ) {}

    public function create(User $customer, Order $order, array $payload): Dispute
    {
        if ($order->customer_id !== $customer->id) {
            abort(403, 'Bu sipariş için itiraz açamazsınız.');
        }

        if (($order->status->value ?? $order->status) !== OrderStatus::DELIVERED->value) {
            throw ValidationException::withMessages([
                'order' => 'Yalnızca teslim edilmiş siparişler için itiraz açılabilir.',
            ]);
        }

        if (! $order->delivered_at || $order->delivered_at->diffInHours(now()) > self::DISPUTE_WINDOW_HOURS) {
            throw ValidationException::withMessages([
                'order' => 'İtiraz süresi doldu. Teslimattan sonra en fazla '.self::DISPUTE_WINDOW_HOURS.' saat içinde itiraz açabilirsiniz.',
            ]);
        }

        if ($order->disputes()->exists()) {
            throw ValidationException::withMessages([
                'order' => 'Bu sipariş için zaten bir itiraz kaydı mevcut.',
            ]);
        }

        return Dispute::query()->create([
            'order_id' => $order->id,
            'customer_id' => $customer->id,
            'type' => $payload['type'],
            'description' => $payload['description'],
            'photo_url' => $payload['photo_url'] ?? null,
            'status' => DisputeStatus::OPEN,
        ]);
    }

    /**
     * Admin/destek ekibi itirazı çözer. Çözüm tipine göre otomatik olarak
     * para iadesi veya puan telafisi tetiklenir.
     */
    public function resolve(User $staff, Dispute $dispute, array $payload): Dispute
    {
        $resolutionType = DisputeResolutionType::from($payload['resolution_type']);
        $order = $dispute->order()->firstOrFail();

        switch ($resolutionType) {
            case DisputeResolutionType::REFUND:
                $amount = (float) $payload['resolution_amount'];
                if ($amount <= 0 || $amount > $order->total_amount) {
                    throw ValidationException::withMessages([
                        'resolution_amount' => "İade tutarı 0 ile {$order->total_amount} KM arasında olmalıdır.",
                    ]);
                }

                if ($order->isPaid() && $order->payment_method === PaymentMethod::CARD) {
                    $this->paymentService->refund($order, $amount, 'İtiraz #'.$dispute->id.' çözümü');
                } else {
                    // Kapıda ödemede gerçek para iadesi yok — telafi puanı olarak karşılığı verilir.
                    $equivalentPoints = (int) round($amount * 100);
                    $this->loyaltyService->compensate($dispute->customer, $equivalentPoints, $order, 'İtiraz #'.$dispute->id.' — kapıda ödeme iade karşılığı puan');
                }
                break;

            case DisputeResolutionType::COMPENSATE_POINTS:
                $points = (int) $payload['resolution_points'];
                if ($points <= 0) {
                    throw ValidationException::withMessages(['resolution_points' => 'Puan miktarı pozitif olmalıdır.']);
                }
                $this->loyaltyService->compensate($dispute->customer, $points, $order, 'İtiraz #'.$dispute->id.' telafisi');
                break;

            case DisputeResolutionType::NONE:
                break;
        }

        $dispute->forceFill([
            'status' => $resolutionType === DisputeResolutionType::NONE ? DisputeStatus::REJECTED : DisputeStatus::RESOLVED,
            'resolution_type' => $resolutionType,
            'resolution_amount' => $payload['resolution_amount'] ?? null,
            'resolution_points' => $payload['resolution_points'] ?? null,
            'resolution_notes' => $payload['resolution_notes'] ?? null,
            'resolved_by' => $staff->id,
            'resolved_at' => now(),
        ])->save();

        $this->notificationService->sendCustom(
            $dispute->customer_id,
            $resolutionType === DisputeResolutionType::NONE ? 'İtirazınız İncelendi' : '✅ İtirazınız Çözüldü',
            $payload['resolution_notes'] ?? 'İtirazınız hakkında bir güncelleme var.',
            ['dispute_id' => (string) $dispute->id, 'screen' => 'dispute_detail'],
        );

        return $dispute->fresh();
    }

    public function markUnderReview(Dispute $dispute): Dispute
    {
        $dispute->forceFill(['status' => DisputeStatus::UNDER_REVIEW])->save();

        return $dispute->fresh();
    }
}
