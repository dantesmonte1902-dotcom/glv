<?php

namespace App\Services\Menu;

use App\Models\Product;
use App\Models\ProductOption;
use App\Models\Restaurant;
use App\Models\RestaurantBranch;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Validation\ValidationException;

class MenuService
{
    /**
     * Bir şubeye ait restoranın tam menüsünü kategorilerle birlikte döner.
     * Sadece aktif ve müsait ürünler gösterilir.
     */
    public function getMenuForBranch(RestaurantBranch $branch): array
    {
        $branch->loadMissing('restaurant');

        $categories = $branch->restaurant
            ->categories()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->with([
                'activeProducts.optionGroups.activeOptions',
            ])
            ->get();

        return [
            'branch' => [
                'id' => $branch->id,
                'name' => $branch->name,
                'is_open' => $branch->is_open,
                'opens_at' => $branch->opens_at,
                'closes_at' => $branch->closes_at,
                'minimum_order_amount' => $branch->minimum_order_amount,
                'estimated_delivery_minutes' => $branch->estimated_delivery_minutes,
            ],
            'restaurant' => [
                'id' => $branch->restaurant->id,
                'name' => $branch->restaurant->name,
            ],
            'categories' => $categories,
        ];
    }

    /**
     * Ürünü opsiyon gruplarıyla birlikte döner.
     */
    public function getProduct(int $productId, int $restaurantId): Product
    {
        return Product::query()
            ->where('restaurant_id', $restaurantId)
            ->where('is_active', true)
            ->with(['optionGroups.activeOptions'])
            ->findOrFail($productId);
    }

    /**
     * Sipariş verilmeden önce seçilen opsiyonları doğrular ve
     * fiyat snapshot'ını oluşturur.
     *
     * Her item şu yapıda gelir:
     * [
     *   'product_id'       => 5,
     *   'quantity'         => 2,
     *   'selected_options' => [101, 205]  // ProductOption id'leri
     * ]
     *
     * @return array{items: array, subtotal: float}
     */
    public function validateAndPriceItems(array $items, int $restaurantId): array
    {
        $pricedItems = [];
        $subtotal = 0.0;

        foreach ($items as $item) {
            $product = Product::query()
                ->where('restaurant_id', $restaurantId)
                ->where('is_active', true)
                ->where('is_available', true)
                ->with(['optionGroups.activeOptions'])
                ->find($item['product_id']);

            if (! $product) {
                throw ValidationException::withMessages([
                    'items' => "Ürün bulunamadı veya aktif değil: ID {$item['product_id']}",
                ]);
            }

            $selectedOptions = $this->resolveOptions($product, $item['selected_options'] ?? []);
            $optionsPrice = collect($selectedOptions)->sum('price_modifier');
            $unitPrice = round($product->base_price + $optionsPrice, 2);
            $lineTotal = round($unitPrice * $item['quantity'], 2);

            $pricedItems[] = [
                'product_id' => $product->id,
                'item_name' => $product->name,
                'quantity' => $item['quantity'],
                'unit_price' => $unitPrice,
                'line_total' => $lineTotal,
                'selected_options' => $selectedOptions,
            ];

            $subtotal += $lineTotal;
        }

        return [
            'items' => $pricedItems,
            'subtotal' => round($subtotal, 2),
        ];
    }

    /**
     * Seçilen opsiyon id'lerini doğrular:
     * - Ürüne ait mi?
     * - Zorunlu gruplar seçilmiş mi?
     * - Çoklu seçim kurallarına uyuyor mu?
     */
    private function resolveOptions(Product $product, array $selectedOptionIds): array
    {
        $resolvedOptions = [];

        foreach ($product->optionGroups as $group) {
            $groupOptionIds = $group->activeOptions->pluck('id')->toArray();
            $chosen = array_intersect($selectedOptionIds, $groupOptionIds);

            // Zorunlu grup kontrolü
            if ($group->is_required && count($chosen) < $group->min_selections) {
                throw ValidationException::withMessages([
                    'items' => "'{$group->name}' grubu için en az {$group->min_selections} seçenek seçilmeli.",
                ]);
            }

            // Maksimum seçim kontrolü
            if (! $group->is_multiple && count($chosen) > 1) {
                throw ValidationException::withMessages([
                    'items' => "'{$group->name}' grubundan yalnızca 1 seçenek seçilebilir.",
                ]);
            }

            if ($group->is_multiple && count($chosen) > $group->max_selections) {
                throw ValidationException::withMessages([
                    'items' => "'{$group->name}' grubundan en fazla {$group->max_selections} seçenek seçilebilir.",
                ]);
            }

            foreach ($group->activeOptions as $option) {
                if (in_array($option->id, $chosen)) {
                    $resolvedOptions[] = [
                        'option_id' => $option->id,
                        'group_name' => $group->name,
                        'option_name' => $option->name,
                        'price_modifier' => $option->price_modifier,
                    ];
                }
            }
        }

        return $resolvedOptions;
    }
}
