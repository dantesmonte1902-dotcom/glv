<?php

namespace App\Services\Favorite;

use App\Models\Favorite;
use App\Models\Restaurant;
use App\Models\User;
use Illuminate\Support\Collection;

class FavoriteService
{
    /** Kullanıcının favori restoranlarını döner. */
    public function list(User $user): Collection
    {
        return Favorite::query()
            ->where('user_id', $user->id)
            ->with(['restaurant.branches' => fn ($q) => $q->where('is_active', true)->select(
                'id', 'restaurant_id', 'avg_food_rating', 'avg_delivery_rating', 'review_count', 'is_open', 'estimated_delivery_minutes'
            )])
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Favorite $fav) => [
                'id' => $fav->id,
                'restaurant_id' => $fav->restaurant_id,
                'restaurant_name' => $fav->restaurant->name,
                'is_favorited' => true,
                'branches' => $fav->restaurant->branches,
            ]);
    }

    /** Favoriye ekle, zaten varsa çıkar (toggle). */
    public function toggle(User $user, int $restaurantId): array
    {
        $existing = Favorite::where('user_id', $user->id)
            ->where('restaurant_id', $restaurantId)
            ->first();

        if ($existing) {
            $existing->delete();
            return ['favorited' => false];
        }

        Favorite::create(['user_id' => $user->id, 'restaurant_id' => $restaurantId]);
        return ['favorited' => true];
    }

    /** Restoran kullanıcı tarafından favoride mi? */
    public function isFavorited(User $user, int $restaurantId): bool
    {
        return Favorite::where('user_id', $user->id)
            ->where('restaurant_id', $restaurantId)
            ->exists();
    }
}
