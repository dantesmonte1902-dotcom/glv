<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Cache\RateLimiter;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Symfony\Component\HttpFoundation\Response as SymfonyResponse;

class ApiRateLimitMiddleware
{
    public function __construct(private readonly RateLimiter $limiter) {}

    public function handle(Request $request, Closure $next, string $limiterName = 'api'): SymfonyResponse
    {
        $key = $this->resolveKey($request, $limiterName);
        $maxAttempts = $this->resolveMaxAttempts($request, $limiterName);

        if ($this->limiter->tooManyAttempts($key, $maxAttempts)) {
            $retryAfter = $this->limiter->availableIn($key);

            return response()->json([
                'message' => 'Çok fazla istek gönderildi. Lütfen bekleyin.',
                'retry_after' => $retryAfter,
            ], Response::HTTP_TOO_MANY_REQUESTS)->withHeaders([
                'X-RateLimit-Limit' => $maxAttempts,
                'X-RateLimit-Remaining' => 0,
                'Retry-After' => $retryAfter,
            ]);
        }

        $this->limiter->hit($key, 60); // 1 dakikalık pencere

        $response = $next($request);

        $remaining = max(0, $maxAttempts - $this->limiter->attempts($key));

        return $response->withHeaders([
            'X-RateLimit-Limit' => $maxAttempts,
            'X-RateLimit-Remaining' => $remaining,
        ]);
    }

    private function resolveKey(Request $request, string $limiterName): string
    {
        $userId = $request->user()?->id ?? $request->ip();

        return "rl:{$limiterName}:{$userId}";
    }

    private function resolveMaxAttempts(Request $request, string $limiterName): int
    {
        $user = $request->user();

        return match ($limiterName) {
            // Giriş/kayıt — brute-force koruması
            'auth' => 10,

            // Sipariş oluşturma — müşteri başına dakikada 5
            'order' => 5,

            // Genel API
            'api' => match ($user?->role?->value ?? 'guest') {
                'admin' => 600,
                'restaurant' => 300,
                'courier' => 200,
                'customer' => 120,
                default => 30,
            },

            default => 60,
        };
    }
}
