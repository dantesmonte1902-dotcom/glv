<?php

namespace App\Http\Requests\Api\V1\Orders;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreOrderRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'city_id' => ['required', 'integer', 'exists:cities,id'],
            'branch_id' => ['required', 'integer', 'exists:restaurant_branches,id'],
            'domain_type' => ['required', Rule::in(['food', 'market', 'pharmacy'])],
            'payment_method' => ['required', Rule::in(['card', 'cash_on_delivery'])],
            'delivery_address' => ['required', 'string', 'max:500'],
            'delivery_lat' => ['nullable', 'numeric', 'between:-90,90'],
            'delivery_lng' => ['nullable', 'numeric', 'between:-180,180'],
            'notes' => ['nullable', 'string', 'max:1000'],
            'coupon_code' => ['nullable', 'string', 'max:50'],

            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['required', 'integer', 'exists:products,id'],
            'items.*.quantity' => ['required', 'integer', 'min:1', 'max:99'],
            'items.*.selected_options' => ['nullable', 'array'],
            'items.*.selected_options.*' => ['integer', 'exists:product_options,id'],
        ];
    }
}
