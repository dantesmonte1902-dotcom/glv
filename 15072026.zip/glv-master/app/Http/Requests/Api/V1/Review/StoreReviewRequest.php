<?php

namespace App\Http\Requests\Api\V1\Review;

use Illuminate\Foundation\Http\FormRequest;

class StoreReviewRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'food_rating' => ['required', 'integer', 'min:1', 'max:5'],
            'delivery_rating' => ['required', 'integer', 'min:1', 'max:5'],
            'comment' => ['nullable', 'string', 'min:10', 'max:1000'],
        ];
    }

    public function messages(): array
    {
        return [
            'food_rating.required' => 'Yemek puanı zorunludur.',
            'food_rating.min' => 'Yemek puanı en az 1 olmalıdır.',
            'food_rating.max' => 'Yemek puanı en fazla 5 olmalıdır.',
            'delivery_rating.required' => 'Teslimat puanı zorunludur.',
            'comment.min' => 'Yorum en az 10 karakter olmalıdır.',
        ];
    }
}
