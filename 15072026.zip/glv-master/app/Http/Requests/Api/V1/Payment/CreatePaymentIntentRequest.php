<?php

namespace App\Http\Requests\Api\V1\Payment;

use Illuminate\Foundation\Http\FormRequest;

class CreatePaymentIntentRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [];
        // Sipariş zaten route model binding ile geliyor,
        // ek doğrulama PaymentService içinde yapılıyor.
    }
}
