<?php

namespace App\Http\Requests\Api\V1\Cart;

use Illuminate\Foundation\Http\FormRequest;

class AddCartItemRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'branch_id'          => ['required', 'integer', 'exists:restaurant_branches,id'],
            'product_id'         => ['required', 'integer', 'exists:products,id'],
            'quantity'           => ['required', 'integer', 'min:1', 'max:99'],
            'selected_options'   => ['nullable', 'array'],
            'selected_options.*' => ['integer', 'exists:product_options,id'],
        ];
    }
}
