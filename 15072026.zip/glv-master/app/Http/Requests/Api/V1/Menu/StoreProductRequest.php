<?php

namespace App\Http\Requests\Api\V1\Menu;

use Illuminate\Foundation\Http\FormRequest;

class StoreProductRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:2000'],
            'image_url' => ['nullable', 'url', 'max:500'],
            'base_price' => ['required', 'numeric', 'min:0'],
            'preparation_time_minutes' => ['nullable', 'integer', 'min:1', 'max:120'],
            'is_available' => ['nullable', 'boolean'],
            'is_active' => ['nullable', 'boolean'],
            'sort_order' => ['nullable', 'integer', 'min:0'],

            'option_groups' => ['nullable', 'array'],
            'option_groups.*.name' => ['required', 'string', 'max:100'],
            'option_groups.*.is_required' => ['boolean'],
            'option_groups.*.is_multiple' => ['boolean'],
            'option_groups.*.min_selections' => ['integer', 'min:0'],
            'option_groups.*.max_selections' => ['integer', 'min:1'],
            'option_groups.*.sort_order' => ['integer'],
            'option_groups.*.options' => ['array'],
            'option_groups.*.options.*.name' => ['required', 'string', 'max:100'],
            'option_groups.*.options.*.price_modifier' => ['numeric'],
            'option_groups.*.options.*.is_default' => ['boolean'],
            'option_groups.*.options.*.sort_order' => ['integer'],
        ];
    }
}
