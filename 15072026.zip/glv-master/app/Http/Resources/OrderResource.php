<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'city_id' => $this->city_id,
            'customer_id' => $this->customer_id,
            'branch_id' => $this->branch_id,
            'domain_type' => $this->domain_type,
            'status' => $this->status->value ?? $this->status,

            // Ödeme
            'payment_method' => $this->payment_method?->value ?? $this->payment_method,
            'payment_method_label' => $this->payment_method?->label(),
            'payment_status' => $this->payment_status,

            // Fiyat dökümü
            'subtotal_amount' => $this->subtotal_amount,
            'delivery_fee' => $this->delivery_fee,
            'service_fee' => $this->service_fee,
            'discount_amount' => $this->discount_amount,
            'total_amount' => $this->total_amount,

            'delivery_address' => $this->delivery_address,
            'delivery_lat' => $this->delivery_lat,
            'delivery_lng' => $this->delivery_lng,
            'notes' => $this->notes,
            'approved_at' => $this->approved_at,
            'delivered_at' => $this->delivered_at,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,

            'city' => $this->whenLoaded('city', fn (): array => [
                'id' => $this->city->id,
                'name' => $this->city->name,
            ]),

            'branch' => $this->whenLoaded('branch', fn (): array => [
                'id' => $this->branch->id,
                'name' => $this->branch->name,
                'address' => $this->branch->address,
                'restaurant' => [
                    'id' => $this->branch->restaurant?->id,
                    'name' => $this->branch->restaurant?->name,
                ],
            ]),

            'coupon' => $this->whenLoaded('coupon', fn (): ?array => $this->coupon ? [
                'code' => $this->coupon->code,
                'type' => $this->coupon->type,
                'value' => $this->coupon->value,
                'discount_applied' => $this->discount_amount,
            ] : null),

            'items' => $this->whenLoaded('items', fn (): array => $this->items->map(
                fn ($item): array => [
                    'id' => $item->id,
                    'product_id' => $item->product_id,
                    'item_name' => $item->item_name,
                    'quantity' => $item->quantity,
                    'unit_price' => $item->unit_price,
                    'line_total' => $item->line_total,
                    'selected_options' => $item->selected_options ?? [],
                ]
            )->all()),

            'payment' => $this->whenLoaded('latestPayment', fn (): ?array => $this->latestPayment
                ? (new PaymentResource($this->latestPayment))->toArray($request)
                : null
            ),

            'courier_assignment' => $this->whenLoaded('courierAssignment', fn (): ?array => $this->courierAssignment ? [
                'courier_id' => $this->courierAssignment->courier_id,
                'status' => $this->courierAssignment->status->value ?? $this->courierAssignment->status,
                'assigned_at' => $this->courierAssignment->assigned_at,
                'accepted_at' => $this->courierAssignment->accepted_at,
                'courier' => $this->courierAssignment->relationLoaded('courier') && $this->courierAssignment->courier
                    ? ['id' => $this->courierAssignment->courier->id, 'name' => $this->courierAssignment->courier->name]
                    : null,
            ] : null),
        ];
    }
}
