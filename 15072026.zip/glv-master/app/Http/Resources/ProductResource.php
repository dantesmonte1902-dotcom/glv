<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'description' => $this->description,
            'image_url' => $this->image_url,
            'base_price' => $this->base_price,
            'preparation_time_minutes' => $this->preparation_time_minutes,
            'is_available' => $this->is_available,
            'option_groups' => $this->whenLoaded('optionGroups', function () {
                return $this->optionGroups->map(fn ($group) => [
                    'id' => $group->id,
                    'name' => $group->name,
                    'is_required' => $group->is_required,
                    'is_multiple' => $group->is_multiple,
                    'min_selections' => $group->min_selections,
                    'max_selections' => $group->max_selections,
                    'options' => $group->activeOptions->map(fn ($opt) => [
                        'id' => $opt->id,
                        'name' => $opt->name,
                        'price_modifier' => $opt->price_modifier,
                        'is_default' => $opt->is_default,
                    ]),
                ]);
            }),
        ];
    }
}
