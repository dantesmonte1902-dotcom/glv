<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ReviewResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'order_id' => $this->order_id,
            'food_rating' => $this->food_rating,
            'delivery_rating' => $this->delivery_rating,
            'average_rating' => $this->averageRating(),
            'comment' => $this->comment,
            'is_visible' => $this->is_visible,
            'reply' => $this->reply,
            'replied_at' => $this->replied_at,
            'created_at' => $this->created_at,

            'customer' => $this->whenLoaded('customer', fn () => [
                'id' => $this->customer->id,
                'name' => $this->customer->name,
            ]),

            'branch' => $this->whenLoaded('branch', fn () => [
                'id' => $this->branch->id,
                'name' => $this->branch->name,
                'restaurant' => $this->branch->relationLoaded('restaurant') ? [
                    'id' => $this->branch->restaurant->id,
                    'name' => $this->branch->restaurant->name,
                ] : null,
            ]),
        ];
    }
}
