<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PaymentResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'order_id' => $this->order_id,
            'method' => $this->method->value ?? $this->method,
            'method_label' => $this->method?->label(),
            'status' => $this->status->value ?? $this->status,
            'status_label' => $this->status?->label(),
            'amount' => $this->amount,
            'currency' => $this->currency,
            'refunded_amount' => $this->refunded_amount,
            'refund_reason' => $this->refund_reason,
            'refunded_at' => $this->refunded_at,
            'paid_at' => $this->paid_at,
            'created_at' => $this->created_at,

            // Kart ödemesi için client_secret — sadece pending durumunda göster
            'client_secret' => $this->when(
                $this->stripe_client_secret && in_array($this->status->value, ['pending', 'processing']),
                $this->stripe_client_secret
            ),

            // Stripe intent id'yi her zaman göster (takip için)
            'stripe_payment_intent_id' => $this->stripe_payment_intent_id,
        ];
    }
}
