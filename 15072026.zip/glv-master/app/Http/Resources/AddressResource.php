<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AddressResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'full_address' => $this->full_address,
            'district' => $this->district,
            'city_name' => $this->city_name,
            'lat' => $this->lat,
            'lng' => $this->lng,
            'notes' => $this->notes,
            'is_default' => $this->is_default,
            'created_at' => $this->created_at,
        ];
    }
}
