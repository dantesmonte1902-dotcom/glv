<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\Analytics\AnalyticsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class AnalyticsController extends Controller
{
    public function __construct(private readonly AnalyticsService $analyticsService) {}

    /**
     * GET /api/v1/analytics/restaurant
     * Restoran sahibinin kendi analitiği.
     * ?period=today|week|month|custom&from=2026-01-01&to=2026-01-31
     */
    public function restaurant(Request $request): JsonResponse
    {
        $user = $request->user();
        $role = $user->role->value ?? $user->role;

        if ($role !== 'restaurant' && $role !== 'admin') {
            abort(403);
        }

        $restaurantId = $role === 'admin'
            ? $request->integer('restaurant_id', 0)
            : $user->restaurant_id;

        if (! $restaurantId) {
            return response()->json(['message' => 'restaurant_id gerekli.'], 422);
        }

        [$from, $to] = $this->resolvePeriod($request);

        return response()->json(
            $this->analyticsService->restaurantSummary($restaurantId, $from, $to)
        );
    }

    /**
     * GET /api/v1/admin/analytics/platform
     * Admin platform geneli analitik.
     */
    public function platform(Request $request): JsonResponse
    {
        [$from, $to] = $this->resolvePeriod($request);

        return response()->json(
            $this->analyticsService->platformSummary($from, $to)
        );
    }

    private function resolvePeriod(Request $request): array
    {
        $period = $request->string('period', 'week');

        return match ($period->value()) {
            'today' => [Carbon::today(), Carbon::now()],
            'month' => [Carbon::now()->startOfMonth(), Carbon::now()],
            'custom' => [
                Carbon::parse($request->string('from', now()->subDays(7))),
                Carbon::parse($request->string('to', now())),
            ],
            default => [Carbon::now()->subDays(7), Carbon::now()], // week
        };
    }
}
