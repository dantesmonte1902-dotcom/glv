<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\MenuResource;
use App\Http\Resources\ProductResource;
use App\Models\RestaurantBranch;
use App\Services\Menu\MenuService;
use Illuminate\Http\JsonResponse;

class MenuController extends Controller
{
    public function __construct(private readonly MenuService $menuService) {}

    /**
     * GET /api/v1/branches/{branch}/menu
     * Şubeye ait tam menüyü kategorilerle döner.
     */
    public function index(RestaurantBranch $branch): JsonResponse
    {
        if (! $branch->is_active) {
            return response()->json(['message' => 'Bu şube aktif değil.'], 404);
        }

        $menu = $this->menuService->getMenuForBranch($branch);

        return response()->json($menu);
    }

    /**
     * GET /api/v1/products/{product}
     * Tek ürün detayı + opsiyon grupları.
     */
    public function show(int $product, RestaurantBranch $branch): JsonResponse
    {
        $productModel = $this->menuService->getProduct($product, $branch->restaurant_id);

        return response()->json(new ProductResource($productModel));
    }
}
