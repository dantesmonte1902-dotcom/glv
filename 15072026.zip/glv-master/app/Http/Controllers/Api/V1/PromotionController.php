<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Promotion;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PromotionController extends Controller
{
    /** GET /api/v1/promotions — public, ana sayfa için */
    public function index(): JsonResponse
    {
        $promotions = Promotion::active()
            ->orderBy('sort_order')
            ->get(['id', 'title', 'description', 'image_url', 'type', 'restaurant_id']);

        return response()->json($promotions);
    }
}
