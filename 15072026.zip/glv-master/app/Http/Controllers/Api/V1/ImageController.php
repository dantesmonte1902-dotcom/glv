<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Services\Media\ImageUploadService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ImageController extends Controller
{
    public function __construct(private readonly ImageUploadService $imageService) {}

    /**
     * POST /api/v1/admin/products/{product}/image
     * Ürün resmi yükle (multipart/form-data).
     * Restoran sahibi veya admin yapabilir.
     */
    public function uploadProductImage(Request $request, Product $product): JsonResponse
    {
        $request->validate([
            'image' => [
                'required',
                'image',
                'mimes:jpeg,png,webp',
                'max:4096', // 4 MB
                'dimensions:min_width=200,min_height=200,max_width=4000,max_height=4000',
            ],
        ]);

        // Yetki kontrolü
        $user = $request->user();
        $role = $user->role->value ?? $user->role;

        if ($role !== 'admin' && (int) $user->restaurant_id !== (int) $product->restaurant_id) {
            abort(403, 'Bu ürünün resmini değiştirme yetkiniz yok.');
        }

        $url = $this->imageService->uploadProductImage($product, $request->file('image'));

        return response()->json([
            'message' => 'Resim başarıyla yüklendi.',
            'image_url' => $url,
        ]);
    }

    /**
     * DELETE /api/v1/admin/products/{product}/image
     * Ürün resmini sil.
     */
    public function deleteProductImage(Request $request, Product $product): JsonResponse
    {
        $user = $request->user();
        $role = $user->role->value ?? $user->role;

        if ($role !== 'admin' && (int) $user->restaurant_id !== (int) $product->restaurant_id) {
            abort(403);
        }

        $this->imageService->delete($product->image_path);

        $product->update(['image_path' => null, 'image_url' => null]);

        return response()->json(['message' => 'Resim silindi.']);
    }
}
