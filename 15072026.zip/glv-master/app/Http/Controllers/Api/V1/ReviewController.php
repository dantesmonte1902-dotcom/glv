<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\Review\StoreReviewRequest;
use App\Http\Resources\ReviewResource;
use App\Models\Order;
use App\Models\RestaurantBranch;
use App\Models\Review;
use App\Services\Review\ReviewService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function __construct(private readonly ReviewService $reviewService) {}

    /**
     * POST /api/v1/orders/{order}/review
     * Teslim edilen sipariş için değerlendirme oluştur.
     */
    public function store(StoreReviewRequest $request, Order $order): JsonResponse
    {
        $review = $this->reviewService->create(
            $request->user(),
            $order,
            $request->validated()
        );

        return response()->json(new ReviewResource($review), 201);
    }

    /**
     * GET /api/v1/branches/{branch}/reviews
     * Şubenin değerlendirmelerini listele (public).
     */
    public function branchReviews(RestaurantBranch $branch, Request $request): JsonResponse
    {
        $paginated = $this->reviewService->listForBranch(
            $branch->id,
            $request->integer('per_page', 10)
        );

        return response()->json([
            'data' => ReviewResource::collection($paginated->items()),
            'summary' => [
                'avg_food_rating' => $branch->avg_food_rating,
                'avg_delivery_rating' => $branch->avg_delivery_rating,
                'review_count' => $branch->review_count,
                'overall' => round(($branch->avg_food_rating + $branch->avg_delivery_rating) / 2, 1),
            ],
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'total' => $paginated->total(),
            ],
        ]);
    }

    /**
     * GET /api/v1/my-reviews
     * Müşterinin kendi değerlendirmeleri.
     */
    public function myReviews(Request $request): JsonResponse
    {
        $paginated = $this->reviewService->listForCustomer(
            $request->user(),
            $request->integer('per_page', 10)
        );

        return response()->json([
            'data' => ReviewResource::collection($paginated->items()),
            'meta' => [
                'current_page' => $paginated->currentPage(),
                'last_page' => $paginated->lastPage(),
                'total' => $paginated->total(),
            ],
        ]);
    }

    /**
     * POST /api/v1/reviews/{review}/reply
     * Restoran değerlendirmeye yanıt verir.
     */
    public function reply(Request $request, Review $review): JsonResponse
    {
        $request->validate([
            'reply' => ['required', 'string', 'max:1000'],
        ]);

        $review = $this->reviewService->reply($request->user(), $review, $request->input('reply'));

        return response()->json(new ReviewResource($review));
    }

    /**
     * PATCH /api/v1/admin/reviews/{review}/toggle-visibility
     * Admin: değerlendirmeyi gizle/göster.
     */
    public function toggleVisibility(Review $review): JsonResponse
    {
        $review = $this->reviewService->toggleVisibility($review);

        return response()->json(new ReviewResource($review));
    }
}
