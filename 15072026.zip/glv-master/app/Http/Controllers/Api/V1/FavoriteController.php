<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\Favorite\FavoriteService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class FavoriteController extends Controller
{
    public function __construct(private readonly FavoriteService $favoriteService) {}

    /** GET /api/v1/favorites */
    public function index(Request $request): JsonResponse
    {
        return response()->json($this->favoriteService->list($request->user()));
    }

    /** POST /api/v1/favorites/{restaurantId}/toggle */
    public function toggle(Request $request, int $restaurantId): JsonResponse
    {
        $result = $this->favoriteService->toggle($request->user(), $restaurantId);
        return response()->json($result);
    }

    /** GET /api/v1/favorites/{restaurantId}/check */
    public function check(Request $request, int $restaurantId): JsonResponse
    {
        $favorited = $this->favoriteService->isFavorited($request->user(), $restaurantId);
        return response()->json(['favorited' => $favorited]);
    }
}
