<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\Address\StoreAddressRequest;
use App\Http\Requests\Api\V1\Address\UpdateAddressRequest;
use App\Http\Resources\AddressResource;
use App\Models\CustomerAddress;
use App\Services\Address\AddressService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AddressController extends Controller
{
    public function __construct(private readonly AddressService $addressService) {}

    /**
     * GET /api/v1/addresses
     * Kullanıcının kayıtlı adreslerini listeler.
     */
    public function index(Request $request): JsonResponse
    {
        $addresses = $this->addressService->list($request->user());

        return response()->json(AddressResource::collection($addresses));
    }

    /**
     * POST /api/v1/addresses
     * Yeni adres ekler.
     */
    public function store(StoreAddressRequest $request): JsonResponse
    {
        $address = $this->addressService->create($request->user(), $request->validated());

        return response()->json(new AddressResource($address), 201);
    }

    /**
     * PATCH /api/v1/addresses/{address}
     * Adresi günceller.
     */
    public function update(UpdateAddressRequest $request, CustomerAddress $address): JsonResponse
    {
        $address = $this->addressService->update($request->user(), $address, $request->validated());

        return response()->json(new AddressResource($address));
    }

    /**
     * DELETE /api/v1/addresses/{address}
     * Adresi siler.
     */
    public function destroy(Request $request, CustomerAddress $address): JsonResponse
    {
        $this->addressService->delete($request->user(), $address);

        return response()->json(['message' => 'Adres silindi.']);
    }

    /**
     * POST /api/v1/addresses/{address}/set-default
     * Seçilen adresi varsayılan yapar.
     */
    public function setDefault(Request $request, CustomerAddress $address): JsonResponse
    {
        $address = $this->addressService->setDefault($request->user(), $address);

        return response()->json(new AddressResource($address));
    }
}
