<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\Cart\AddCartItemRequest;
use App\Http\Requests\Api\V1\Cart\CheckoutSummaryRequest;
use App\Http\Requests\Api\V1\Cart\UpdateCartItemRequest;
use App\Services\Cart\CartService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function __construct(private readonly CartService $cartService) {}

    /**
     * GET /api/v1/cart
     * Mevcut sepeti döner.
     */
    public function index(Request $request): JsonResponse
    {
        return response()->json($this->cartService->getCart($request->user()));
    }

    /**
     * POST /api/v1/cart/items
     * Sepete ürün ekler.
     */
    public function addItem(AddCartItemRequest $request): JsonResponse
    {
        $cart = $this->cartService->addItem($request->user(), $request->validated());

        return response()->json($cart, 201);
    }

    /**
     * PATCH /api/v1/cart/items/{cartItemId}
     * Sepetteki ürün miktarını günceller. quantity=0 → siler.
     */
    public function updateItem(UpdateCartItemRequest $request, string $cartItemId): JsonResponse
    {
        $cart = $this->cartService->updateItem(
            $request->user(),
            $cartItemId,
            $request->validated('quantity')
        );

        return response()->json($cart);
    }

    /**
     * DELETE /api/v1/cart/items/{cartItemId}
     * Sepetten ürün çıkarır.
     */
    public function removeItem(Request $request, string $cartItemId): JsonResponse
    {
        $cart = $this->cartService->removeItem($request->user(), $cartItemId);

        return response()->json($cart);
    }

    /**
     * DELETE /api/v1/cart
     * Sepeti tamamen temizler.
     */
    public function clear(Request $request): JsonResponse
    {
        $this->cartService->clearCart($request->user());

        return response()->json(['message' => 'Sepet temizlendi.']);
    }

    /**
     * POST /api/v1/cart/checkout-summary
     * Sipariş vermeden önce fiyat dökümü + kupon uygulama önizlemesi.
     */
    public function checkoutSummary(CheckoutSummaryRequest $request): JsonResponse
    {
        $summary = $this->cartService->buildCheckoutSummary(
            $request->user(),
            $request->validated('coupon_code'),
            $request->has('delivery_lat') ? (float) $request->validated('delivery_lat') : null,
            $request->has('delivery_lng') ? (float) $request->validated('delivery_lng') : null,
            (int) ($request->validated('redeem_points') ?? 0),
        );

        return response()->json($summary);
    }
}
