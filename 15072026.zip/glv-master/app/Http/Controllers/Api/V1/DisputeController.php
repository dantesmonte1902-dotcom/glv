<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Dispute;
use App\Models\Order;
use App\Services\Support\DisputeService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class DisputeController extends Controller
{
    public function __construct(private readonly DisputeService $disputeService) {}

    /**
     * POST /api/v1/orders/{order}/disputes
     */
    public function store(Request $request, Order $order): JsonResponse
    {
        $validated = $request->validate([
            'type' => ['required', Rule::in(['missing_item', 'wrong_item', 'quality_issue', 'never_arrived', 'other'])],
            'description' => ['required', 'string', 'max:1000'],
            'photo_url' => ['nullable', 'string', 'max:500'],
        ]);

        $dispute = $this->disputeService->create($request->user(), $order, $validated);

        return response()->json($dispute, 201);
    }

    /**
     * GET /api/v1/disputes — müşterinin kendi itirazları
     */
    public function index(Request $request): JsonResponse
    {
        $disputes = Dispute::query()
            ->where('customer_id', $request->user()->id)
            ->with('order:id,total_amount,delivered_at')
            ->orderByDesc('created_at')
            ->paginate(20);

        return response()->json($disputes);
    }

    public function show(Request $request, Dispute $dispute): JsonResponse
    {
        if ($dispute->customer_id !== $request->user()->id && ! $request->user()->isAdmin()) {
            abort(403);
        }

        return response()->json($dispute->load('order', 'resolver:id,name'));
    }
}
