<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\SupportTicket;
use App\Services\Support\SupportService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SupportController extends Controller
{
    public function __construct(private readonly SupportService $supportService) {}

    /**
     * GET /api/v1/support/tickets
     */
    public function index(Request $request): JsonResponse
    {
        $tickets = $this->supportService->listForUser($request->user())->paginate(20);

        return response()->json($tickets);
    }

    /**
     * POST /api/v1/support/tickets
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'subject' => ['required', 'string', 'max:255'],
            'message' => ['required', 'string', 'max:2000'],
            'order_id' => ['nullable', 'integer', 'exists:orders,id'],
        ]);

        $ticket = $this->supportService->createTicket($request->user(), $validated);

        return response()->json($ticket->load('messages'), 201);
    }

    /**
     * GET /api/v1/support/tickets/{ticket}
     */
    public function show(Request $request, SupportTicket $ticket): JsonResponse
    {
        $this->ensureAccess($request, $ticket);

        return response()->json($ticket->load('messages.sender:id,name,role'));
    }

    /**
     * POST /api/v1/support/tickets/{ticket}/messages
     */
    public function postMessage(Request $request, SupportTicket $ticket): JsonResponse
    {
        $this->ensureAccess($request, $ticket);

        $validated = $request->validate([
            'message' => ['required', 'string', 'max:2000'],
        ]);

        $isStaff = $request->user()->isAdmin();
        $message = $this->supportService->postMessage($request->user(), $ticket, $validated['message'], $isStaff);

        return response()->json($message, 201);
    }

    private function ensureAccess(Request $request, SupportTicket $ticket): void
    {
        if ($ticket->user_id !== $request->user()->id && ! $request->user()->isAdmin()) {
            abort(403, 'Bu destek talebine erişim yetkiniz yok.');
        }
    }
}
