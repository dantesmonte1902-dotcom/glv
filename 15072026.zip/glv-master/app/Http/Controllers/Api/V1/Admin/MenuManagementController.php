<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\Menu\StoreCategoryRequest;
use App\Http\Requests\Api\V1\Menu\StoreProductRequest;
use App\Http\Requests\Api\V1\Menu\UpdateProductRequest;
use App\Models\MenuCategory;
use App\Models\Product;
use App\Models\ProductOption;
use App\Models\ProductOptionGroup;
use App\Models\Restaurant;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class MenuManagementController extends Controller
{
    // ─── Kategoriler ────────────────────────────────────────────────────────────

    /**
     * GET /api/v1/admin/restaurants/{restaurant}/categories
     */
    public function categories(Restaurant $restaurant): JsonResponse
    {
        $this->authorizeRestaurant($restaurant);

        return response()->json(
            $restaurant->categories()->orderBy('sort_order')->with('activeProducts')->get()
        );
    }

    /**
     * POST /api/v1/admin/restaurants/{restaurant}/categories
     */
    public function storeCategory(StoreCategoryRequest $request, Restaurant $restaurant): JsonResponse
    {
        $this->authorizeRestaurant($restaurant);

        $category = $restaurant->categories()->create([
            'name' => $request->validated('name'),
            'slug' => Str::slug($request->validated('name')),
            'sort_order' => $request->validated('sort_order', 0),
            'is_active' => $request->validated('is_active', true),
        ]);

        return response()->json($category, 201);
    }

    /**
     * PATCH /api/v1/admin/categories/{category}
     */
    public function updateCategory(Request $request, MenuCategory $category): JsonResponse
    {
        $this->authorizeRestaurant($category->restaurant);

        $category->update($request->only(['name', 'sort_order', 'is_active']));

        if ($request->has('name')) {
            $category->update(['slug' => Str::slug($request->name)]);
        }

        return response()->json($category);
    }

    // ─── Ürünler ─────────────────────────────────────────────────────────────

    /**
     * GET /api/v1/admin/categories/{category}/products
     */
    public function products(MenuCategory $category): JsonResponse
    {
        $this->authorizeRestaurant($category->restaurant);

        return response()->json(
            $category->products()->orderBy('sort_order')->with('optionGroups.options')->get()
        );
    }

    /**
     * POST /api/v1/admin/categories/{category}/products
     */
    public function storeProduct(StoreProductRequest $request, MenuCategory $category): JsonResponse
    {
        $this->authorizeRestaurant($category->restaurant);

        $product = $category->products()->create([
            'restaurant_id' => $category->restaurant_id,
            'name' => $request->validated('name'),
            'slug' => Str::slug($request->validated('name')),
            'description' => $request->validated('description'),
            'image_url' => $request->validated('image_url'),
            'base_price' => $request->validated('base_price'),
            'preparation_time_minutes' => $request->validated('preparation_time_minutes', 15),
            'is_available' => $request->validated('is_available', true),
            'is_active' => $request->validated('is_active', true),
            'sort_order' => $request->validated('sort_order', 0),
        ]);

        // Opsiyon grupları varsa oluştur
        foreach ($request->validated('option_groups', []) as $groupData) {
            $group = $product->optionGroups()->create([
                'name' => $groupData['name'],
                'is_required' => $groupData['is_required'] ?? false,
                'is_multiple' => $groupData['is_multiple'] ?? false,
                'min_selections' => $groupData['min_selections'] ?? 0,
                'max_selections' => $groupData['max_selections'] ?? 1,
                'sort_order' => $groupData['sort_order'] ?? 0,
            ]);

            foreach ($groupData['options'] ?? [] as $optionData) {
                $group->options()->create([
                    'name' => $optionData['name'],
                    'price_modifier' => $optionData['price_modifier'] ?? 0,
                    'is_default' => $optionData['is_default'] ?? false,
                    'is_active' => true,
                    'sort_order' => $optionData['sort_order'] ?? 0,
                ]);
            }
        }

        return response()->json($product->load('optionGroups.options'), 201);
    }

    /**
     * PATCH /api/v1/admin/products/{product}
     */
    public function updateProduct(UpdateProductRequest $request, Product $product): JsonResponse
    {
        $this->authorizeRestaurant($product->restaurant);

        $product->update($request->validated());

        if ($request->has('name')) {
            $product->update(['slug' => Str::slug($request->name)]);
        }

        return response()->json($product->fresh()->load('optionGroups.options'));
    }

    /**
     * DELETE /api/v1/admin/products/{product}
     * Soft-delete yerine is_active=false yaparak pasife alır.
     */
    public function deactivateProduct(Product $product): JsonResponse
    {
        $this->authorizeRestaurant($product->restaurant);

        $product->update(['is_active' => false]);

        return response()->json(['message' => 'Ürün pasife alındı.']);
    }

    // ─── Opsiyon Grupları ────────────────────────────────────────────────────

    /**
     * POST /api/v1/admin/products/{product}/option-groups
     */
    public function storeOptionGroup(Request $request, Product $product): JsonResponse
    {
        $this->authorizeRestaurant($product->restaurant);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'is_required' => ['boolean'],
            'is_multiple' => ['boolean'],
            'min_selections' => ['integer', 'min:0'],
            'max_selections' => ['integer', 'min:1'],
            'sort_order' => ['integer'],
            'options' => ['array'],
            'options.*.name' => ['required', 'string', 'max:100'],
            'options.*.price_modifier' => ['numeric'],
            'options.*.is_default' => ['boolean'],
            'options.*.sort_order' => ['integer'],
        ]);

        $group = $product->optionGroups()->create($validated);

        foreach ($validated['options'] ?? [] as $opt) {
            $group->options()->create(array_merge($opt, ['is_active' => true]));
        }

        return response()->json($group->load('options'), 201);
    }

    /**
     * DELETE /api/v1/admin/option-groups/{group}
     */
    public function destroyOptionGroup(ProductOptionGroup $group): JsonResponse
    {
        $this->authorizeRestaurant($group->product->restaurant);

        $group->delete();

        return response()->json(['message' => 'Opsiyon grubu silindi.']);
    }

    // ─── Yardımcı ────────────────────────────────────────────────────────────

    private function authorizeRestaurant(Restaurant $restaurant): void
    {
        $user = request()->user();

        if ($user->role->value === 'admin') {
            return;
        }

        if (! $user->ownsRestaurantId($restaurant->id)) {
            abort(403, 'Bu restorana erişim yetkiniz yok.');
        }
    }
}
