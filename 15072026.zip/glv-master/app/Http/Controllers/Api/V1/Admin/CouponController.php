<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CouponController extends Controller
{
    /**
     * GET /api/v1/admin/coupons
     */
    public function index(Request $request): JsonResponse
    {
        $coupons = Coupon::query()
            ->with('restaurant:id,name')
            ->when($request->boolean('active_only'), fn ($q) => $q->where('is_active', true))
            ->orderByDesc('created_at')
            ->paginate(20);

        return response()->json($coupons);
    }

    /**
     * POST /api/v1/admin/coupons
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'code' => ['required', 'string', 'max:50', 'unique:coupons,code'],
            'type' => ['required', 'in:percentage,fixed'],
            'value' => ['required', 'numeric', 'min:0'],
            'minimum_order_amount' => ['nullable', 'numeric', 'min:0'],
            'maximum_discount' => ['nullable', 'numeric', 'min:0'],
            'restaurant_id' => ['nullable', 'integer', 'exists:restaurants,id'],
            'usage_limit' => ['nullable', 'integer', 'min:1'],
            'per_user_limit' => ['nullable', 'integer', 'min:1'],
            'starts_at' => ['nullable', 'date'],
            'expires_at' => ['nullable', 'date', 'after_or_equal:starts_at'],
            'is_active' => ['boolean'],
        ]);

        $validated['code'] = strtoupper($validated['code']);

        $coupon = Coupon::query()->create($validated);

        return response()->json($coupon, 201);
    }

    /**
     * GET /api/v1/admin/coupons/{coupon}
     */
    public function show(Coupon $coupon): JsonResponse
    {
        return response()->json($coupon->load('restaurant:id,name'));
    }

    /**
     * PATCH /api/v1/admin/coupons/{coupon}
     */
    public function update(Request $request, Coupon $coupon): JsonResponse
    {
        $validated = $request->validate([
            'type' => ['sometimes', 'in:percentage,fixed'],
            'value' => ['sometimes', 'numeric', 'min:0'],
            'minimum_order_amount' => ['nullable', 'numeric', 'min:0'],
            'maximum_discount' => ['nullable', 'numeric', 'min:0'],
            'restaurant_id' => ['nullable', 'integer', 'exists:restaurants,id'],
            'usage_limit' => ['nullable', 'integer', 'min:1'],
            'per_user_limit' => ['nullable', 'integer', 'min:1'],
            'starts_at' => ['nullable', 'date'],
            'expires_at' => ['nullable', 'date'],
            'is_active' => ['boolean'],
        ]);

        $coupon->update($validated);

        return response()->json($coupon->fresh());
    }

    /**
     * DELETE /api/v1/admin/coupons/{coupon}
     * Pasife alır, silmez — sipariş geçmişi bozulmasın.
     */
    public function destroy(Coupon $coupon): JsonResponse
    {
        $coupon->update(['is_active' => false]);

        return response()->json(['message' => 'Kupon pasife alındı.']);
    }

    /**
     * GET /api/v1/coupons/validate?code=ABC&branch_id=1
     * Müşteri kuponu kontrol eder (public endpoint).
     */
    public function validateCoupon(Request $request): JsonResponse
    {
        $request->validate([
            'code' => ['required', 'string'],
            'branch_id' => ['required', 'integer', 'exists:restaurant_branches,id'],
        ]);

        $coupon = Coupon::query()
            ->where('code', strtoupper(trim($request->code)))
            ->first();

        if (! $coupon || ! $coupon->isCurrentlyValid()) {
            return response()->json(['valid' => false, 'message' => 'Geçersiz veya süresi dolmuş kupon.'], 422);
        }

        $user = $request->user();
        if ($coupon->usageCountForUser($user->id) >= $coupon->per_user_limit) {
            return response()->json(['valid' => false, 'message' => 'Bu kuponu kullanım limitinize ulaştınız.'], 422);
        }

        return response()->json([
            'valid' => true,
            'coupon' => [
                'code' => $coupon->code,
                'type' => $coupon->type,
                'value' => $coupon->value,
                'minimum_order_amount' => $coupon->minimum_order_amount,
                'maximum_discount' => $coupon->maximum_discount,
                'expires_at' => $coupon->expires_at,
            ],
        ]);
    }
}
