<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\Courier\CourierEarningService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class CourierEarningController extends Controller
{
    public function __construct(private readonly CourierEarningService $courierEarningService) {}

    /**
     * GET /api/v1/courier/earnings/summary
     * ?period=today|week|month|custom&from=2026-01-01&to=2026-01-31
     */
    public function summary(Request $request): JsonResponse
    {
        [$from, $to] = $this->resolvePeriod($request);

        return response()->json(
            $this->courierEarningService->summary($request->user(), $from, $to)
        );
    }

    /**
     * GET /api/v1/courier/earnings
     * Kuryenin geçmiş kazanç dökümü (sayfalanmış).
     */
    public function index(Request $request): JsonResponse
    {
        [$from, $to] = $this->resolvePeriod($request);

        $earnings = $this->courierEarningService->list($request->user(), $from, $to);

        return response()->json($earnings);
    }

    private function resolvePeriod(Request $request): array
    {
        $period = $request->string('period', 'week');

        return match ($period->value()) {
            'today' => [Carbon::today(), Carbon::now()],
            'month' => [Carbon::now()->startOfMonth(), Carbon::now()],
            'custom' => [
                Carbon::parse($request->string('from', now()->subDays(7))),
                Carbon::parse($request->string('to', now())),
            ],
            default => [Carbon::now()->subDays(7), Carbon::now()], // week
        };
    }
}
