<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\Loyalty\LoyaltyService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class LoyaltyController extends Controller
{
    public function __construct(private readonly LoyaltyService $loyaltyService) {}

    /**
     * GET /api/v1/loyalty/summary
     * Puan bakiyesi + referans kodu + referans özeti tek çağrıda.
     */
    public function summary(Request $request): JsonResponse
    {
        $user = $this->ensureReferralCode($request->user());

        return response()->json([
            'points_balance' => $this->loyaltyService->balance($user),
            'points_to_km_rate' => 100, // 100 puan = 1 KM (bilgi amaçlı, backend'de sabit)
            'referral' => $this->loyaltyService->referralStats($user),
        ]);
    }

    /**
     * GET /api/v1/loyalty/history
     */
    public function history(Request $request): JsonResponse
    {
        return response()->json(
            $this->loyaltyService->history($request->user())
        );
    }

    /**
     * Eski kullanıcılarda (bu özellikten önce kayıt olmuş) referans kodu
     * olmayabilir — ilk istekte tembel (lazy) üretilir.
     */
    private function ensureReferralCode(User $user): User
    {
        if (! $user->referral_code) {
            $user->forceFill(['referral_code' => User::generateUniqueReferralCode()])->save();
        }

        return $user;
    }
}
