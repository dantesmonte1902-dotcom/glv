<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\OrderResource;
use App\Models\Order;
use App\Services\Cart\CartService;
use App\Services\Orders\OrderService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function __construct(
        private readonly OrderService $orderService,
        private readonly CartService $cartService,
    ) {}

    /**
     * POST /api/v1/orders
     */
    public function store(\App\Http\Requests\Api\V1\Orders\StoreOrderRequest $request): JsonResponse
    {
        $order = $this->orderService->create($request->user(), $request->validated());

        return response()->json(new OrderResource($order), 201);
    }

    /**
     * GET /api/v1/orders/{order}
     */
    public function show(Request $request, Order $order): JsonResponse
    {
        $order = $this->orderService->showForUser($request->user(), $order);

        return response()->json(new OrderResource($order));
    }

    /**
     * GET /api/v1/orders
     * Müşterinin sipariş geçmişi — sayfalı, en yeniden eskiye.
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();
        $role = $user->role->value ?? $user->role;

        $query = Order::query()
            ->with(['branch.restaurant', 'items', 'latestPayment', 'courierAssignment'])
            ->orderByDesc('created_at');

        // Role göre filtrele
        match ($role) {
            'customer' => $query->where('customer_id', $user->id),
            'restaurant' => $query->whereHas('branch', fn ($q) => $q->where('restaurant_id', $user->restaurant_id)),
            'courier' => $query->whereHas('courierAssignment', fn ($q) => $q->where('courier_id', $user->id)),
            default => null, // admin: hepsini görür
        };

        // Durum filtresi (opsiyonel)
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Tarih filtresi (opsiyonel)
        if ($request->filled('date')) {
            $query->whereDate('created_at', $request->date);
        }

        $orders = $query->paginate($request->integer('per_page', 15));

        return response()->json([
            'data' => OrderResource::collection($orders->items()),
            'meta' => [
                'current_page' => $orders->currentPage(),
                'last_page' => $orders->lastPage(),
                'per_page' => $orders->perPage(),
                'total' => $orders->total(),
            ],
        ]);
    }

    /**
     * POST /api/v1/orders/{order}/approve
     */
    public function approve(Request $request, Order $order): JsonResponse
    {
        $order = $this->orderService->approve($request->user(), $order);

        return response()->json(new OrderResource($order));
    }

    /**
     * POST /api/v1/orders/{order}/reject
     */
    public function reject(Request $request, Order $order): JsonResponse
    {
        $order = $this->orderService->reject(
            $request->user(),
            $order,
            $request->input('reason')
        );

        return response()->json(new OrderResource($order));
    }

    /**
     * POST /api/v1/orders/{order}/reorder — geçmiş siparişi sepete yeniden ekler
     */
    public function reorder(Request $request, Order $order): JsonResponse
    {
        if ($order->customer_id !== $request->user()->id) {
            abort(403, 'Bu siparişi yeniden veremezsiniz.');
        }

        $result = $this->cartService->reorder($request->user(), $order);

        return response()->json($result);
    }

    /**
     * POST /api/v1/orders/{order}/cancel — müşterinin kendi siparişini iptali
     */
    public function cancel(Request $request, Order $order): JsonResponse
    {
        $order = $this->orderService->cancel(
            $request->user(),
            $order,
            $request->input('reason')
        );

        return response()->json(new OrderResource($order));
    }

    /**
     * POST /api/v1/orders/{order}/assign-courier
     */
    public function assignCourier(Request $request, Order $order): JsonResponse
    {
        $assignment = $this->orderService->dispatchAssignment($request->user(), $order);

        return response()->json($assignment);
    }

    /**
     * POST /api/v1/orders/{order}/accept-courier
     */
    public function acceptCourier(Request $request, Order $order): JsonResponse
    {
        $assignment = $order->courierAssignment;

        if (! $assignment || $assignment->courier_id !== $request->user()->id) {
            abort(403, 'Bu sipariş size atanmamış.');
        }

        $assignment->update([
            'status' => 'accepted',
            'accepted_at' => now(),
        ]);

        return response()->json($assignment->fresh());
    }

    /**
     * POST /api/v1/orders/{order}/reject-courier
     */
    public function rejectCourier(Request $request, Order $order): JsonResponse
    {
        $assignment = $order->courierAssignment;

        if (! $assignment || $assignment->courier_id !== $request->user()->id) {
            abort(403, 'Bu sipariş size atanmamış.');
        }

        $assignment->update(['status' => 'rejected']);

        // Yeni kurye ara
        \App\Jobs\Orders\AssignCourierJob::dispatch($order->id);

        return response()->json(['message' => 'Sipariş reddedildi, yeni kurye aranıyor.']);
    }

    /**
     * POST /api/v1/orders/{order}/deliver
     */
    public function deliver(Request $request, Order $order): JsonResponse
    {
        $order = $this->orderService->deliver($request->user(), $order);

        return response()->json(new OrderResource($order));
    }
}
