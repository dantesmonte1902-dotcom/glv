<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\RestaurantBranch;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CityBranchController extends Controller
{
    /**
     * GET /api/v1/cities/{city}/branches
     * Bir şehirdeki tüm aktif restoran şubelerini listeler (public, ana sayfa için).
     * Arama, sıralama destekler.
     */
    public function index(Request $request, int $cityId): JsonResponse
    {
        $query = RestaurantBranch::query()
            ->where('city_id', $cityId)
            ->where('is_active', true)
            ->with('restaurant:id,name')
            ->select([
                'id', 'restaurant_id', 'name', 'is_open',
                'estimated_delivery_minutes', 'minimum_order_amount',
                'avg_food_rating', 'avg_delivery_rating', 'review_count',
            ]);

        // Arama (restoran adına göre)
        if ($request->filled('search')) {
            $search = $request->string('search');
            $query->whereHas('restaurant', fn ($q) => $q->where('name', 'like', "%{$search}%"));
        }

        // Sıralama: önce açık olanlar, sonra puan
        $branches = $query
            ->orderByDesc('is_open')
            ->orderByDesc('avg_food_rating')
            ->get();

        $data = $branches->map(fn (RestaurantBranch $branch) => [
            'id' => $branch->id,
            'name' => $branch->name,
            'is_open' => $branch->is_open,
            'estimated_delivery_minutes' => $branch->estimated_delivery_minutes,
            'minimum_order_amount' => $branch->minimum_order_amount,
            'avg_food_rating' => $branch->avg_food_rating,
            'avg_delivery_rating' => $branch->avg_delivery_rating,
            'review_count' => $branch->review_count,
            'image_url' => null, // gelecekte restoran kapak resmi eklenebilir
            'restaurant' => [
                'id' => $branch->restaurant->id,
                'name' => $branch->restaurant->name,
            ],
        ]);

        return response()->json(['data' => $data]);
    }
}
