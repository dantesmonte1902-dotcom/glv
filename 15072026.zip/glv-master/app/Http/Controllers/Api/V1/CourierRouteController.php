<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\Courier\RouteOptimizationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CourierRouteController extends Controller
{
    public function __construct(private readonly RouteOptimizationService $routeOptimizationService) {}

    /**
     * GET /api/v1/courier/route
     * Kuryenin üzerindeki kabul edilmiş tüm siparişler için optimize edilmiş durak sırası.
     */
    public function current(Request $request): JsonResponse
    {
        return response()->json(
            $this->routeOptimizationService->buildRoute($request->user())
        );
    }
}
