<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\Payment\CreatePaymentIntentRequest;
use App\Http\Requests\Api\V1\Payment\RefundRequest;
use App\Http\Resources\PaymentResource;
use App\Models\Order;
use App\Services\Payment\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Stripe\Exception\SignatureVerificationException;
use Stripe\Webhook;

class PaymentController extends Controller
{
    public function __construct(private readonly PaymentService $paymentService) {}

    /**
     * POST /api/v1/orders/{order}/payment/intent
     * Kart ödemesi için Stripe PaymentIntent oluşturur.
     * Flutter/web uygulaması bu client_secret ile ödemeyi tamamlar.
     */
    public function createIntent(CreatePaymentIntentRequest $request, Order $order): JsonResponse
    {
        $result = $this->paymentService->createPaymentIntent($order, $request->user());

        return response()->json([
            'payment_id' => $result['payment_id'],
            'client_secret' => $result['client_secret'],
            'payment_intent_id' => $result['payment_intent_id'],
            'amount' => $order->total_amount,
            'currency' => 'BAM',
        ]);
    }

    /**
     * POST /api/v1/orders/{order}/payment/cash
     * Kapıda ödeme kaydı oluşturur.
     * Sipariş oluşturulurken payment_method=cash_on_delivery seçilmişse çağrılır.
     */
    public function createCash(Request $request, Order $order): JsonResponse
    {
        if ($order->customer_id !== $request->user()->id) {
            abort(403);
        }

        $payment = $this->paymentService->createCashPayment($order);

        return response()->json(new PaymentResource($payment), 201);
    }

    /**
     * POST /api/v1/orders/{order}/payment/cash/complete
     * Kurye teslim ettiğinde kapıda ödemeyi tamamlar.
     */
    public function completeCash(Request $request, Order $order): JsonResponse
    {
        $payment = $this->paymentService->completeCashPayment($order);

        return response()->json(new PaymentResource($payment));
    }

    /**
     * GET /api/v1/orders/{order}/payment
     * Siparişe ait ödeme bilgilerini döner.
     */
    public function show(Request $request, Order $order): JsonResponse
    {
        if ($order->customer_id !== $request->user()->id
            && ! in_array($request->user()->role->value ?? $request->user()->role, ['admin', 'restaurant'])) {
            abort(403);
        }

        $payment = $order->latestPayment;

        if (! $payment) {
            return response()->json(['message' => 'Henüz ödeme kaydı yok.'], 404);
        }

        return response()->json(new PaymentResource($payment));
    }

    /**
     * POST /api/v1/admin/orders/{order}/payment/refund
     * İade işlemi (sadece admin).
     */
    public function refund(RefundRequest $request, Order $order): JsonResponse
    {
        $payment = $this->paymentService->refund(
            $order,
            $request->validated('amount'),
            $request->validated('reason')
        );

        return response()->json(new PaymentResource($payment));
    }

    /**
     * POST /api/v1/webhooks/stripe
     * Stripe'tan gelen webhook event'lerini işler.
     * Bu endpoint auth middleware'den muaf olmalı — Stripe imzalama ile korunur.
     */
    public function stripeWebhook(Request $request): JsonResponse
    {
        $payload = $request->getContent();
        $sigHeader = $request->header('Stripe-Signature');
        $secret = config('services.stripe.webhook_secret');

        try {
            $event = Webhook::constructEvent($payload, $sigHeader, $secret);
        } catch (SignatureVerificationException $e) {
            Log::warning('Stripe webhook imza hatası', ['error' => $e->getMessage()]);

            return response()->json(['error' => 'Invalid signature'], 400);
        }

        $this->paymentService->handleWebhook($event->toArray());

        return response()->json(['status' => 'ok']);
    }
}
