<?php

namespace App\Jobs\Notification;

use App\Models\Order;
use App\Services\Notification\NotificationService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;

class SendOrderNotificationJob implements ShouldQueue
{
    use Queueable;

    public int $tries = 3;
    public int $backoff = 10;

    public function __construct(
        private readonly int $orderId,
        private readonly string $event,    // approved, rejected, out_for_delivery, delivered, new_order
        private readonly ?int $courierId = null,
        private readonly ?string $reason = null,
    ) {
        $this->onQueue('notifications');
    }

    public function handle(NotificationService $service): void
    {
        $order = Order::with(['branch.restaurant', 'branch'])->find($this->orderId);

        if (! $order) {
            return;
        }

        match ($this->event) {
            'approved' => $service->notifyOrderApproved($order),
            'rejected' => $service->notifyOrderRejected($order, $this->reason),
            'cancelled' => $service->notifyOrderCancelled($order),
            'out_for_delivery' => $service->notifyOrderOutForDelivery($order),
            'delivered' => $service->notifyOrderDelivered($order),
            'new_order' => $service->notifyRestaurantNewOrder($order),
            'courier_assigned' => $service->notifyCourierNewAssignment($order, $this->courierId),
            default => null,
        };
    }
}
