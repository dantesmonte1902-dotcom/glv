<?php

namespace App\Jobs\Notification;

use App\Models\Campaign;
use App\Services\Notification\NotificationService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;

class SendCampaignJob implements ShouldQueue
{
    use Queueable;

    public int $tries = 3;
    public int $backoff = 10;

    /**
     * @param  array<int, int>  $userIds
     */
    public function __construct(
        private readonly int $campaignId,
        private readonly array $userIds,
    ) {
        $this->onQueue('notifications');
    }

    public function handle(NotificationService $service): void
    {
        $campaign = Campaign::find($this->campaignId);

        if (! $campaign) {
            return;
        }

        foreach ($this->userIds as $userId) {
            $service->sendCustom($userId, $campaign->message_title, $campaign->message_body, [
                'campaign_id' => (string) $campaign->id,
            ]);
        }
    }
}
