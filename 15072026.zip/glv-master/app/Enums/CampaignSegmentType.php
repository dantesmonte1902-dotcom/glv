<?php

namespace App\Enums;

enum CampaignSegmentType: string
{
    case ALL = 'all';
    case INACTIVE_CUSTOMERS = 'inactive_customers';
    case CITY = 'city';

    public function label(): string
    {
        return match ($this) {
            self::ALL => 'Tüm Müşteriler',
            self::INACTIVE_CUSTOMERS => 'Uzun Süredir Sipariş Vermeyenler',
            self::CITY => 'Belirli Şehir',
        };
    }
}
