<?php

namespace App\Enums;

enum DisputeType: string
{
    case MISSING_ITEM = 'missing_item';
    case WRONG_ITEM = 'wrong_item';
    case QUALITY_ISSUE = 'quality_issue';
    case NEVER_ARRIVED = 'never_arrived';
    case OTHER = 'other';

    public function label(): string
    {
        return match ($this) {
            self::MISSING_ITEM => 'Eksik Ürün',
            self::WRONG_ITEM => 'Yanlış Ürün',
            self::QUALITY_ISSUE => 'Kalite Sorunu',
            self::NEVER_ARRIVED => 'Sipariş Hiç Gelmedi',
            self::OTHER => 'Diğer',
        };
    }
}
