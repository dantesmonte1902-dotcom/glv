<?php

namespace App\Enums;

enum LoyaltyPointTransactionType: string
{
    case EARN = 'earn';
    case REDEEM = 'redeem';
    case REFUND = 'refund';
    case REFERRAL_BONUS = 'referral_bonus';
    case REFERRAL_SIGNUP_BONUS = 'referral_signup_bonus';
    case ADJUSTMENT = 'adjustment';

    public function label(): string
    {
        return match ($this) {
            self::EARN => 'Kazanım',
            self::REDEEM => 'Harcama',
            self::REFUND => 'İade',
            self::REFERRAL_BONUS => 'Referans Bonusu',
            self::REFERRAL_SIGNUP_BONUS => 'Hoş Geldin Bonusu',
            self::ADJUSTMENT => 'Manuel Düzeltme',
        };
    }
}
