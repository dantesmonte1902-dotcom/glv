<?php

namespace App\Enums;

enum CourierPayoutStatus: string
{
    case PENDING = 'pending';
    case PAID = 'paid';

    public function label(): string
    {
        return match ($this) {
            self::PENDING => 'Bekliyor',
            self::PAID => 'Ödendi',
        };
    }
}
