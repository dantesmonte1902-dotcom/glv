<?php

namespace App\Enums;

enum SupportTicketStatus: string
{
    case OPEN = 'open';
    case IN_PROGRESS = 'in_progress';
    case CLOSED = 'closed';

    public function label(): string
    {
        return match ($this) {
            self::OPEN => 'Açık',
            self::IN_PROGRESS => 'İşlemde',
            self::CLOSED => 'Kapalı',
        };
    }
}
