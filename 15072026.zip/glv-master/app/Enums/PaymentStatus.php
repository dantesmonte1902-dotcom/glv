<?php

namespace App\Enums;

enum PaymentStatus: string
{
    case PENDING = 'pending';
    case PROCESSING = 'processing';
    case SUCCEEDED = 'succeeded';
    case FAILED = 'failed';
    case REFUNDED = 'refunded';
    case PARTIALLY_REFUNDED = 'partially_refunded';

    public function label(): string
    {
        return match ($this) {
            self::PENDING => 'Bekliyor',
            self::PROCESSING => 'İşleniyor',
            self::SUCCEEDED => 'Başarılı',
            self::FAILED => 'Başarısız',
            self::REFUNDED => 'İade Edildi',
            self::PARTIALLY_REFUNDED => 'Kısmi İade',
        };
    }

    public function isTerminal(): bool
    {
        return in_array($this, [self::SUCCEEDED, self::FAILED, self::REFUNDED]);
    }
}
