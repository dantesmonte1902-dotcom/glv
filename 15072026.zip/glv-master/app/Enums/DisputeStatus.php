<?php

namespace App\Enums;

enum DisputeStatus: string
{
    case OPEN = 'open';
    case UNDER_REVIEW = 'under_review';
    case RESOLVED = 'resolved';
    case REJECTED = 'rejected';

    public function label(): string
    {
        return match ($this) {
            self::OPEN => 'Açık',
            self::UNDER_REVIEW => 'İnceleniyor',
            self::RESOLVED => 'Çözüldü',
            self::REJECTED => 'Reddedildi',
        };
    }
}
