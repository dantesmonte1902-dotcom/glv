<?php

namespace App\Enums;

enum DisputeResolutionType: string
{
    case REFUND = 'refund';
    case COMPENSATE_POINTS = 'compensate_points';
    case NONE = 'none';

    public function label(): string
    {
        return match ($this) {
            self::REFUND => 'Para İadesi',
            self::COMPENSATE_POINTS => 'Puan Telafisi',
            self::NONE => 'Telafi Yok',
        };
    }
}
