<?php

namespace App\Enums;

enum PaymentMethod: string
{
    case CARD = 'card';
    case CASH_ON_DELIVERY = 'cash_on_delivery';

    public function label(): string
    {
        return match ($this) {
            self::CARD => 'Kredi/Banka Kartı',
            self::CASH_ON_DELIVERY => 'Kapıda Ödeme',
        };
    }
}
