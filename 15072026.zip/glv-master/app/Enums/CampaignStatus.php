<?php

namespace App\Enums;

enum CampaignStatus: string
{
    case DRAFT = 'draft';
    case SENT = 'sent';

    public function label(): string
    {
        return match ($this) {
            self::DRAFT => 'Taslak',
            self::SENT => 'Gönderildi',
        };
    }
}
