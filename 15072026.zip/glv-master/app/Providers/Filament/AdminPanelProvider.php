<?php

namespace App\Providers\Filament;

use App\Filament\Admin\Pages\Dashboard;
use App\Filament\Admin\Resources\CityResource;
use App\Filament\Admin\Resources\CampaignResource;
use App\Filament\Admin\Resources\CouponResource;
use App\Filament\Admin\Resources\CourierPayoutResource;
use App\Filament\Admin\Resources\DisputeResource;
use App\Filament\Admin\Resources\OrderResource;
use App\Filament\Admin\Resources\RestaurantResource;
use App\Filament\Admin\Resources\ReviewResource;
use App\Filament\Admin\Resources\SupportTicketResource;
use App\Filament\Admin\Resources\UserResource;
use App\Filament\Admin\Widgets\FlaggedCouriersWidget;
use App\Filament\Admin\Widgets\FlaggedCustomersWidget;
use App\Filament\Admin\Widgets\RevenueChart;
use App\Filament\Admin\Widgets\StatsOverview;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Pages\Auth\Login;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\AuthenticateSession;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->id('admin')
            ->path('admin')
            ->login(Login::class)
            ->colors(['primary' => Color::Orange])
            ->brandName('GLV Admin')
            ->resources([
                CityResource::class,
                RestaurantResource::class,
                OrderResource::class,
                UserResource::class,
                CouponResource::class,
                ReviewResource::class,  // YENİ
                CourierPayoutResource::class,  // YENİ v3 — kurye kazanç/ödeme yönetimi
                CampaignResource::class,  // YENİ v5 — büyüme/sadakat kampanya yönetimi
                DisputeResource::class,  // YENİ v6 — itiraz/iade yönetimi
                SupportTicketResource::class,  // YENİ v6 — canlı destek yönetimi
            ])
            ->pages([Dashboard::class])
            ->widgets([
                StatsOverview::class,
                RevenueChart::class,
                FlaggedCustomersWidget::class,  // YENİ v6
                FlaggedCouriersWidget::class,  // YENİ v6
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([Authenticate::class])
            ->authGuard('web')
            ->databaseNotifications();
    }
}
