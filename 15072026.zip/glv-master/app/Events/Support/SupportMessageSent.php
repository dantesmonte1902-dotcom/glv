<?php

namespace App\Events\Support;

use App\Models\SupportMessage;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class SupportMessageSent implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public SupportMessage $message) {}

    public function broadcastOn(): array
    {
        return [
            new PrivateChannel('support-tickets.'.$this->message->ticket_id),
        ];
    }

    public function broadcastAs(): string
    {
        return 'support.message.sent';
    }

    public function broadcastWith(): array
    {
        return [
            'ticket_id' => $this->message->ticket_id,
            'message' => [
                'id' => $this->message->id,
                'sender_id' => $this->message->sender_id,
                'is_staff' => $this->message->is_staff,
                'message' => $this->message->message,
                'created_at' => $this->message->created_at?->toIso8601String(),
            ],
        ];
    }
}
