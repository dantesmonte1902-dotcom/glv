<?php

use App\Http\Controllers\Api\V1\Admin\BranchController;
use App\Http\Controllers\Api\V1\Admin\CityController;
use App\Http\Controllers\Api\V1\Admin\CouponController;
use App\Http\Controllers\Api\V1\Admin\CourierController as AdminCourierController;
use App\Http\Controllers\Api\V1\Admin\MenuManagementController;
use App\Http\Controllers\Api\V1\Admin\RestaurantController;
use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\CartController;
use App\Http\Controllers\Api\V1\CourierController;
use App\Http\Controllers\Api\V1\DeviceTokenController;
use App\Http\Controllers\Api\V1\MenuController;
use App\Http\Controllers\Api\V1\OrderController;
use App\Http\Controllers\Api\V1\PaymentController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function (): void {

    // ─── Auth (rate limit: 10/dk) ─────────────────────────────────────────────
    Route::prefix('auth')->middleware('throttle:auth')->group(function (): void {
        Route::post('register', [AuthController::class, 'register']);
        Route::post('login', [AuthController::class, 'login']);

        Route::middleware('auth:sanctum')->group(function (): void {
            Route::get('me', [AuthController::class, 'me']);
            Route::post('logout', [AuthController::class, 'logout']);
        });
    });

    // ─── Stripe Webhook — imza doğrulaması ile korunur ────────────────────────
    Route::post('webhooks/stripe', [PaymentController::class, 'stripeWebhook']);

    // ─── Public (genel rate limit: 30/dk) ─────────────────────────────────────
    Route::middleware('throttle:api')->group(function (): void {
        Route::get('branches/{branch}/menu', [MenuController::class, 'index']);
        Route::get('branches/{branch}/products/{product}', [MenuController::class, 'show']);
    });

    // ─── Korumalı endpointler ─────────────────────────────────────────────────
    Route::middleware(['auth:sanctum', 'tenant', 'throttle:api'])->group(function (): void {

        // FCM device token kayıt/silme
        Route::post('device-tokens', [DeviceTokenController::class, 'store']);
        Route::delete('device-tokens', [DeviceTokenController::class, 'destroy']);

        // ─── Sepet ───────────────────────────────────────────────────────────
        Route::middleware('role:customer')->prefix('cart')->group(function (): void {
            Route::get('/', [CartController::class, 'index']);
            Route::post('items', [CartController::class, 'addItem']);
            Route::patch('items/{itemKey}', [CartController::class, 'updateItem']);
            Route::delete('items/{itemKey}', [CartController::class, 'removeItem']);
            Route::delete('/', [CartController::class, 'clear']);
            Route::post('checkout-summary', [CartController::class, 'checkoutSummary']);
        });

        // ─── Kupon doğrulama ─────────────────────────────────────────────────
        Route::get('coupons/validate', [CouponController::class, 'validateCoupon'])->middleware('role:customer');

        // ─── Siparişler (sipariş oluşturma ayrı sıkı limit: 5/dk) ────────────
        Route::post('orders', [OrderController::class, 'store'])
            ->middleware(['role:customer', 'throttle:order']);
        Route::get('orders/{order}', [OrderController::class, 'show']);
        Route::post('orders/{order}/approve', [OrderController::class, 'approve'])->middleware('role:restaurant,admin');
        Route::post('orders/{order}/reject', [OrderController::class, 'reject'])->middleware('role:restaurant,admin');
        Route::post('orders/{order}/assign-courier', [OrderController::class, 'assignCourier'])->middleware('role:admin,restaurant');
        Route::post('orders/{order}/accept-courier', [OrderController::class, 'acceptCourier'])->middleware('role:courier');
        Route::post('orders/{order}/reject-courier', [OrderController::class, 'rejectCourier'])->middleware('role:courier');
        Route::post('orders/{order}/deliver', [OrderController::class, 'deliver'])->middleware('role:courier,admin');

        // ─── Ödeme ───────────────────────────────────────────────────────────
        Route::prefix('orders/{order}/payment')->group(function (): void {
            Route::post('intent', [PaymentController::class, 'createIntent'])->middleware('role:customer');
            Route::post('cash', [PaymentController::class, 'createCash'])->middleware('role:customer');
            Route::post('cash/complete', [PaymentController::class, 'completeCash'])->middleware('role:courier,admin');
            Route::get('/', [PaymentController::class, 'show']);
        });

        // ─── Kurye ───────────────────────────────────────────────────────────
        Route::patch('courier/location', [CourierController::class, 'updateLocation'])->middleware('role:courier');
        Route::patch('courier/availability', [CourierController::class, 'updateAvailability'])->middleware('role:courier');

        // ─── Admin ───────────────────────────────────────────────────────────
        Route::prefix('admin')->group(function (): void {

            // Şehir
            Route::get('cities', [CityController::class, 'index']);
            Route::post('cities', [CityController::class, 'store']);
            Route::patch('cities/{city}', [CityController::class, 'update']);

            // Restoran
            Route::get('restaurants', [RestaurantController::class, 'index'])->middleware('role:admin,restaurant');
            Route::post('restaurants', [RestaurantController::class, 'store'])->middleware('role:admin');
            Route::patch('restaurants/{restaurant}', [RestaurantController::class, 'update'])->middleware('role:admin,restaurant');

            // Şube
            Route::get('restaurants/{restaurant}/branches', [BranchController::class, 'index'])->middleware('role:admin,restaurant');
            Route::post('restaurants/{restaurant}/branches', [BranchController::class, 'store'])->middleware('role:admin,restaurant');
            Route::patch('branches/{branch}', [BranchController::class, 'update'])->middleware('role:admin,restaurant');

            // Kurye aktivasyon
            Route::patch('couriers/{courier}/activation', [AdminCourierController::class, 'updateActivation'])->middleware('role:admin');

            // Menü
            Route::get('restaurants/{restaurant}/categories', [MenuManagementController::class, 'categories'])->middleware('role:admin,restaurant');
            Route::post('restaurants/{restaurant}/categories', [MenuManagementController::class, 'storeCategory'])->middleware('role:admin,restaurant');
            Route::patch('categories/{category}', [MenuManagementController::class, 'updateCategory'])->middleware('role:admin,restaurant');
            Route::get('categories/{category}/products', [MenuManagementController::class, 'products'])->middleware('role:admin,restaurant');
            Route::post('categories/{category}/products', [MenuManagementController::class, 'storeProduct'])->middleware('role:admin,restaurant');
            Route::patch('products/{product}', [MenuManagementController::class, 'updateProduct'])->middleware('role:admin,restaurant');
            Route::delete('products/{product}', [MenuManagementController::class, 'deactivateProduct'])->middleware('role:admin,restaurant');
            Route::post('products/{product}/option-groups', [MenuManagementController::class, 'storeOptionGroup'])->middleware('role:admin,restaurant');
            Route::delete('option-groups/{group}', [MenuManagementController::class, 'destroyOptionGroup'])->middleware('role:admin,restaurant');

            // Kuponlar
            Route::middleware('role:admin')->prefix('coupons')->group(function (): void {
                Route::get('/', [CouponController::class, 'index']);
                Route::post('/', [CouponController::class, 'store']);
                Route::get('{coupon}', [CouponController::class, 'show']);
                Route::patch('{coupon}', [CouponController::class, 'update']);
                Route::delete('{coupon}', [CouponController::class, 'destroy']);
            });

            // İade
            Route::post('orders/{order}/payment/refund', [PaymentController::class, 'refund'])->middleware('role:admin');
        });
    });
});
