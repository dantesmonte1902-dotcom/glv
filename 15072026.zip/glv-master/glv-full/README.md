# GLV — Teslimat Platformu

Glovo / Yemeksepeti benzeri çok şehirli teslimat platformu.

## Stack
- **Backend:** Laravel 12 + PostgreSQL + Redis + Laravel Reverb (WebSocket)
- **Panel:** Filament v3 (Admin + Restoran)
- **Ödeme:** Stripe + Kapıda ödeme
- **Mobil:** Flutter (Dart)
- **Altyapı:** Docker, Nginx, Supervisor, GitHub Actions CI/CD

---

## Hızlı Başlangıç (Geliştirme)

```bash
# 1. Repoyu klonla
git clone <repo> glv && cd glv

# 2. Kurulum scriptini çalıştır
chmod +x scripts/local-install.sh
./scripts/local-install.sh

# 3. Paketleri yükle
docker compose exec app composer require \
  filament/filament:"^3.x" \
  stripe/stripe-php:"^v16.0" \
  sentry/sentry-laravel:"^4.0" -W

# 4. Filament panelleri kur
docker compose exec app php artisan filament:install --panels
# Panel id: "admin" yaz

# 5. Migration ve seed
docker compose exec app php artisan migrate --seed

# 6. Adreslere gir
# API:             http://localhost:8080/api/v1
# Admin Panel:     http://localhost:8080/admin
# Restoran Panel:  http://localhost:8080/restaurant
```

## Giriş Bilgileri (Seed)
| Rol | E-posta | Şifre |
|-----|---------|-------|
| Admin | admin@glv.local | password |
| Restoran | restaurant@glv.local | password |
| Müşteri | customer@glv.local | password |
| Kurye | courier@glv.local | password |

## Flutter Mobil Uygulama

```bash
cd mobile
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8080/api/v1
```

## Migration Sırası
| # | İçerik |
|---|--------|
| 000001 | menu_categories |
| 000002 | products |
| 000003 | product_option_groups, product_options |
| 000004 | restaurant_branches ve order_items genişletme |
| 000005 | coupons, coupon_usages |
| 000006 | orders kupon ve ücret alanları |
| 000007 | payments |
| 000008 | orders payment alanları |
| 000009 | audit_logs, device_tokens |
