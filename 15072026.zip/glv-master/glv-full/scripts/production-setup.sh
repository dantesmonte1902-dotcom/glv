#!/bin/bash
# scripts/production-setup.sh
# Ubuntu 24.04 üzerinde GLV ilk kurulum
# Çalıştır: chmod +x scripts/production-setup.sh && sudo ./scripts/production-setup.sh

set -euo pipefail

echo "=== GLV Production Kurulum ==="

# ─── PHP 8.3 + gerekli eklentiler ────────────────────────────────────────────
echo "PHP 8.3 yükleniyor..."
apt-get update -q
apt-get install -y software-properties-common
add-apt-repository ppa:ondrej/php -y
apt-get update -q
apt-get install -y \
    php8.3-fpm php8.3-cli php8.3-pgsql php8.3-redis \
    php8.3-bcmath php8.3-mbstring php8.3-xml php8.3-curl \
    php8.3-zip php8.3-pcntl php8.3-intl

# ─── Nginx ───────────────────────────────────────────────────────────────────
echo "Nginx yükleniyor..."
apt-get install -y nginx

# ─── PostgreSQL 16 ───────────────────────────────────────────────────────────
echo "PostgreSQL yükleniyor..."
apt-get install -y postgresql postgresql-client
systemctl enable postgresql && systemctl start postgresql

sudo -u postgres psql -c "CREATE USER glv WITH PASSWORD 'CHANGE_ME_STRONG_PASSWORD';"
sudo -u postgres psql -c "CREATE DATABASE glv_production OWNER glv;"

# ─── Redis ───────────────────────────────────────────────────────────────────
echo "Redis yükleniyor..."
apt-get install -y redis-server
systemctl enable redis-server && systemctl start redis-server

# ─── Composer ────────────────────────────────────────────────────────────────
echo "Composer yükleniyor..."
curl -sS https://getcomposer.org/installer | php
mv composer.phar /usr/local/bin/composer

# ─── Supervisor ──────────────────────────────────────────────────────────────
echo "Supervisor yükleniyor..."
apt-get install -y supervisor
systemctl enable supervisor && systemctl start supervisor

# ─── Certbot (Let's Encrypt) ─────────────────────────────────────────────────
echo "Certbot yükleniyor..."
apt-get install -y certbot python3-certbot-nginx

# ─── Uygulama dizini ─────────────────────────────────────────────────────────
echo "Uygulama dizini oluşturuluyor..."
mkdir -p /var/www/glv
mkdir -p /var/log/glv
chown -R www-data:www-data /var/www/glv /var/log/glv

# ─── Nginx config ────────────────────────────────────────────────────────────
cp docker/glv-nginx.conf /etc/nginx/sites-available/glv
ln -sf /etc/nginx/sites-available/glv /etc/nginx/sites-enabled/glv
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

# ─── Supervisor config ───────────────────────────────────────────────────────
cp docker/glv-supervisor.conf /etc/supervisor/conf.d/glv.conf
supervisorctl reread && supervisorctl update

echo ""
echo "=== Kurulum tamamlandı ==="
echo ""
echo "Sonraki adımlar:"
echo "1. /var/www/glv dizinine kodu kopyala"
echo "2. .env dosyasını oluştur ve doldur"
echo "3. composer install --no-dev --optimize-autoloader"
echo "4. php artisan migrate --force"
echo "5. php artisan db:seed --force"
echo "6. certbot --nginx -d api.glv.ba"
echo "7. supervisorctl start all"
