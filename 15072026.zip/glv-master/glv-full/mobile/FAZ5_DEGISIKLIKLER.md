# GLV — Faz 5: Flutter Mobil Uygulama

## Kurulum
```bash
# Flutter SDK gerekirhttps://flutter.dev/docs/get-started/install
flutter pub get
flutter run
```

## Proje yapısı
```
lib/
├── main.dart
├── core/
│   ├── api/api_client.dart          # Dio + Auth interceptor
│   ├── constants/app_constants.dart # URL, key sabitleri
│   ├── router/app_router.dart       # GoRouter navigasyon
│   └── theme/app_theme.dart         # Material 3 tema
└── features/
    ├── auth/       # Login, Register, AuthNotifier
    ├── menu/       # Home, RestaurantMenu, ProductDetail
    ├── cart/       # CartScreen, CheckoutScreen
    ├── orders/     # OrdersScreen, OrderTracking
    ├── courier/    # CourierHome (online/offline)
    └── profile/    # ProfileScreen
```

## Ekranlar
| Ekran | Açıklama |
|-------|----------|
| LoginScreen | E-posta + şifre girişi |
| RegisterScreen | Kayıt + şehir seçimi |
| HomeScreen | Şube listesi |
| RestaurantMenuScreen | Kategori + ürün listesi |
| ProductDetailScreen | Opsiyon seçimi, sepete ekle |
| CartScreen | Sepet görüntüle, miktar güncelle |
| CheckoutScreen | Adres, ödeme yöntemi, kupon, sipariş ver |
| OrderTrackingScreen | Sipariş durum adımları |
| CourierHomeScreen | Online/offline toggle, istatistikler |
| ProfileScreen | Kullanıcı bilgileri, çıkış |

## Ortam değişkenleri
```bash
flutter run \
  --dart-define=API_BASE_URL=http://10.0.2.2:8080/api/v1 \
  --dart-define=STRIPE_KEY=pk_test_xxx \
  --dart-define=WS_HOST=10.0.2.2 \
  --dart-define=REVERB_APP_KEY=your-key
```

## Android emülatörde localhost
10.0.2.2 → bilgisayarınızın localhost'una denk gelir.
