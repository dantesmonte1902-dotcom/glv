import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/register_screen.dart';
import '../../features/menu/presentation/screens/home_screen.dart';
import '../../features/menu/presentation/screens/restaurant_menu_screen.dart';
import '../../features/menu/presentation/screens/product_detail_screen.dart';
import '../../features/cart/presentation/screens/cart_screen.dart';
import '../../features/cart/presentation/screens/checkout_screen.dart';
import '../../features/orders/presentation/screens/orders_screen.dart';
import '../../features/orders/presentation/screens/order_tracking_screen.dart';
import '../../features/courier/presentation/screens/courier_home_screen.dart';
import '../../features/profile/presentation/screens/profile_screen.dart';
import '../api/api_client.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authEvent = ref.watch(authEventProvider);

  return GoRouter(
    initialLocation: '/home',
    redirect: (context, state) {
      if (authEvent == AuthEvent.unauthorized) {
        ref.read(authEventProvider.notifier).state = AuthEvent.none;
        return '/login';
      }
      return null;
    },
    routes: [
      // Auth
      GoRoute(path: '/login', builder: (ctx, s) => const LoginScreen()),
      GoRoute(path: '/register', builder: (ctx, s) => const RegisterScreen()),

      // Ana Shell — alt navigasyon barı ile
      ShellRoute(
        builder: (ctx, state, child) => MainShell(child: child),
        routes: [
          GoRoute(path: '/home', builder: (ctx, s) => const HomeScreen()),
          GoRoute(
            path: '/restaurants/:branchId/menu',
            builder: (ctx, s) => RestaurantMenuScreen(
              branchId: int.parse(s.pathParameters['branchId']!),
            ),
          ),
          GoRoute(
            path: '/products/:branchId/:productId',
            builder: (ctx, s) => ProductDetailScreen(
              branchId: int.parse(s.pathParameters['branchId']!),
              productId: int.parse(s.pathParameters['productId']!),
            ),
          ),
          GoRoute(path: '/cart', builder: (ctx, s) => const CartScreen()),
          GoRoute(path: '/checkout', builder: (ctx, s) => const CheckoutScreen()),
          GoRoute(path: '/orders', builder: (ctx, s) => const OrdersScreen()),
          GoRoute(
            path: '/orders/:orderId/tracking',
            builder: (ctx, s) => OrderTrackingScreen(
              orderId: int.parse(s.pathParameters['orderId']!),
            ),
          ),
          GoRoute(path: '/courier', builder: (ctx, s) => const CourierHomeScreen()),
          GoRoute(path: '/profile', builder: (ctx, s) => const ProfileScreen()),
        ],
      ),
    ],
  );
});

/// Alt navigasyon barı — rol bazlı menü öğeleri
class MainShell extends ConsumerWidget {
  final Widget child;
  const MainShell({super.key, required this.child});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: child,
      bottomNavigationBar: NavigationBar(
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'Sepet'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Siparişler'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
        ],
        onDestinationSelected: (index) {
          switch (index) {
            case 0: context.go('/home');
            case 1: context.go('/cart');
            case 2: context.go('/orders');
            case 3: context.go('/profile');
          }
        },
      ),
    );
  }
}
