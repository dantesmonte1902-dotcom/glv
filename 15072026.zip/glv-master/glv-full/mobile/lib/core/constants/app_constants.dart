class AppConstants {
  AppConstants._();

  // API base URL — geliştirme ortamında localhost, production'da gerçek domain
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8080/api/v1', // Android emülatörde localhost
  );

  static const String stripePublishableKey = String.fromEnvironment(
    'STRIPE_KEY',
    defaultValue: 'pk_test_YOUR_KEY_HERE',
  );

  // Reverb WebSocket
  static const String wsHost = String.fromEnvironment(
    'WS_HOST',
    defaultValue: '10.0.2.2',
  );
  static const int wsPort = int.fromEnvironment('WS_PORT', defaultValue: 8080);
  static const String wsKey = String.fromEnvironment(
    'REVERB_APP_KEY',
    defaultValue: 'your-reverb-key',
  );

  // Storage anahtarları
  static const String tokenKey = 'auth_token';
  static const String userKey = 'auth_user';
  static const String cityIdKey = 'selected_city_id';
}
