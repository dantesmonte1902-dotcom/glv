// lib/features/menu/presentation/screens/product_detail_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/models/menu_models.dart';
import '../../data/repositories/menu_repository.dart';
import '../../../cart/data/repositories/cart_repository.dart';

class ProductDetailScreen extends ConsumerStatefulWidget {
  final int branchId;
  final int productId;
  const ProductDetailScreen({super.key, required this.branchId, required this.productId});

  @override
  ConsumerState<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends ConsumerState<ProductDetailScreen> {
  int _quantity = 1;
  final Map<int, Set<int>> _selectedOptions = {}; // groupId -> Set<optionId>

  double _calculateTotal(Product product) {
    double total = product.basePrice;
    for (final group in product.optionGroups) {
      final selected = _selectedOptions[group.id] ?? {};
      for (final opt in group.options) {
        if (selected.contains(opt.id)) total += opt.priceModifier;
      }
    }
    return total * _quantity;
  }

  List<int> get _flatSelectedOptions {
    return _selectedOptions.values.expand((s) => s).toList();
  }

  void _toggleOption(OptionGroup group, ProductOption option) {
    setState(() {
      _selectedOptions.putIfAbsent(group.id, () => {});
      if (!group.isMultiple) {
        _selectedOptions[group.id] = {option.id};
      } else {
        if (_selectedOptions[group.id]!.contains(option.id)) {
          _selectedOptions[group.id]!.remove(option.id);
        } else if (_selectedOptions[group.id]!.length < group.maxSelections) {
          _selectedOptions[group.id]!.add(option.id);
        }
      }
    });
  }

  Future<void> _addToCart(Product product) async {
    // Zorunlu grupları kontrol et
    for (final group in product.optionGroups) {
      if (group.isRequired && (_selectedOptions[group.id]?.isEmpty ?? true)) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('"${group.name}" için bir seçenek seçiniz.'), backgroundColor: Colors.red),
        );
        return;
      }
    }

    await ref.read(cartRepositoryProvider).addItem(
      branchId: widget.branchId,
      productId: product.id,
      quantity: _quantity,
      selectedOptions: _flatSelectedOptions,
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sepete eklendi!'), backgroundColor: Color(0xFF16A34A)),
      );
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final productAsync = ref.watch(productDetailProvider((branchId: widget.branchId, productId: widget.productId)));

    return productAsync.when(
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(body: Center(child: Text('Hata: $e'))),
      data: (product) => Scaffold(
        appBar: AppBar(title: Text(product.name)),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Ürün görseli
              Container(
                height: 200,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF7ED),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.fastfood, size: 80, color: Color(0xFFF97316)),
              ),
              const SizedBox(height: 20),
              Text(product.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              if (product.description != null) ...[
                const SizedBox(height: 8),
                Text(product.description!, style: const TextStyle(color: Colors.grey, fontSize: 15)),
              ],
              const SizedBox(height: 8),
              Row(children: [
                const Icon(Icons.access_time, size: 16, color: Colors.grey),
                const SizedBox(width: 4),
                Text('${product.preparationTimeMinutes} dk', style: const TextStyle(color: Colors.grey)),
              ]),
              const SizedBox(height: 24),

              // Opsiyon grupları
              for (final group in product.optionGroups) ...[
                Row(children: [
                  Text(group.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  if (group.isRequired) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFFEF9C3), borderRadius: BorderRadius.circular(8)),
                      child: const Text('Zorunlu', style: TextStyle(fontSize: 11, color: Color(0xFFCA8A04))),
                    ),
                  ],
                ]),
                const SizedBox(height: 10),
                for (final opt in group.options)
                  _OptionTile(
                    option: opt,
                    isSelected: (_selectedOptions[group.id] ?? {}).contains(opt.id),
                    isMultiple: group.isMultiple,
                    onTap: () => _toggleOption(group, opt),
                  ),
                const SizedBox(height: 16),
              ],

              // Miktar
              Row(
                children: [
                  const Text('Miktar', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  const Spacer(),
                  IconButton(
                    onPressed: _quantity > 1 ? () => setState(() => _quantity--) : null,
                    icon: const Icon(Icons.remove_circle_outline),
                    color: const Color(0xFFF97316),
                  ),
                  Text('$_quantity', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  IconButton(
                    onPressed: () => setState(() => _quantity++),
                    icon: const Icon(Icons.add_circle_outline),
                    color: const Color(0xFFF97316),
                  ),
                ],
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.all(16),
          child: ElevatedButton(
            onPressed: () => _addToCart(product),
            child: Text('Sepete Ekle — ${_calculateTotal(product).toStringAsFixed(2)} KM'),
          ),
        ),
      ),
    );
  }
}

class _OptionTile extends StatelessWidget {
  final ProductOption option;
  final bool isSelected;
  final bool isMultiple;
  final VoidCallback onTap;

  const _OptionTile({required this.option, required this.isSelected, required this.isMultiple, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFFFF7ED) : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: isSelected ? const Color(0xFFF97316) : const Color(0xFFE2E8F0), width: isSelected ? 2 : 1),
        ),
        child: Row(
          children: [
            Icon(
              isMultiple ? (isSelected ? Icons.check_box : Icons.check_box_outline_blank) : (isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked),
              color: isSelected ? const Color(0xFFF97316) : Colors.grey,
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(option.name, style: const TextStyle(fontSize: 15))),
            if (option.priceModifier != 0)
              Text(
                '${option.priceModifier > 0 ? '+' : ''}${option.priceModifier.toStringAsFixed(2)} KM',
                style: TextStyle(color: option.priceModifier > 0 ? const Color(0xFFF97316) : const Color(0xFF16A34A), fontWeight: FontWeight.w600),
              ),
          ],
        ),
      ),
    );
  }
}
