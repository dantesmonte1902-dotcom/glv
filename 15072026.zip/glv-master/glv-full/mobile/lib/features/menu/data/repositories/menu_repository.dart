// lib/features/menu/data/repositories/menu_repository.dart

import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/api/api_client.dart';
import '../models/menu_models.dart';

final menuRepositoryProvider = Provider<MenuRepository>((ref) {
  return MenuRepository(ref.read(dioProvider));
});

class MenuRepository {
  final Dio _dio;
  MenuRepository(this._dio);

  Future<Map<String, dynamic>> getBranchMenu(int branchId) async {
    final res = await _dio.get('/branches/$branchId/menu');
    return res.data;
  }

  Future<Product> getProduct(int branchId, int productId) async {
    final res = await _dio.get('/branches/$branchId/products/$productId');
    return Product.fromJson(res.data);
  }
}

// Provider'lar
final branchMenuProvider = FutureProvider.family<Map<String, dynamic>, int>((ref, branchId) async {
  return ref.read(menuRepositoryProvider).getBranchMenu(branchId);
});

final productDetailProvider = FutureProvider.family<Product, ({int branchId, int productId})>((ref, args) async {
  return ref.read(menuRepositoryProvider).getProduct(args.branchId, args.productId);
});
