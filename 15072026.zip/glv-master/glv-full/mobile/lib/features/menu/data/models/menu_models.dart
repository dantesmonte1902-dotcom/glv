// lib/features/menu/data/models/menu_models.dart

class Branch {
  final int id;
  final String name;
  final bool isOpen;
  final String? opensAt;
  final String? closesAt;
  final double minimumOrderAmount;
  final int estimatedDeliveryMinutes;

  const Branch({
    required this.id,
    required this.name,
    required this.isOpen,
    this.opensAt,
    this.closesAt,
    required this.minimumOrderAmount,
    required this.estimatedDeliveryMinutes,
  });

  factory Branch.fromJson(Map<String, dynamic> json) => Branch(
    id: json['id'],
    name: json['name'],
    isOpen: json['is_open'] ?? false,
    opensAt: json['opens_at'],
    closesAt: json['closes_at'],
    minimumOrderAmount: (json['minimum_order_amount'] ?? 0).toDouble(),
    estimatedDeliveryMinutes: json['estimated_delivery_minutes'] ?? 30,
  );
}

class MenuCategory {
  final int id;
  final String name;
  final List<Product> products;

  const MenuCategory({required this.id, required this.name, required this.products});

  factory MenuCategory.fromJson(Map<String, dynamic> json) => MenuCategory(
    id: json['id'],
    name: json['name'],
    products: (json['active_products'] as List? ?? [])
        .map((p) => Product.fromJson(p))
        .toList(),
  );
}

class Product {
  final int id;
  final String name;
  final String? description;
  final String? imageUrl;
  final double basePrice;
  final int preparationTimeMinutes;
  final bool isAvailable;
  final List<OptionGroup> optionGroups;

  const Product({
    required this.id,
    required this.name,
    this.description,
    this.imageUrl,
    required this.basePrice,
    required this.preparationTimeMinutes,
    required this.isAvailable,
    required this.optionGroups,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    id: json['id'],
    name: json['name'],
    description: json['description'],
    imageUrl: json['image_url'],
    basePrice: (json['base_price'] ?? 0).toDouble(),
    preparationTimeMinutes: json['preparation_time_minutes'] ?? 15,
    isAvailable: json['is_available'] ?? true,
    optionGroups: (json['option_groups'] as List? ?? [])
        .map((g) => OptionGroup.fromJson(g))
        .toList(),
  );
}

class OptionGroup {
  final int id;
  final String name;
  final bool isRequired;
  final bool isMultiple;
  final int minSelections;
  final int maxSelections;
  final List<ProductOption> options;

  const OptionGroup({
    required this.id,
    required this.name,
    required this.isRequired,
    required this.isMultiple,
    required this.minSelections,
    required this.maxSelections,
    required this.options,
  });

  factory OptionGroup.fromJson(Map<String, dynamic> json) => OptionGroup(
    id: json['id'],
    name: json['name'],
    isRequired: json['is_required'] ?? false,
    isMultiple: json['is_multiple'] ?? false,
    minSelections: json['min_selections'] ?? 0,
    maxSelections: json['max_selections'] ?? 1,
    options: (json['options'] as List? ?? [])
        .map((o) => ProductOption.fromJson(o))
        .toList(),
  );
}

class ProductOption {
  final int id;
  final String name;
  final double priceModifier;
  final bool isDefault;

  const ProductOption({
    required this.id,
    required this.name,
    required this.priceModifier,
    required this.isDefault,
  });

  factory ProductOption.fromJson(Map<String, dynamic> json) => ProductOption(
    id: json['id'],
    name: json['name'],
    priceModifier: (json['price_modifier'] ?? 0).toDouble(),
    isDefault: json['is_default'] ?? false,
  );
}
