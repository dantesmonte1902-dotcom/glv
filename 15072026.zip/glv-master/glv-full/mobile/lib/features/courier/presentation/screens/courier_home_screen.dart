// lib/features/courier/presentation/screens/courier_home_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';
import '../../../../core/api/api_client.dart';

final courierOnlineProvider = StateProvider<bool>((ref) => false);

class CourierHomeScreen extends ConsumerWidget {
  const CourierHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isOnline = ref.watch(courierOnlineProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(title: const Text('Kurye Paneli')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Online/Offline toggle kartı
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(
                    isOnline ? '🟢 Çevrimiçisin' : '🔴 Çevrimdışısın',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isOnline ? 'Sipariş teklifleri alıyorsun' : 'Sipariş almak için çevrimiçi ol',
                    style: const TextStyle(color: Colors.grey, fontSize: 13),
                  ),
                ]),
              ),
              Switch(
                value: isOnline,
                activeColor: const Color(0xFF16A34A),
                onChanged: (val) async {
                  ref.read(courierOnlineProvider.notifier).state = val;
                  await ref.read(dioProvider).patch('/courier/availability', data: {'is_online': val});
                },
              ),
            ]),
          ),

          const SizedBox(height: 24),

          // İstatistikler
          Row(children: [
            Expanded(child: _StatCard(label: 'Bugün', value: '0 Teslimat', icon: Icons.delivery_dining)),
            const SizedBox(width: 12),
            Expanded(child: _StatCard(label: 'Kazanç', value: '0.00 KM', icon: Icons.account_balance_wallet_outlined)),
          ]),

          const SizedBox(height: 24),

          const Text('Aktif Siparişler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),

          if (!isOnline)
            Center(
              child: Column(children: [
                const SizedBox(height: 32),
                Icon(Icons.directions_bike, size: 64, color: Colors.grey.shade300),
                const SizedBox(height: 16),
                const Text('Sipariş almak için çevrimiçi olun', style: TextStyle(color: Colors.grey)),
              ]),
            )
          else
            const Center(child: Text('Bekleniyor...', style: TextStyle(color: Colors.grey))),
        ]),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _StatCard({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: const Color(0xFFF97316)),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      ]),
    );
  }
}
