// lib/features/auth/data/models/auth_models.dart

class LoginRequest {
  final String email;
  final String password;
  LoginRequest({required this.email, required this.password});
  Map<String, dynamic> toJson() => {'email': email, 'password': password};
}

class RegisterRequest {
  final String name;
  final String email;
  final String phone;
  final String password;
  final int cityId;
  RegisterRequest({
    required this.name,
    required this.email,
    required this.phone,
    required this.password,
    required this.cityId,
  });
  Map<String, dynamic> toJson() => {
    'name': name,
    'email': email,
    'phone': phone,
    'password': password,
    'password_confirmation': password,
    'city_id': cityId,
    'role': 'customer',
  };
}

class AuthUser {
  final int id;
  final String name;
  final String email;
  final String phone;
  final String role;
  final int cityId;
  final int? restaurantId;
  final bool isActive;

  const AuthUser({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.role,
    required this.cityId,
    this.restaurantId,
    required this.isActive,
  });

  factory AuthUser.fromJson(Map<String, dynamic> json) => AuthUser(
    id: json['id'],
    name: json['name'],
    email: json['email'],
    phone: json['phone'] ?? '',
    role: json['role'] is Map ? json['role']['value'] : json['role'],
    cityId: json['city_id'],
    restaurantId: json['restaurant_id'],
    isActive: json['is_active'] ?? true,
  );

  bool get isCourier => role == 'courier';
  bool get isRestaurant => role == 'restaurant';
  bool get isAdmin => role == 'admin';
  bool get isCustomer => role == 'customer';
}
