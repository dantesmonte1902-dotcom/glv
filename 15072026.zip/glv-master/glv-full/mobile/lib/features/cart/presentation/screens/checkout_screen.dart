// lib/features/cart/presentation/screens/checkout_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/repositories/cart_repository.dart';
import '../../../orders/data/repositories/order_repository.dart';

class CheckoutScreen extends ConsumerStatefulWidget {
  const CheckoutScreen({super.key});
  @override
  ConsumerState<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends ConsumerState<CheckoutScreen> {
  final _addressCtrl = TextEditingController();
  final _couponCtrl = TextEditingController();
  String _paymentMethod = 'cash_on_delivery';
  Map<String, dynamic>? _summary;
  bool _loadingSummary = false;
  bool _placingOrder = false;

  Future<void> _loadSummary() async {
    setState(() => _loadingSummary = true);
    try {
      final s = await ref.read(cartRepositoryProvider).checkoutSummary(
        couponCode: _couponCtrl.text.isEmpty ? null : _couponCtrl.text,
      );
      setState(() => _summary = s);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'), backgroundColor: Colors.red));
    } finally {
      setState(() => _loadingSummary = false);
    }
  }

  Future<void> _placeOrder() async {
    if (_addressCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Lütfen teslimat adresinizi girin.')));
      return;
    }
    if (_summary == null) { await _loadSummary(); return; }

    setState(() => _placingOrder = true);
    try {
      final cart = await ref.read(cartRepositoryProvider).getCart();
      final order = await ref.read(orderRepositoryProvider).placeOrder(
        cityId: 1,
        branchId: cart['branch_id'],
        items: cart['items'],
        deliveryAddress: _addressCtrl.text.trim(),
        paymentMethod: _paymentMethod,
        couponCode: _couponCtrl.text.isEmpty ? null : _couponCtrl.text,
      );
      if (mounted) context.go('/orders/${order['id']}/tracking');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'), backgroundColor: Colors.red));
    } finally {
      setState(() => _placingOrder = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sipariş Özeti')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Teslimat Adresi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          TextField(
            controller: _addressCtrl,
            maxLines: 2,
            decoration: const InputDecoration(hintText: 'Adres, daire no, kat...', prefixIcon: Icon(Icons.location_on_outlined)),
          ),
          const SizedBox(height: 24),

          const Text('Ödeme Yöntemi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          _PaymentOption(
            value: 'cash_on_delivery',
            groupValue: _paymentMethod,
            label: 'Kapıda Ödeme',
            icon: Icons.payments_outlined,
            onChanged: (v) => setState(() => _paymentMethod = v!),
          ),
          _PaymentOption(
            value: 'card',
            groupValue: _paymentMethod,
            label: 'Kredi / Banka Kartı',
            icon: Icons.credit_card_outlined,
            onChanged: (v) => setState(() => _paymentMethod = v!),
          ),
          const SizedBox(height: 24),

          const Text('Kupon', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _couponCtrl,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(hintText: 'Kupon kodu girin'),
              ),
            ),
            const SizedBox(width: 12),
            ElevatedButton(onPressed: _loadSummary, child: const Text('Uygula')),
          ]),

          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 12),

          if (_loadingSummary)
            const Center(child: CircularProgressIndicator())
          else if (_summary != null) ...[
            _SummaryRow('Ara Toplam', '${(_summary!['subtotal'] as num).toStringAsFixed(2)} KM'),
            _SummaryRow('Teslimat Ücreti', '${(_summary!['delivery_fee'] as num).toStringAsFixed(2)} KM'),
            _SummaryRow('Servis Ücreti', '${(_summary!['service_fee'] as num).toStringAsFixed(2)} KM'),
            if ((_summary!['discount'] as num) > 0)
              _SummaryRow('İndirim', '-${(_summary!['discount'] as num).toStringAsFixed(2)} KM', isDiscount: true),
            const Divider(),
            _SummaryRow('Toplam', '${(_summary!['total'] as num).toStringAsFixed(2)} KM', isBold: true),
          ] else
            TextButton(onPressed: _loadSummary, child: const Text('Fiyat özetini yükle')),

          const SizedBox(height: 32),
        ]),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: ElevatedButton(
          onPressed: _placingOrder ? null : _placeOrder,
          child: _placingOrder
              ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : Text(_summary != null ? 'Sipariş Ver — ${(_summary!['total'] as num).toStringAsFixed(2)} KM' : 'Sipariş Ver'),
        ),
      ),
    );
  }
}

class _PaymentOption extends StatelessWidget {
  final String value;
  final String groupValue;
  final String label;
  final IconData icon;
  final ValueChanged<String?> onChanged;
  const _PaymentOption({required this.value, required this.groupValue, required this.label, required this.icon, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final selected = value == groupValue;
    return GestureDetector(
      onTap: () => onChanged(value),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF7ED) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? const Color(0xFFF97316) : const Color(0xFFE2E8F0), width: selected ? 2 : 1),
        ),
        child: Row(children: [
          Radio<String>(value: value, groupValue: groupValue, onChanged: onChanged, activeColor: const Color(0xFFF97316)),
          Icon(icon, color: selected ? const Color(0xFFF97316) : Colors.grey),
          const SizedBox(width: 12),
          Text(label, style: TextStyle(fontWeight: selected ? FontWeight.w600 : FontWeight.normal)),
        ]),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;
  final bool isBold;
  final bool isDiscount;
  const _SummaryRow(this.label, this.value, {this.isBold = false, this.isDiscount = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: TextStyle(fontSize: isBold ? 16 : 14, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
        Text(value, style: TextStyle(fontSize: isBold ? 16 : 14, fontWeight: isBold ? FontWeight.bold : FontWeight.normal, color: isDiscount ? const Color(0xFF16A34A) : null)),
      ]),
    );
  }
}
