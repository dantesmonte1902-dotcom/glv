// lib/features/cart/presentation/screens/cart_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../data/repositories/cart_repository.dart';

class CartScreen extends ConsumerWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cartAsync = ref.watch(cartProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Sepetim'), actions: [
        TextButton(
          onPressed: () async {
            await ref.read(cartRepositoryProvider).clearCart();
            ref.invalidate(cartProvider);
          },
          child: const Text('Temizle', style: TextStyle(color: Colors.red)),
        ),
      ]),
      body: cartAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Hata: $e')),
        data: (cart) {
          final items = cart['items'] as List? ?? [];
          if (items.isEmpty) {
            return Center(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.shopping_cart_outlined, size: 80, color: Colors.grey),
                const SizedBox(height: 16),
                const Text('Sepetiniz boş', style: TextStyle(fontSize: 18, color: Colors.grey)),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => context.go('/home'),
                  child: const Text('Menüye Git'),
                ),
              ]),
            );
          }

          return Column(children: [
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: items.length,
                itemBuilder: (ctx, i) {
                  final item = items[i];
                  return _CartItemTile(item: item, onChanged: () => ref.invalidate(cartProvider));
                },
              ),
            ),
            _CartSummary(cart: cart),
          ]);
        },
      ),
    );
  }
}

class _CartItemTile extends ConsumerWidget {
  final Map<String, dynamic> item;
  final VoidCallback onChanged;
  const _CartItemTile({required this.item, required this.onChanged});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(item['item_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 4),
            Text('${(item['unit_price'] as num).toStringAsFixed(2)} KM', style: const TextStyle(color: Colors.grey, fontSize: 13)),
          ]),
        ),
        Row(children: [
          GestureDetector(
            onTap: () async {
              final qty = (item['quantity'] as int) - 1;
              if (qty <= 0) {
                await ref.read(cartRepositoryProvider).removeItem(item['_key']);
              } else {
                await ref.read(cartRepositoryProvider).updateItem(item['_key'], qty);
              }
              onChanged();
            },
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(border: Border.all(color: const Color(0xFFE2E8F0)), borderRadius: BorderRadius.circular(8)),
              child: const Icon(Icons.remove, size: 16),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text('${item['quantity']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ),
          GestureDetector(
            onTap: () async {
              await ref.read(cartRepositoryProvider).updateItem(item['_key'], (item['quantity'] as int) + 1);
              onChanged();
            },
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(color: const Color(0xFFF97316), borderRadius: BorderRadius.circular(8)),
              child: const Icon(Icons.add, size: 16, color: Colors.white),
            ),
          ),
        ]),
      ]),
    );
  }
}

class _CartSummary extends StatelessWidget {
  final Map<String, dynamic> cart;
  const _CartSummary({required this.cart});

  @override
  Widget build(BuildContext context) {
    final items = cart['items'] as List? ?? [];
    final subtotal = items.fold<double>(0, (sum, i) => sum + (i['line_total'] as num).toDouble());

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFE2E8F0))),
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Ara Toplam'),
          Text('${subtotal.toStringAsFixed(2)} KM', style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 12),
        ElevatedButton(
          onPressed: () => context.go('/checkout'),
          child: const Text('Siparişi Tamamla'),
        ),
      ]),
    );
  }
}
