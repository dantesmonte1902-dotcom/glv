// lib/features/orders/presentation/screens/orders_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

class OrdersScreen extends ConsumerWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Siparişlerim')),
      body: const Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.receipt_long, size: 64, color: Colors.grey),
          SizedBox(height: 16),
          Text('Sipariş geçmişi burada görünecek', style: TextStyle(color: Colors.grey)),
        ]),
      ),
    );
  }
}

// lib/features/orders/presentation/screens/order_tracking_screen.dart
class OrderTrackingScreen extends ConsumerStatefulWidget {
  final int orderId;
  const OrderTrackingScreen({super.key, required this.orderId});

  @override
  ConsumerState<OrderTrackingScreen> createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends ConsumerState<OrderTrackingScreen> {
  final _statusSteps = [
    {'status': 'pending_restaurant_approval', 'label': 'Sipariş Alındı', 'icon': Icons.receipt_outlined},
    {'status': 'searching_courier', 'label': 'Hazırlanıyor', 'icon': Icons.restaurant_outlined},
    {'status': 'courier_assigned', 'label': 'Kurye Atandı', 'icon': Icons.delivery_dining_outlined},
    {'status': 'out_for_delivery', 'label': 'Yolda', 'icon': Icons.directions_bike_outlined},
    {'status': 'delivered', 'label': 'Teslim Edildi', 'icon': Icons.check_circle_outline},
  ];

  int _currentStep(String status) {
    final idx = _statusSteps.indexWhere((s) => s['status'] == status);
    return idx == -1 ? 0 : idx;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sipariş #${widget.orderId}')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Sipariş Takibi', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 32),

          // Demo: pending_restaurant_approval durumu
          ..._statusSteps.asMap().entries.map((entry) {
            final i = entry.key;
            final step = entry.value;
            final current = _currentStep('pending_restaurant_approval');
            final isDone = i <= current;
            final isActive = i == current;

            return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Column(children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isDone ? const Color(0xFFF97316) : const Color(0xFFE2E8F0),
                  ),
                  child: Icon(step['icon'] as IconData, color: isDone ? Colors.white : Colors.grey, size: 20),
                ),
                if (i < _statusSteps.length - 1)
                  Container(width: 2, height: 32, color: isDone ? const Color(0xFFF97316) : const Color(0xFFE2E8F0)),
              ]),
              const SizedBox(width: 16),
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  step['label'] as String,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                    color: isDone ? const Color(0xFF1E293B) : const Color(0xFF94A3B8),
                  ),
                ),
              ),
            ]);
          }),

          const Spacer(),
          ElevatedButton.icon(
            onPressed: () => context.go('/home'),
            icon: const Icon(Icons.home_outlined),
            label: const Text('Ana Sayfaya Dön'),
          ),
        ]),
      ),
    );
  }
}
