// lib/features/profile/presentation/screens/profile_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../auth/data/repositories/auth_repository.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final user = auth.user;

    if (user == null) {
      return Scaffold(
        body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('Hesabınıza giriş yapın'),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: () => context.go('/login'), child: const Text('Giriş Yap')),
        ])),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Profilim')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        // Avatar
        Center(
          child: Column(children: [
            CircleAvatar(
              radius: 48,
              backgroundColor: const Color(0xFFFFF7ED),
              child: Text(user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Color(0xFFF97316))),
            ),
            const SizedBox(height: 12),
            Text(user.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text(user.email, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(color: const Color(0xFFFFF7ED), borderRadius: BorderRadius.circular(20)),
              child: Text(user.role, style: const TextStyle(color: Color(0xFFF97316), fontWeight: FontWeight.w600)),
            ),
          ]),
        ),
        const SizedBox(height: 32),

        // Menü öğeleri
        _MenuItem(icon: Icons.receipt_long_outlined, label: 'Siparişlerim', onTap: () => context.go('/orders')),
        _MenuItem(icon: Icons.location_on_outlined, label: 'Adreslerim', onTap: () {}),
        _MenuItem(icon: Icons.notifications_outlined, label: 'Bildirimler', onTap: () {}),
        _MenuItem(icon: Icons.help_outline, label: 'Yardım & Destek', onTap: () {}),
        const Divider(),
        _MenuItem(
          icon: Icons.logout,
          label: 'Çıkış Yap',
          color: Colors.red,
          onTap: () async {
            await ref.read(authProvider.notifier).logout();
            if (context.mounted) context.go('/login');
          },
        ),
      ]),
    );
  }
}

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;
  const _MenuItem({required this.icon, required this.label, required this.onTap, this.color});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: color ?? const Color(0xFF1E293B)),
      title: Text(label, style: TextStyle(color: color ?? const Color(0xFF1E293B))),
      trailing: const Icon(Icons.chevron_right, color: Colors.grey),
      onTap: onTap,
      contentPadding: EdgeInsets.zero,
    );
  }
}
