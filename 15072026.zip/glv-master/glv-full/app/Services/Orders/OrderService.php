<?php

namespace App\Services\Orders;

use App\Enums\OrderStatus;
use App\Enums\PaymentMethod;
use App\Enums\UserRole;
use App\Events\Orders\OrderApproved;
use App\Events\Orders\OrderCreated;
use App\Events\Orders\OrderRejected;
use App\Events\Orders\OrderStatusUpdated;
use App\Jobs\Notification\SendOrderNotificationJob;
use App\Jobs\Orders\AssignCourierJob;
use App\Models\AuditLog;
use App\Models\Coupon;
use App\Models\CouponUsage;
use App\Models\CourierAssignment;
use App\Models\Order;
use App\Models\RestaurantBranch;
use App\Models\User;
use App\Services\Cart\CartService;
use App\Services\Menu\MenuService;
use App\Services\Payment\PaymentService;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class OrderService
{
    public function __construct(
        private readonly MenuService $menuService,
        private readonly CartService $cartService,
        private readonly PaymentService $paymentService,
    ) {}

    public function create(User $customer, array $payload): Order
    {
        $branch = RestaurantBranch::query()->findOrFail($payload['branch_id']);

        if (! $customer->belongsToCity((int) $payload['city_id'])) {
            throw ValidationException::withMessages(['city_id' => 'Seçilen şehir kullanıcı kapsamınızın dışında.']);
        }
        if ((int) $branch->city_id !== (int) $payload['city_id']) {
            throw ValidationException::withMessages(['branch_id' => 'Seçilen şube bu şehre ait değil.']);
        }
        if (! $branch->is_open) {
            throw ValidationException::withMessages(['branch_id' => 'Bu şube şu an kapalı.']);
        }

        $paymentMethod = PaymentMethod::from($payload['payment_method'] ?? 'cash_on_delivery');
        $priced = $this->menuService->validateAndPriceItems($payload['items'], $branch->restaurant_id);
        $subtotal = $priced['subtotal'];

        if ($subtotal < $branch->minimum_order_amount) {
            throw ValidationException::withMessages(['items' => "Minimum sipariş tutarı {$branch->minimum_order_amount} KM."]);
        }

        $deliveryFee = $this->calculateDeliveryFee($payload['domain_type'], $branch->service_radius_km);
        $serviceFee = $this->calculateServiceFee($subtotal);
        $coupon = null;
        $discountAmount = 0.0;

        if (! empty($payload['coupon_code'])) {
            $coupon = Coupon::query()->where('code', strtoupper(trim($payload['coupon_code'])))->first();
            if (! $coupon || ! $coupon->isCurrentlyValid()) {
                throw ValidationException::withMessages(['coupon_code' => 'Geçersiz veya süresi dolmuş kupon.']);
            }
            if ($coupon->restaurant_id !== null && $coupon->restaurant_id !== $branch->restaurant_id) {
                throw ValidationException::withMessages(['coupon_code' => 'Bu kupon bu restoran için geçerli değil.']);
            }
            if ($subtotal < $coupon->minimum_order_amount) {
                throw ValidationException::withMessages(['coupon_code' => "Minimum {$coupon->minimum_order_amount} KM sipariş gerekiyor."]);
            }
            if ($coupon->usageCountForUser($customer->id) >= $coupon->per_user_limit) {
                throw ValidationException::withMessages(['coupon_code' => 'Kupon kullanım limitinize ulaştınız.']);
            }
            $discountAmount = $coupon->calculateDiscount($subtotal);
        }

        $totalAmount = round($subtotal + $deliveryFee + $serviceFee - $discountAmount, 2);

        $order = DB::transaction(function () use (
            $customer, $payload, $priced, $paymentMethod,
            $deliveryFee, $serviceFee, $discountAmount, $totalAmount, $coupon
        ): Order {
            $order = Order::query()->create([
                'city_id' => $payload['city_id'],
                'customer_id' => $customer->id,
                'branch_id' => $payload['branch_id'],
                'coupon_id' => $coupon?->id,
                'domain_type' => $payload['domain_type'],
                'payment_method' => $paymentMethod->value,
                'payment_status' => 'unpaid',
                'status' => OrderStatus::PENDING_RESTAURANT_APPROVAL,
                'subtotal_amount' => $priced['subtotal'],
                'delivery_fee' => $deliveryFee,
                'service_fee' => $serviceFee,
                'discount_amount' => $discountAmount,
                'total_amount' => $totalAmount,
                'delivery_address' => $payload['delivery_address'],
                'delivery_lat' => $payload['delivery_lat'] ?? null,
                'delivery_lng' => $payload['delivery_lng'] ?? null,
                'notes' => $payload['notes'] ?? null,
            ]);

            $order->items()->createMany(
                collect($priced['items'])->map(fn (array $item): array => [
                    'product_id' => $item['product_id'],
                    'item_name' => $item['item_name'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'line_total' => $item['line_total'],
                    'selected_options' => $item['selected_options'],
                ])->all()
            );

            if ($coupon) {
                CouponUsage::query()->create(['coupon_id' => $coupon->id, 'user_id' => $customer->id, 'order_id' => $order->id]);
                $coupon->increment('usage_count');
            }

            if ($paymentMethod === PaymentMethod::CASH_ON_DELIVERY) {
                $this->paymentService->createCashPayment($order);
            }

            return $order;
        });

        $this->cartService->clear($customer);

        // Audit log
        AuditLog::record('order.created', $order, [], ['total' => $totalAmount, 'items' => count($priced['items'])]);

        // Broadcast
        OrderCreated::dispatch($order->fresh()->load('city', 'branch.restaurant', 'items', 'courierAssignment'));
        OrderStatusUpdated::dispatch($order->fresh()->load('branch.restaurant', 'courierAssignment'));

        // Restoran bildirimi — queue'ya gönder
        SendOrderNotificationJob::dispatch($order->id, 'new_order');

        return $order->fresh()->load('city', 'branch.restaurant', 'items', 'coupon', 'courierAssignment', 'latestPayment');
    }

    public function showForUser(User $user, Order $order): Order
    {
        $this->ensureUserCanAccessOrder($user, $order);

        return $order->load('city', 'branch.restaurant', 'items.product', 'coupon', 'courierAssignment.courier', 'latestPayment');
    }

    public function approve(User $actor, Order $order): Order
    {
        $this->ensureRestaurantCanManageOrder($actor, $order);

        if (($order->status->value ?? $order->status) !== OrderStatus::PENDING_RESTAURANT_APPROVAL->value) {
            throw ValidationException::withMessages(['status' => 'Yalnızca bekleyen siparişler onaylanabilir.']);
        }

        if ($order->payment_method === PaymentMethod::CARD && ! $order->isPaid()) {
            throw ValidationException::withMessages(['payment' => 'Kart ödemesi tamamlanmadan sipariş onaylanamaz.']);
        }

        $order->forceFill(['status' => OrderStatus::SEARCHING_COURIER, 'approved_at' => now()])->save();

        AuditLog::record('order.approved', $order, [], ['approved_by' => $actor->id]);
        OrderApproved::dispatch($order->fresh()->load('city', 'branch.restaurant', 'items', 'courierAssignment'));
        OrderStatusUpdated::dispatch($order->fresh()->load('branch.restaurant', 'courierAssignment'));
        SendOrderNotificationJob::dispatch($order->id, 'approved');

        return $order->fresh()->load('city', 'branch.restaurant', 'items', 'courierAssignment');
    }

    public function reject(User $actor, Order $order, ?string $reason = null): Order
    {
        $this->ensureRestaurantCanManageOrder($actor, $order);

        $order->forceFill(['status' => OrderStatus::REJECTED, 'notes' => $reason ?: $order->notes])->save();

        if ($order->coupon_id) {
            CouponUsage::query()->where('order_id', $order->id)->delete();
            Coupon::query()->where('id', $order->coupon_id)->decrement('usage_count');
        }

        if ($order->isPaid() && $order->payment_method === PaymentMethod::CARD) {
            $this->paymentService->refund($order, null, 'Restoran siparişi reddetti.');
        }

        AuditLog::record('order.rejected', $order, [], ['reason' => $reason, 'rejected_by' => $actor->id]);
        OrderRejected::dispatch($order->fresh()->load('city', 'branch.restaurant', 'items', 'courierAssignment'));
        OrderStatusUpdated::dispatch($order->fresh()->load('branch.restaurant', 'courierAssignment'));
        SendOrderNotificationJob::dispatch($order->id, 'rejected', null, $reason);

        return $order->fresh()->load('city', 'branch.restaurant', 'items', 'courierAssignment');
    }

    public function dispatchAssignment(User $actor, Order $order): CourierAssignment
    {
        $this->ensureRestaurantCanManageOrder($actor, $order);

        $assignment = $order->courierAssignment()->firstOrCreate([], [
            'status' => 'searching',
            'search_started_at' => now(),
        ]);

        AssignCourierJob::dispatch($order->id);

        return $assignment->fresh();
    }

    public function deliver(User $actor, Order $order): Order
    {
        if (($actor->role->value ?? $actor->role) !== UserRole::ADMIN->value
            && ($order->courierAssignment?->courier_id !== $actor->id || ! $actor->belongsToCity($order->city_id))) {
            abort(403, 'Yalnızca atanan kurye veya admin teslimatı tamamlayabilir.');
        }

        $order->forceFill(['status' => OrderStatus::DELIVERED, 'delivered_at' => now()])->save();

        if ($order->isCashOnDelivery() && ! $order->isPaid()) {
            $this->paymentService->completeCashPayment($order);
        }

        AuditLog::record('order.delivered', $order, [], ['delivered_by' => $actor->id]);
        OrderStatusUpdated::dispatch($order->fresh()->load('branch.restaurant', 'courierAssignment'));
        SendOrderNotificationJob::dispatch($order->id, 'delivered');

        return $order->fresh()->load('city', 'branch.restaurant', 'items', 'courierAssignment', 'latestPayment');
    }

    // ─── Yardımcı metotlar ───────────────────────────────────────────────────

    private function ensureUserCanAccessOrder(User $user, Order $order): void
    {
        $role = $user->role->value ?? $user->role;
        $allowed = $role === UserRole::ADMIN->value
            || ($role === UserRole::RESTAURANT->value && $user->ownsRestaurantId($order->branch->restaurant_id) && $user->belongsToCity($order->city_id))
            || ($order->customer_id === $user->id && $user->belongsToCity($order->city_id))
            || ($order->courierAssignment?->courier_id === $user->id && $user->belongsToCity($order->city_id));

        if (! $allowed) {
            abort(403, 'Bu siparişe erişim yetkiniz yok.');
        }
    }

    private function ensureRestaurantCanManageOrder(User $actor, Order $order): void
    {
        $role = $actor->role->value ?? $actor->role;
        if ($role === UserRole::ADMIN->value) { return; }
        if ($role !== UserRole::RESTAURANT->value || ! $actor->ownsRestaurantId($order->branch->restaurant_id) || ! $actor->belongsToCity($order->city_id)) {
            abort(403, 'Yalnızca restoranın sahibi veya admin bu işlemi yapabilir.');
        }
    }

    private function calculateDeliveryFee(string $domainType, float $serviceRadiusKm): float
    {
        $baseFee = match ($domainType) { 'market' => 5.5, 'pharmacy' => 4.5, default => 3.5 };
        return round($baseFee + max($serviceRadiusKm - 3, 0) * 0.35, 2);
    }

    private function calculateServiceFee(float $subtotal): float
    {
        return round(min(max($subtotal * 0.05, 1.0), 5.0), 2);
    }
}
