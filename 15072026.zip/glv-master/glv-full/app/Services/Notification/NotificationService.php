<?php

namespace App\Services\Notification;

use App\Models\DeviceToken;
use App\Models\Order;
use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class NotificationService
{
    private string $fcmUrl = 'https://fcm.googleapis.com/v1/projects/{project_id}/messages:send';

    // ─── Sipariş bildirimleri ────────────────────────────────────────────────

    /** Müşteriye: siparişi onaylandı */
    public function notifyOrderApproved(Order $order): void
    {
        $this->sendToUser($order->customer_id, [
            'title' => '✅ Siparişiniz Onaylandı!',
            'body' => "{$order->branch->restaurant->name} siparişinizi hazırlamaya başladı.",
            'data' => ['order_id' => (string) $order->id, 'screen' => 'order_tracking'],
        ]);
    }

    /** Müşteriye: sipariş reddedildi */
    public function notifyOrderRejected(Order $order, ?string $reason = null): void
    {
        $this->sendToUser($order->customer_id, [
            'title' => '❌ Siparişiniz Reddedildi',
            'body' => $reason ?? 'Restoran siparişinizi kabul edemedi.',
            'data' => ['order_id' => (string) $order->id, 'screen' => 'orders'],
        ]);
    }

    /** Müşteriye: kurye yola çıktı */
    public function notifyOrderOutForDelivery(Order $order): void
    {
        $this->sendToUser($order->customer_id, [
            'title' => '🚴 Kurye Yolda!',
            'body' => "Siparişiniz teslimata çıktı. Tahmini süre: {$order->branch->estimated_delivery_minutes} dk.",
            'data' => ['order_id' => (string) $order->id, 'screen' => 'order_tracking'],
        ]);
    }

    /** Müşteriye: teslim edildi */
    public function notifyOrderDelivered(Order $order): void
    {
        $this->sendToUser($order->customer_id, [
            'title' => '🎉 Siparişiniz Teslim Edildi!',
            'body' => 'Afiyet olsun! Siparişinizi değerlendirmeyi unutmayın.',
            'data' => ['order_id' => (string) $order->id, 'screen' => 'order_review'],
        ]);
    }

    /** Restorana: yeni sipariş geldi */
    public function notifyRestaurantNewOrder(Order $order): void
    {
        // Restoranın tüm kullanıcılarına bildirim gönder
        $restaurantUserIds = User::where('restaurant_id', $order->branch->restaurant_id)
            ->pluck('id')
            ->toArray();

        foreach ($restaurantUserIds as $userId) {
            $this->sendToUser($userId, [
                'title' => '🔔 Yeni Sipariş!',
                'body' => "#{$order->id} numaralı sipariş geldi. Toplam: {$order->total_amount} KM",
                'data' => ['order_id' => (string) $order->id, 'screen' => 'restaurant_orders'],
            ]);
        }
    }

    /** Kuryeye: sipariş teklifi */
    public function notifyCourierNewAssignment(Order $order, int $courierId): void
    {
        $this->sendToUser($courierId, [
            'title' => '📦 Yeni Sipariş Teklifi!',
            'body' => "{$order->branch->name} → {$order->delivery_address}",
            'data' => ['order_id' => (string) $order->id, 'screen' => 'courier_order'],
        ]);
    }

    // ─── FCM gönderim altyapısı ──────────────────────────────────────────────

    private function sendToUser(int $userId, array $notification): void
    {
        $tokens = DeviceToken::where('user_id', $userId)
            ->pluck('token')
            ->toArray();

        if (empty($tokens)) {
            return;
        }

        foreach ($tokens as $token) {
            $this->sendFcm($token, $notification);
        }
    }

    private function sendFcm(string $token, array $notification): void
    {
        $projectId = config('services.firebase.project_id');
        $url = str_replace('{project_id}', $projectId, $this->fcmUrl);
        $accessToken = $this->getAccessToken();

        $payload = [
            'message' => [
                'token' => $token,
                'notification' => [
                    'title' => $notification['title'],
                    'body' => $notification['body'],
                ],
                'data' => $notification['data'] ?? [],
                'android' => [
                    'priority' => 'high',
                    'notification' => ['sound' => 'default', 'channel_id' => 'glv_orders'],
                ],
                'apns' => [
                    'payload' => ['aps' => ['sound' => 'default', 'badge' => 1]],
                ],
            ],
        ];

        try {
            $response = Http::withToken($accessToken)
                ->post($url, $payload);

            if (! $response->successful()) {
                Log::warning('FCM gönderim hatası', [
                    'token' => substr($token, 0, 20) . '...',
                    'status' => $response->status(),
                    'body' => $response->body(),
                ]);

                // Geçersiz token ise sil
                if ($response->status() === 404 || str_contains($response->body(), 'UNREGISTERED')) {
                    DeviceToken::where('token', $token)->delete();
                }
            }
        } catch (\Throwable $e) {
            Log::error('FCM exception', ['error' => $e->getMessage()]);
        }
    }

    private function getAccessToken(): string
    {
        // Google OAuth2 access token — production'da service account JSON kullanılır
        // Geliştirme kolaylığı için config'den alınır
        return config('services.firebase.server_key', '');
    }
}
