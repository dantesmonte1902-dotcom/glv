<?php

namespace App\Models;

use App\Enums\OrderStatus;
use App\Enums\PaymentMethod;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'city_id',
        'customer_id',
        'branch_id',
        'coupon_id',
        'domain_type',
        'payment_method',
        'payment_status',
        'status',
        'subtotal_amount',
        'delivery_fee',
        'service_fee',
        'discount_amount',
        'total_amount',
        'delivery_address',
        'delivery_lat',
        'delivery_lng',
        'notes',
        'approved_at',
        'delivered_at',
    ];

    protected function casts(): array
    {
        return [
            'status' => OrderStatus::class,
            'payment_method' => PaymentMethod::class,
            'delivery_lat' => 'float',
            'delivery_lng' => 'float',
            'subtotal_amount' => 'float',
            'delivery_fee' => 'float',
            'service_fee' => 'float',
            'discount_amount' => 'float',
            'total_amount' => 'float',
            'approved_at' => 'datetime',
            'delivered_at' => 'datetime',
        ];
    }

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(RestaurantBranch::class, 'branch_id');
    }

    public function coupon(): BelongsTo
    {
        return $this->belongsTo(Coupon::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function courierAssignment(): HasOne
    {
        return $this->hasOne(CourierAssignment::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function latestPayment(): HasOne
    {
        return $this->hasOne(Payment::class)->latestOfMany();
    }

    public function isPaid(): bool
    {
        return $this->payment_status === 'paid';
    }

    public function isCashOnDelivery(): bool
    {
        return $this->payment_method === PaymentMethod::CASH_ON_DELIVERY;
    }
}
