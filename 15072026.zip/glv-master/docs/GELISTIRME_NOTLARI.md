# GLV — Faz 1: Menu Sistemi Değişiklik Özeti

## Yeni dosyalar

### Migration'lar (database/migrations/)
| Dosya | Ne yapar |
|-------|----------|
| `2026_06_20_000001_create_menu_categories_table.php` | Menü kategorileri tablosu |
| `2026_06_20_000002_create_products_table.php` | Ürünler tablosu |
| `2026_06_20_000003_create_product_options_tables.php` | Opsiyon grupları + seçenekler |
| `2026_06_20_000004_extend_branches_and_order_items_for_menu.php` | Şubeye is_open/saatler/min tutar; order_items'a product_id + selected_options ekler |

### Modeller (app/Models/)
- `MenuCategory.php`
- `Product.php`
- `ProductOptionGroup.php`
- `ProductOption.php`

### Servis (app/Services/Menu/)
- `MenuService.php` — menü getirme, ürün doğrulama, fiyat snapshot

### Controller'lar
- `app/Http/Controllers/Api/V1/MenuController.php` — public menü endpoint'leri
- `app/Http/Controllers/Api/V1/Admin/MenuManagementController.php` — restoran menü CRUD

### Form Request'ler (app/Http/Requests/Api/V1/Menu/)
- `StoreCategoryRequest.php`
- `StoreProductRequest.php`
- `UpdateProductRequest.php`

### Resource (app/Http/Resources/)
- `ProductResource.php`

## Güncellenen dosyalar

| Dosya | Değişiklik |
|-------|------------|
| `app/Models/Restaurant.php` | `categories()` ve `products()` ilişkileri eklendi |
| `app/Models/RestaurantBranch.php` | `is_open`, `opens_at`, `closes_at`, `minimum_order_amount`, `estimated_delivery_minutes` fillable'a eklendi |
| `app/Models/OrderItem.php` | `product_id`, `selected_options` eklendi; `product()` ilişkisi eklendi |
| `app/Http/Requests/Api/V1/Orders/StoreOrderRequest.php` | `items` artık `product_id` + `selected_options` alıyor (eski `item_name`/`unit_price` elle girilmiyor) |
| `app/Services/Orders/OrderService.php` | `MenuService` inject edildi; fiyat hesaplama MenuService'e devredildi; şube açık/kapalı kontrolü eklendi |
| `routes/api.php` | Menu endpoint'leri (public + admin) eklendi |
| `database/seeders/DatabaseSeeder.php` | Demo menü kategorileri, ürünler ve opsiyon grupları eklendi |

## Yeni API endpoint'leri

### Public (auth gerekmez)
```
GET  /api/v1/branches/{branch}/menu
GET  /api/v1/branches/{branch}/products/{product}
```

### Admin/Restoran (auth + rol gerekir)
```
GET    /api/v1/admin/restaurants/{restaurant}/categories
POST   /api/v1/admin/restaurants/{restaurant}/categories
PATCH  /api/v1/admin/categories/{category}

GET    /api/v1/admin/categories/{category}/products
POST   /api/v1/admin/categories/{category}/products
PATCH  /api/v1/admin/products/{product}
DELETE /api/v1/admin/products/{product}

POST   /api/v1/admin/products/{product}/option-groups
DELETE /api/v1/admin/option-groups/{group}
```

## Kurulum
```bash
docker compose exec app php artisan migrate
docker compose exec app php artisan db:seed --force
```
# GLV — Faz 2: Sepet ve Checkout Değişiklik Özeti

## Yeni dosyalar

### Migration'lar
| Dosya | Ne yapar |
|-------|----------|
| `2026_06_20_000005_create_coupons_table.php` | `coupons` + `coupon_usages` tabloları |
| `2026_06_20_000006_add_coupon_and_fees_to_orders_table.php` | `orders` tablosuna `coupon_id`, `discount_amount`, `service_fee` ekler |

### Modeller
- `Coupon.php` — kupon modeli, geçerlilik ve indirim hesaplama
- `CouponUsage.php` — kullanım kaydı

### Servis
- `CartService.php` — Redis tabanlı sepet (ekle/güncelle/sil/temizle + checkout özeti)

### Controller'lar
- `CartController.php` — sepet endpoint'leri
- `Admin/CouponController.php` — kupon CRUD + müşteri doğrulama

### Form Request'ler
- `Cart/AddCartItemRequest.php`
- `Cart/UpdateCartItemRequest.php`
- `Cart/CheckoutSummaryRequest.php`

### Seeder
- `CouponSeeder.php` — demo kuponlar

## Güncellenen dosyalar
| Dosya | Değişiklik |
|-------|------------|
| `Order.php` | `coupon_id`, `service_fee`, `discount_amount` eklendi |
| `OrderService.php` | Kupon entegrasyonu, sepet temizleme, service_fee hesaplama |
| `OrderResource.php` | Yeni fiyat alanları, kupon bilgisi, selected_options |
| `StoreOrderRequest.php` | `coupon_code` alanı eklendi |
| `routes/api.php` | Sepet ve kupon endpoint'leri eklendi |

## Yeni API endpoint'leri

### Sepet (auth + customer rolü gerekir)
```
GET    /api/v1/cart                      → sepeti görüntüle
POST   /api/v1/cart/items                → ürün ekle
PATCH  /api/v1/cart/items/{itemKey}      → miktar güncelle
DELETE /api/v1/cart/items/{itemKey}      → ürün sil
DELETE /api/v1/cart                      → sepeti temizle
POST   /api/v1/cart/checkout-summary     → fiyat özeti + kupon uygula
```

### Kupon doğrulama (müşteri)
```
GET    /api/v1/coupons/validate?code=ABC&branch_id=1
```

### Kupon yönetimi (sadece admin)
```
GET    /api/v1/admin/coupons
POST   /api/v1/admin/coupons
GET    /api/v1/admin/coupons/{coupon}
PATCH  /api/v1/admin/coupons/{coupon}
DELETE /api/v1/admin/coupons/{coupon}
```

## Sipariş verme akışı (Faz 1 + Faz 2 birleşik)

```
1. GET  /api/v1/branches/{branch}/menu          → menüyü gör
2. POST /api/v1/cart/items                       → sepete ekle (birden fazla kez)
3. POST /api/v1/cart/checkout-summary            → fiyat özetini gör, kupon uygula
4. POST /api/v1/orders                           → siparişi ver (sepet otomatik temizlenir)
5. GET  /api/v1/orders/{order}                   → siparişi takip et
```

## Kurulum
```bash
docker compose exec app php artisan migrate
docker compose exec app php artisan db:seed --class=CouponSeeder --force
```

## Checkout summary örnek yanıt
```json
{
  "branch": { "id": 1, "name": "Demo Burger Center", "minimum_order_amount": 10 },
  "items": [
    {
      "product_id": 1,
      "item_name": "Classic Burger",
      "quantity": 2,
      "unit_price": 16.40,
      "line_total": 32.80,
      "selected_options": [
        { "option_id": 2, "group_name": "Boy Seçimi", "option_name": "Menü", "price_modifier": 7.0 }
      ]
    }
  ],
  "subtotal": 32.80,
  "delivery_fee": 3.50,
  "service_fee": 1.64,
  "discount": 3.28,
  "total": 34.66,
  "coupon": { "code": "HOSGELDIN10", "type": "percentage", "value": 10, "discount_applied": 3.28 },
  "estimated_delivery_minutes": 35
}
```
# GLV — Faz 3: Ödeme Sistemi Değişiklik Özeti

## Yeni dosyalar

### Migration'lar
| Dosya | Ne yapar |
|-------|----------|
| `2026_06_20_000007_create_payments_table.php` | `payments` tablosu |
| `2026_06_20_000008_add_payment_fields_to_orders_table.php` | `orders`'a `payment_method`, `payment_status` ekler |

### Modeller
- `Payment.php` — ödeme kaydı, Stripe intent, iade alanları
- `Order.php` — `payment_method`, `payment_status`, `payments()` ilişkisi güncellendi

### Enum'lar
- `PaymentMethod.php` — `card`, `cash_on_delivery`
- `PaymentStatus.php` — `pending`, `processing`, `succeeded`, `failed`, `refunded`, `partially_refunded`

### Servis
- `PaymentService.php` — Stripe PaymentIntent, kapıda ödeme, webhook işleme, iade

### Controller
- `PaymentController.php` — tüm ödeme endpoint'leri

### Form Request'ler
- `Payment/CreatePaymentIntentRequest.php`
- `Payment/RefundRequest.php`

### Resource
- `PaymentResource.php`

### Config
- `config/services.php` — Stripe ayarları eklendi

## Güncellenen dosyalar
| Dosya | Değişiklik |
|-------|------------|
| `Order.php` | payment alanları + `payments()`, `latestPayment()` ilişkileri |
| `OrderService.php` | `PaymentService` inject, sipariş sonrası ödeme kaydı, red sonrası iade |
| `OrderResource.php` | `payment_method`, `payment_status`, `payment` bloğu eklendi |
| `StoreOrderRequest.php` | `payment_method` zorunlu alan eklendi |
| `routes/api.php` | Ödeme endpoint'leri, webhook (auth dışı) eklendi |

## Kurulum
```bash
# 1. Stripe paketini yükle
docker compose exec app composer require stripe/stripe-php

# 2. .env dosyasına Stripe anahtarlarını ekle
STRIPE_KEY=pk_test_xxx
STRIPE_SECRET=sk_test_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx

# 3. Migration çalıştır
docker compose exec app php artisan migrate
```

## Yeni API endpoint'leri

```
# Kart ödemesi — müşteri sipariş verdikten sonra çağırır
POST  /api/v1/orders/{order}/payment/intent

# Kapıda ödeme kaydı — sipariş sonrası otomatik oluşturuluyor (manuel de çağrılabilir)
POST  /api/v1/orders/{order}/payment/cash

# Kapıda ödemeyi tamamla — kurye teslim ettiğinde
POST  /api/v1/orders/{order}/payment/cash/complete

# Ödeme bilgisini görüntüle
GET   /api/v1/orders/{order}/payment

# İade (admin)
POST  /api/v1/admin/orders/{order}/payment/refund

# Stripe webhook (auth yok)
POST  /api/v1/webhooks/stripe
```

## Tam sipariş + ödeme akışı

### Kart ile ödeme
```
1. POST /api/v1/orders          → payment_method: "card" ile sipariş ver
2. POST /api/v1/orders/{id}/payment/intent  → client_secret al
3. [Flutter/Web] Stripe SDK ile ödemeyi tamamla
4. Stripe → webhook → payment_intent.succeeded → payment_status: "paid"
5. Restoran siparişi onaylar (ödeme kontrolü geçer)
6. Kurye teslim eder
```

### Kapıda ödeme
```
1. POST /api/v1/orders          → payment_method: "cash_on_delivery" ile sipariş ver
   (Otomatik: cash payment kaydı oluşturulur, status: pending)
2. Restoran onaylar
3. Kurye teslim eder
4. POST /api/v1/orders/{id}/payment/cash/complete → payment_status: "paid"
```

### İade (sipariş reddedildiğinde otomatik)
```
Restoran reddederse → kart ödemesi otomatik iade edilir
Admin manuel iade: POST /api/v1/admin/orders/{id}/payment/refund
  body: { "amount": 10.50, "reason": "Müşteri talebi" }
  amount null gönderilirse tam iade yapılır
```
# GLV — Faz 4: Admin ve Restoran Paneli (Filament)

## Kurulum Sırası (ÖNEMLİ)

```bash
# 1. Filament yükle
docker compose exec app composer require filament/filament:"^3.x" -W

# 2. Admin paneli kur
docker compose exec app php artisan filament:install --panels
# "panel id" sorusunda: admin yaz

# 3. Restoran paneli kur
docker compose exec app php artisan make:filament-panel restaurant

# 4. Bu ZIP'teki dosyaları projeye kopyala
#    (app/Filament/, app/Providers/Filament/, app/Models/User.php)

# 5. config/app.php'ye provider'ları ekle:
#    App\Providers\Filament\AdminPanelProvider::class,
#    App\Providers\Filament\RestaurantPanelProvider::class,

# 6. Migration (Filament kendi tablolarını oluşturur)
docker compose exec app php artisan migrate
```

## Yeni dosyalar

### Provider'lar
- `app/Providers/Filament/AdminPanelProvider.php`
- `app/Providers/Filament/RestaurantPanelProvider.php`

### Admin Panel (`app/Filament/Admin/`)
| Dosya | Açıklama |
|-------|----------|
| `Pages/Dashboard.php` | Ana sayfa |
| `Widgets/StatsOverview.php` | Bugünkü sipariş/gelir/bekleyen istatistikleri |
| `Widgets/RevenueChart.php` | Son 7 günlük gelir grafiği |
| `Resources/CityResource.php` | Şehir yönetimi |
| `Resources/RestaurantResource.php` | Restoran + şube yönetimi (repeater ile) |
| `Resources/OrderResource.php` | Tüm siparişler, onayla/reddet aksiyonu |
| `Resources/UserResource.php` | Kullanıcı yönetimi, kurye aktivasyonu |
| `Resources/CouponResource.php` | Kupon yönetimi |

### Restoran Panel (`app/Filament/Restaurant/`)
| Dosya | Açıklama |
|-------|----------|
| `Pages/Dashboard.php` | Restoran ana sayfası |
| `Widgets/RestaurantStatsWidget.php` | Bugün/ay gelir, bekleyen sayısı |
| `Widgets/ActiveOrdersWidget.php` | Bekleyen siparişler — 20s otomatik yenile, onayla/reddet |
| `Resources/OrderResource.php` | Sadece kendi şubelerinin siparişleri |
| `Resources/MenuCategoryResource.php` | Kategori yönetimi, sürükle-bırak sıralama |
| `Resources/ProductResource.php` | Ürün + opsiyon grubu yönetimi |
| `Resources/BranchResource.php` | Şube aç/kapat, çalışma saatleri |

## Güncellenen dosyalar
| Dosya | Değişiklik |
|-------|------------|
| `app/Models/User.php` | `FilamentUser` implement, `canAccessPanel()` eklendi |

## Panel URL'leri
```
Admin panel:     http://localhost:8080/admin
Restoran panel:  http://localhost:8080/restaurant
```

## Giriş bilgileri (seed ile oluşturulmuş)
```
Admin:     admin@glv.local      / password
Restoran:  restaurant@glv.local / password
```

## Özellikler
- Restoran paneli sadece kendi restoranının verilerini görür (tenant izolasyonu)
- Bekleyen siparişler 20 saniyede bir otomatik yenilenir
- Ürünler ve kategoriler sürükle-bırak ile sıralanabilir
- Şube aç/kapat butonu tek tıkla
- Admin paneli Türkçe etiketler
# GLV — Faz 5: Flutter Mobil Uygulama

## Kurulum
```bash
# Flutter SDK gerekirhttps://flutter.dev/docs/get-started/install
flutter pub get
flutter run
```

## Proje yapısı
```
lib/
├── main.dart
├── core/
│   ├── api/api_client.dart          # Dio + Auth interceptor
│   ├── constants/app_constants.dart # URL, key sabitleri
│   ├── router/app_router.dart       # GoRouter navigasyon
│   └── theme/app_theme.dart         # Material 3 tema
└── features/
    ├── auth/       # Login, Register, AuthNotifier
    ├── menu/       # Home, RestaurantMenu, ProductDetail
    ├── cart/       # CartScreen, CheckoutScreen
    ├── orders/     # OrdersScreen, OrderTracking
    ├── courier/    # CourierHome (online/offline)
    └── profile/    # ProfileScreen
```

## Ekranlar
| Ekran | Açıklama |
|-------|----------|
| LoginScreen | E-posta + şifre girişi |
| RegisterScreen | Kayıt + şehir seçimi |
| HomeScreen | Şube listesi |
| RestaurantMenuScreen | Kategori + ürün listesi |
| ProductDetailScreen | Opsiyon seçimi, sepete ekle |
| CartScreen | Sepet görüntüle, miktar güncelle |
| CheckoutScreen | Adres, ödeme yöntemi, kupon, sipariş ver |
| OrderTrackingScreen | Sipariş durum adımları |
| CourierHomeScreen | Online/offline toggle, istatistikler |
| ProfileScreen | Kullanıcı bilgileri, çıkış |

## Ortam değişkenleri
```bash
flutter run \
  --dart-define=API_BASE_URL=http://10.0.2.2:8080/api/v1 \
  --dart-define=STRIPE_KEY=pk_test_xxx \
  --dart-define=WS_HOST=10.0.2.2 \
  --dart-define=REVERB_APP_KEY=your-key
```

## Android emülatörde localhost
10.0.2.2 → bilgisayarınızın localhost'una denk gelir.
# GLV — Faz 6: Üretim Hazırlığı

## Yeni dosyalar

### Migration
| Dosya | Ne yapar |
|-------|----------|
| `2026_06_20_000009_create_audit_logs_and_device_tokens.php` | `audit_logs` + `device_tokens` tabloları |

### Modeller
- `AuditLog.php` — olay kaydı, `AuditLog::record(...)` statik yardımcı
- `DeviceToken.php` — FCM token kayıt

### Middleware
- `ApiRateLimitMiddleware.php` — rol bazlı rate limiting (admin 600, customer 120, guest 30/dk)

### Servisler / Job'lar
- `NotificationService.php` — FCM push bildirimleri (sipariş onay/red/teslimat, restoran yeni sipariş, kurye atama)
- `SendOrderNotificationJob.php` — bildirim gönderimini queue'ya taşır, 3 retry

### Controller
- `DeviceTokenController.php` — FCM token kayıt/silme

### Güncellemeler
- `OrderService.php` — her kritik olayda `AuditLog::record()` + `SendOrderNotificationJob::dispatch()`
- `bootstrap/app.php` — rate limiter tanımları, JSON hata handler'ları
- `routes/api.php` — throttle middleware, device-token endpoint'leri
- `config/services.php` — Firebase, Sentry eklendi

### Altyapı
- `.github/workflows/ci-cd.yml` — GitHub Actions: test + lint + deploy
- `docker/glv-supervisor.conf` — Queue worker (x2), Notification worker, Reverb, Scheduler
- `docker/glv-nginx.conf` — SSL, WebSocket proxy, security headers
- `scripts/production-setup.sh` — Ubuntu 24.04 ilk kurulum scripti
- `.env.example` — tüm production değişkenleri

## Kurulum sırası

### Geliştirme
```bash
# Sentry paketi (opsiyonel)
docker compose exec app composer require sentry/sentry-laravel

# Migration
docker compose exec app php artisan migrate
```

### Production (ilk kurulum)
```bash
# 1. Sunucuyu hazırla
sudo chmod +x scripts/production-setup.sh
sudo ./scripts/production-setup.sh

# 2. Kodu deploy et
cd /var/www/glv
git clone <repo> .
cp .env.example .env
# .env'i doldur

# 3. Laravel kur
composer install --no-dev --optimize-autoloader
php artisan key:generate
php artisan migrate --force
php artisan db:seed --force

# 4. Cache oluştur
php artisan config:cache
php artisan route:cache
php artisan view:cache

# 5. SSL sertifikası al
certbot --nginx -d api.glv.ba

# 6. Worker'ları başlat
supervisorctl start all
```

## Rate limit tablosu
| Endpoint | Limit |
|----------|-------|
| POST /auth/login, /auth/register | 10/dk per IP |
| POST /orders | 5/dk per kullanıcı |
| Admin API | 600/dk |
| Restoran API | 300/dk |
| Kurye API | 200/dk |
| Müşteri API | 120/dk |
| Anonim | 30/dk |

## Push bildirim olayları
| Olay | Alıcı |
|------|-------|
| Sipariş oluşturuldu | Restoran |
| Sipariş onaylandı | Müşteri |
| Sipariş reddedildi | Müşteri |
| Kurye yolda | Müşteri |
| Teslim edildi | Müşteri |
| Kurye atandı | Kurye |

## CI/CD akışı
```
push to main
  → PHP lint (Pint)
  → Static analysis (PHPStan)
  → PHPUnit tests (PostgreSQL + Redis servis container)
  → Coverage raporu (Codecov)
  → SSH ile production deploy
  → php artisan migrate + cache:cache + queue:restart
```
