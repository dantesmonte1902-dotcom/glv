<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('disputes', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->foreignId('customer_id')->constrained('users')->cascadeOnDelete();

            $table->enum('type', ['missing_item', 'wrong_item', 'quality_issue', 'never_arrived', 'other']);
            $table->text('description');
            $table->string('photo_url')->nullable();

            $table->enum('status', ['open', 'under_review', 'resolved', 'rejected'])->default('open');

            $table->enum('resolution_type', ['refund', 'compensate_points', 'none'])->nullable();
            $table->decimal('resolution_amount', 8, 2)->nullable();
            $table->unsignedInteger('resolution_points')->nullable();
            $table->text('resolution_notes')->nullable();
            $table->foreignId('resolved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('resolved_at')->nullable();

            $table->timestamps();

            $table->index(['customer_id', 'created_at']);
            $table->index(['status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('disputes');
    }
};
