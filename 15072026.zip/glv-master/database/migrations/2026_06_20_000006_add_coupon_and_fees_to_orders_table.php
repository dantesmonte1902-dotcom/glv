<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table): void {
            $table->foreignId('coupon_id')
                ->nullable()
                ->after('branch_id')
                ->constrained('coupons')
                ->nullOnDelete();
            $table->decimal('discount_amount', 12, 2)->default(0)->after('delivery_fee');
            $table->decimal('service_fee', 12, 2)->default(0)->after('discount_amount');
            // total_amount = subtotal + delivery_fee + service_fee - discount_amount
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('coupon_id');
            $table->dropColumn(['discount_amount', 'service_fee']);
        });
    }
};
