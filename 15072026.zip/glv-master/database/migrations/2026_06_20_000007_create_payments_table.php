<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();

            // Ödeme yöntemi: card, cash_on_delivery
            $table->string('method');

            // Durum: pending, processing, succeeded, failed, refunded, partially_refunded
            $table->string('status')->default('pending');

            $table->decimal('amount', 12, 2);
            $table->string('currency', 3)->default('BAM'); // Bosna Hersek Markı

            // Stripe alanları (card ödemeler için)
            $table->string('stripe_payment_intent_id')->nullable()->unique();
            $table->string('stripe_client_secret')->nullable();
            $table->string('stripe_charge_id')->nullable();

            // İade
            $table->decimal('refunded_amount', 12, 2)->default(0);
            $table->string('refund_reason')->nullable();
            $table->timestamp('refunded_at')->nullable();

            // Başarı/hata
            $table->timestamp('paid_at')->nullable();
            $table->text('failure_message')->nullable();

            $table->timestamps();

            $table->index(['order_id', 'status']);
            $table->index(['user_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
