<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('courier_payouts', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('courier_id')->constrained('users')->cascadeOnDelete();

            $table->date('period_start');
            $table->date('period_end');
            $table->unsignedInteger('order_count')->default(0);
            $table->decimal('total_amount', 10, 2)->default(0);

            $table->enum('status', ['pending', 'paid'])->default('pending');
            $table->timestamp('paid_at')->nullable();
            $table->string('notes')->nullable();

            $table->timestamps();

            $table->index(['courier_id', 'period_start', 'period_end']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('courier_payouts');
    }
};
