<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('courier_earnings', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->foreignId('courier_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('courier_payout_id')->nullable()->constrained('courier_payouts')->nullOnDelete();

            $table->float('distance_km')->default(0);
            $table->decimal('base_fee', 8, 2)->default(0);
            $table->decimal('distance_fee', 8, 2)->default(0);
            $table->decimal('surge_fee', 8, 2)->default(0);
            $table->decimal('tip_amount', 8, 2)->default(0);
            $table->decimal('total_earning', 8, 2)->default(0);

            $table->enum('status', ['pending', 'paid'])->default('pending');
            $table->timestamp('earned_at')->nullable();

            $table->timestamps();

            $table->unique('order_id');
            $table->index(['courier_id', 'status']);
            $table->index(['courier_id', 'earned_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('courier_earnings');
    }
};
