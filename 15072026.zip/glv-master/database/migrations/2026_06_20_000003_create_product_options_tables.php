<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Seçenek grupları: "Boy Seçimi", "Ekstra Malzeme", "Sos"
        Schema::create('product_option_groups', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->string('name');                          // "Boy Seçimi"
            $table->boolean('is_required')->default(false);  // zorunlu mu?
            $table->boolean('is_multiple')->default(false);  // çoklu seçim olabilir mi?
            $table->integer('min_selections')->default(0);
            $table->integer('max_selections')->default(1);
            $table->integer('sort_order')->default(0);
            $table->timestamps();

            $table->index(['product_id', 'sort_order']);
        });

        // Tekil seçenekler: "Büyük +5 KM", "Küçük +0 KM", "Cheddar +2 KM"
        Schema::create('product_options', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('product_option_group_id')->constrained('product_option_groups')->cascadeOnDelete();
            $table->string('name');                          // "Büyük Boy"
            $table->decimal('price_modifier', 12, 2)->default(0); // ek ücret (+ veya -)
            $table->boolean('is_default')->default(false);
            $table->boolean('is_active')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();

            $table->index(['product_option_group_id', 'is_active', 'sort_order']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_options');
        Schema::dropIfExists('product_option_groups');
    }
};
