<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table): void {
            // Müşterinin seçtiği ödeme yöntemi: card, cash_on_delivery
            $table->string('payment_method')->default('cash_on_delivery')->after('domain_type');
            // Ödeme durumu özeti: unpaid, paid, refunded
            $table->string('payment_status')->default('unpaid')->after('payment_method');
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table): void {
            $table->dropColumn(['payment_method', 'payment_status']);
        });
    }
};
