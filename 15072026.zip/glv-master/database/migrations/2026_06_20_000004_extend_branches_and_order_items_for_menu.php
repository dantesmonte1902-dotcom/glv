<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Şubeye açık/kapalı durumu ve çalışma saati bilgisi ekle
        Schema::table('restaurant_branches', function (Blueprint $table): void {
            $table->boolean('is_open')->default(false)->after('is_active');
            $table->time('opens_at')->nullable()->after('is_open');
            $table->time('closes_at')->nullable()->after('opens_at');
            $table->decimal('minimum_order_amount', 12, 2)->default(0)->after('closes_at');
            $table->integer('estimated_delivery_minutes')->default(30)->after('minimum_order_amount');
        });

        // Order items'a ürün snapshot alanları ekle (fiyat kilitlemek için)
        Schema::table('order_items', function (Blueprint $table): void {
            $table->foreignId('product_id')
                ->nullable()
                ->after('order_id')
                ->constrained('products')
                ->nullOnDelete();
            // Seçilen opsiyonları JSON olarak sakla (snapshot)
            $table->json('selected_options')->nullable()->after('line_total');
        });
    }

    public function down(): void
    {
        Schema::table('order_items', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('product_id');
            $table->dropColumn('selected_options');
        });

        Schema::table('restaurant_branches', function (Blueprint $table): void {
            $table->dropColumn([
                'is_open',
                'opens_at',
                'closes_at',
                'minimum_order_amount',
                'estimated_delivery_minutes',
            ]);
        });
    }
};
