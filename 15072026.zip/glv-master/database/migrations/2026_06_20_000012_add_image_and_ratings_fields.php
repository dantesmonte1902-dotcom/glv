<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Ürünlere storage'da saklanan resim path'i ekle
        Schema::table('products', function (Blueprint $table): void {
            $table->string('image_path')->nullable()->after('image_url');
        });

        // Şube ortalama puanı (review eklendiğinde güncellenir)
        Schema::table('restaurant_branches', function (Blueprint $table): void {
            $table->decimal('avg_food_rating', 3, 2)->default(0)->after('estimated_delivery_minutes');
            $table->decimal('avg_delivery_rating', 3, 2)->default(0)->after('avg_food_rating');
            $table->unsignedInteger('review_count')->default(0)->after('avg_delivery_rating');
        });
    }

    public function down(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            $table->dropColumn('image_path');
        });
        Schema::table('restaurant_branches', function (Blueprint $table): void {
            $table->dropColumn(['avg_food_rating', 'avg_delivery_rating', 'review_count']);
        });
    }
};
