<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('campaigns', function (Blueprint $table): void {
            $table->id();
            $table->string('title');
            $table->string('message_title');
            $table->string('message_body', 500);

            // all: herkes, inactive_customers: N gündür sipariş vermeyenler,
            // city: belirli şehirdekiler, custom: segment_params'a göre serbest filtre
            $table->enum('segment_type', ['all', 'inactive_customers', 'city'])->default('all');
            $table->json('segment_params')->nullable();

            $table->enum('status', ['draft', 'sent'])->default('draft');
            $table->unsignedInteger('recipient_count')->default(0);
            $table->timestamp('sent_at')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('campaigns');
    }
};
