<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('reviews', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('order_id')->unique()->constrained('orders')->cascadeOnDelete();
            $table->foreignId('customer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('restaurant_id')->constrained('restaurants')->cascadeOnDelete();
            $table->foreignId('branch_id')->constrained('restaurant_branches')->cascadeOnDelete();
            $table->tinyInteger('food_rating')->unsigned();       // 1-5 yemek puanı
            $table->tinyInteger('delivery_rating')->unsigned();   // 1-5 teslimat puanı
            $table->text('comment')->nullable();
            $table->boolean('is_visible')->default(true);         // Admin gizleyebilir
            $table->timestamp('replied_at')->nullable();
            $table->text('reply')->nullable();                    // Restoran yanıtı
            $table->timestamps();

            $table->index(['restaurant_id', 'is_visible', 'created_at']);
            $table->index(['branch_id', 'is_visible']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reviews');
    }
};
