<?php

namespace Database\Factories;

use App\Models\Order;
use App\Models\Restaurant;
use App\Models\RestaurantBranch;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class ReviewFactory extends Factory
{
    public function definition(): array
    {
        return [
            'order_id' => Order::factory()->delivered(),
            'customer_id' => User::factory()->customer(),
            'restaurant_id' => Restaurant::factory(),
            'branch_id' => RestaurantBranch::factory(),
            'food_rating' => $this->faker->numberBetween(1, 5),
            'delivery_rating' => $this->faker->numberBetween(1, 5),
            'comment' => $this->faker->optional(0.7)->sentence(10),
            'is_visible' => true,
            'reply' => null,
            'replied_at' => null,
        ];
    }

    public function withComment(): static
    {
        return $this->state(['comment' => $this->faker->sentence(15)]);
    }

    public function withReply(): static
    {
        return $this->state([
            'reply' => $this->faker->sentence(8),
            'replied_at' => now(),
        ]);
    }

    public function hidden(): static
    {
        return $this->state(['is_visible' => false]);
    }

    public function fiveStar(): static
    {
        return $this->state(['food_rating' => 5, 'delivery_rating' => 5]);
    }
}
