<?php

namespace Database\Factories;

use App\Enums\CourierPayoutStatus;
use Illuminate\Database\Eloquent\Factories\Factory;

class CourierPayoutFactory extends Factory
{
    public function definition(): array
    {
        return [
            'period_start' => now()->subDays(7)->toDateString(),
            'period_end' => now()->toDateString(),
            'order_count' => $this->faker->numberBetween(1, 30),
            'total_amount' => $this->faker->randomFloat(2, 20, 400),
            'status' => CourierPayoutStatus::PENDING,
        ];
    }

    public function paid(): static
    {
        return $this->state(['status' => CourierPayoutStatus::PAID, 'paid_at' => now()]);
    }
}
