<?php

namespace Database\Factories;

use App\Enums\UserRole;
use App\Models\City;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;

class UserFactory extends Factory
{
    public function definition(): array
    {
        return [
            'city_id' => City::factory(),
            'restaurant_id' => null,
            'name' => $this->faker->name(),
            'email' => $this->faker->unique()->safeEmail(),
            'phone' => '+387' . $this->faker->numerify('6########'),
            'email_verified_at' => now(),
            'password' => Hash::make('password'),
            'role' => UserRole::CUSTOMER,
            'is_active' => true,
        ];
    }

    public function customer(): static
    {
        return $this->state(['role' => UserRole::CUSTOMER, 'restaurant_id' => null]);
    }

    public function restaurant(): static
    {
        return $this->state(fn (array $attr) => [
            'role' => UserRole::RESTAURANT,
        ]);
    }

    public function courier(): static
    {
        return $this->state(['role' => UserRole::COURIER, 'restaurant_id' => null]);
    }

    public function admin(): static
    {
        return $this->state(['role' => UserRole::ADMIN, 'restaurant_id' => null]);
    }

    public function inactive(): static
    {
        return $this->state(['is_active' => false]);
    }
}
