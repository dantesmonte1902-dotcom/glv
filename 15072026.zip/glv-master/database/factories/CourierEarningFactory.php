<?php

namespace Database\Factories;

use App\Enums\CourierEarningStatus;
use Illuminate\Database\Eloquent\Factories\Factory;

class CourierEarningFactory extends Factory
{
    public function definition(): array
    {
        $baseFee = 2.00;
        $distanceKm = $this->faker->randomFloat(2, 0.5, 8);
        $distanceFee = round($distanceKm * 0.60, 2);
        $surgeFee = 0.0;

        return [
            'distance_km' => $distanceKm,
            'base_fee' => $baseFee,
            'distance_fee' => $distanceFee,
            'surge_fee' => $surgeFee,
            'tip_amount' => 0,
            'total_earning' => round($baseFee + $distanceFee + $surgeFee, 2),
            'status' => CourierEarningStatus::PENDING,
            'earned_at' => now(),
        ];
    }

    public function paid(): static
    {
        return $this->state(['status' => CourierEarningStatus::PAID]);
    }
}
