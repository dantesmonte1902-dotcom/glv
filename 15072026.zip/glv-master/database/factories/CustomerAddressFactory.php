<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class CustomerAddressFactory extends Factory
{
    public function definition(): array
    {
        return [
            'user_id' => User::factory()->customer(),
            'title' => $this->faker->randomElement(['Ev', 'İş', 'Annem', 'Okul']),
            'full_address' => $this->faker->streetAddress() . ', No: ' . $this->faker->buildingNumber(),
            'district' => $this->faker->randomElement(['Centar', 'Novi Grad', 'Stari Grad', 'Ilidža']),
            'city_name' => 'Sarajevo',
            'lat' => $this->faker->latitude(43.82, 43.92),
            'lng' => $this->faker->longitude(18.33, 18.47),
            'notes' => $this->faker->optional(0.4)->sentence(5),
            'is_default' => false,
        ];
    }

    public function default(): static
    {
        return $this->state(['is_default' => true]);
    }
}
