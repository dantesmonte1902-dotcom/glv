<?php

namespace Database\Factories;

use App\Enums\OrderStatus;
use App\Models\City;
use App\Models\RestaurantBranch;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class OrderFactory extends Factory
{
    public function definition(): array
    {
        return [
            'city_id' => City::factory(),
            'customer_id' => User::factory()->customer(),
            'branch_id' => RestaurantBranch::factory(),
            'coupon_id' => null,
            'domain_type' => 'food',
            'payment_method' => 'cash_on_delivery',
            'payment_status' => 'unpaid',
            'status' => OrderStatus::PENDING_RESTAURANT_APPROVAL,
            'subtotal_amount' => $this->faker->randomFloat(2, 10, 100),
            'delivery_fee' => 3.50,
            'service_fee' => 1.50,
            'discount_amount' => 0,
            'total_amount' => fn (array $attr) => round(
                $attr['subtotal_amount'] + $attr['delivery_fee'] + $attr['service_fee'] - $attr['discount_amount'],
                2
            ),
            'delivery_address' => $this->faker->streetAddress() . ', Sarajevo',
            'delivery_lat' => $this->faker->latitude(43.8, 43.9),
            'delivery_lng' => $this->faker->longitude(18.3, 18.5),
            'notes' => null,
            'approved_at' => null,
            'delivered_at' => null,
        ];
    }

    public function pending(): static
    {
        return $this->state(['status' => OrderStatus::PENDING_RESTAURANT_APPROVAL]);
    }

    public function approved(): static
    {
        return $this->state([
            'status' => OrderStatus::SEARCHING_COURIER,
            'approved_at' => now(),
        ]);
    }

    public function delivered(): static
    {
        return $this->state([
            'status' => OrderStatus::DELIVERED,
            'approved_at' => now()->subHour(),
            'delivered_at' => now(),
            'payment_status' => 'paid',
        ]);
    }

    public function rejected(): static
    {
        return $this->state(['status' => OrderStatus::REJECTED]);
    }

    public function withCard(): static
    {
        return $this->state(['payment_method' => 'card']);
    }

    public function paid(): static
    {
        return $this->state(['payment_status' => 'paid']);
    }
}
