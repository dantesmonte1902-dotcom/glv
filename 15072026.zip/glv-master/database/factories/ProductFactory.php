<?php

namespace Database\Factories;

use App\Models\MenuCategory;
use App\Models\Restaurant;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class ProductFactory extends Factory
{
    public function definition(): array
    {
        $name = $this->faker->randomElement([
            'Classic Burger', 'Spicy Burger', 'Cheese Pizza', 'Margherita',
            'Cola', 'Ayran', 'Patates Kızartması', 'Soğan Halkası', 'Cheesecake',
        ]) . ' ' . $this->faker->unique()->numberBetween(1, 999);

        return [
            'restaurant_id' => Restaurant::factory(),
            'menu_category_id' => MenuCategory::factory(),
            'name' => $name,
            'slug' => Str::slug($name),
            'description' => $this->faker->sentence(),
            'image_url' => null,
            'image_path' => null,
            'base_price' => $this->faker->randomFloat(2, 3, 50),
            'preparation_time_minutes' => $this->faker->numberBetween(5, 30),
            'is_available' => true,
            'is_active' => true,
            'sort_order' => $this->faker->numberBetween(0, 20),
        ];
    }

    public function unavailable(): static
    {
        return $this->state(['is_available' => false]);
    }

    public function inactive(): static
    {
        return $this->state(['is_active' => false]);
    }

    public function withPrice(float $price): static
    {
        return $this->state(['base_price' => $price]);
    }
}
