<?php

namespace Database\Factories;

use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Models\Order;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class PaymentFactory extends Factory
{
    public function definition(): array
    {
        return [
            'order_id' => Order::factory(),
            'user_id' => User::factory()->customer(),
            'method' => PaymentMethod::CASH_ON_DELIVERY,
            'status' => PaymentStatus::PENDING,
            'amount' => $this->faker->randomFloat(2, 10, 150),
            'currency' => 'BAM',
            'stripe_payment_intent_id' => null,
            'stripe_client_secret' => null,
            'stripe_charge_id' => null,
            'refunded_amount' => 0,
            'refund_reason' => null,
            'refunded_at' => null,
            'paid_at' => null,
            'failure_message' => null,
        ];
    }

    public function card(): static
    {
        return $this->state([
            'method' => PaymentMethod::CARD,
            'stripe_payment_intent_id' => 'pi_test_' . $this->faker->lexify('??????????????????'),
            'stripe_client_secret' => 'pi_test_secret_' . $this->faker->lexify('??????????????????'),
        ]);
    }

    public function succeeded(): static
    {
        return $this->state([
            'status' => PaymentStatus::SUCCEEDED,
            'paid_at' => now(),
        ]);
    }

    public function failed(): static
    {
        return $this->state([
            'status' => PaymentStatus::FAILED,
            'failure_message' => 'Kart reddedildi.',
        ]);
    }

    public function refunded(): static
    {
        return $this->state(fn (array $attr) => [
            'status' => PaymentStatus::REFUNDED,
            'refunded_amount' => $attr['amount'],
            'refund_reason' => 'Sipariş reddedildi.',
            'refunded_at' => now(),
        ]);
    }
}
