<?php

namespace Database\Factories;

use App\Enums\LoyaltyPointTransactionType;
use Illuminate\Database\Eloquent\Factories\Factory;

class LoyaltyPointTransactionFactory extends Factory
{
    public function definition(): array
    {
        $points = $this->faker->numberBetween(10, 200);

        return [
            'type' => LoyaltyPointTransactionType::EARN,
            'points' => $points,
            'balance_after' => $points,
            'description' => 'Sipariş kazancı',
        ];
    }
}
