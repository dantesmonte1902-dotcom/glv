<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class CouponFactory extends Factory
{
    public function definition(): array
    {
        return [
            'code' => strtoupper($this->faker->unique()->lexify('????????')),
            'type' => 'fixed',
            'value' => $this->faker->randomFloat(2, 2, 15),
            'minimum_order_amount' => 0,
            'maximum_discount' => null,
            'restaurant_id' => null,
            'usage_limit' => null,
            'usage_count' => 0,
            'per_user_limit' => 1,
            'starts_at' => now()->subDay(),
            'expires_at' => now()->addMonth(),
            'is_active' => true,
        ];
    }

    public function percentage(float $percent = 10): static
    {
        return $this->state([
            'type' => 'percentage',
            'value' => $percent,
            'maximum_discount' => 10.00,
        ]);
    }

    public function expired(): static
    {
        return $this->state([
            'starts_at' => now()->subMonth(),
            'expires_at' => now()->subDay(),
        ]);
    }

    public function inactive(): static
    {
        return $this->state(['is_active' => false]);
    }

    public function withMinimum(float $amount): static
    {
        return $this->state(['minimum_order_amount' => $amount]);
    }
}
