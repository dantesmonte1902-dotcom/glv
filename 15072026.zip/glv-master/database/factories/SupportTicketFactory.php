<?php

namespace Database\Factories;

use App\Enums\SupportTicketStatus;
use Illuminate\Database\Eloquent\Factories\Factory;

class SupportTicketFactory extends Factory
{
    public function definition(): array
    {
        return [
            'subject' => $this->faker->sentence(4),
            'status' => SupportTicketStatus::OPEN,
            'last_message_at' => now(),
        ];
    }
}
