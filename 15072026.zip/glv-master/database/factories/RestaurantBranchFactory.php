<?php

namespace Database\Factories;

use App\Models\City;
use App\Models\Restaurant;
use Illuminate\Database\Eloquent\Factories\Factory;

class RestaurantBranchFactory extends Factory
{
    public function definition(): array
    {
        return [
            'restaurant_id' => Restaurant::factory(),
            'city_id' => City::factory(),
            'name' => $this->faker->company() . ' Şubesi',
            'address' => $this->faker->streetAddress(),
            'lat' => $this->faker->latitude(43.5, 44.2),
            'lng' => $this->faker->longitude(17.5, 18.8),
            'service_radius_km' => $this->faker->numberBetween(3, 10),
            'is_active' => true,
            'is_open' => true,
            'opens_at' => '09:00',
            'closes_at' => '23:00',
            'minimum_order_amount' => 10.00,
            'estimated_delivery_minutes' => 30,
            'avg_food_rating' => 0,
            'avg_delivery_rating' => 0,
            'review_count' => 0,
        ];
    }

    public function closed(): static
    {
        return $this->state(['is_open' => false]);
    }

    public function inactive(): static
    {
        return $this->state(['is_active' => false]);
    }
}
