<?php

namespace Database\Factories;

use App\Enums\DisputeStatus;
use App\Enums\DisputeType;
use Illuminate\Database\Eloquent\Factories\Factory;

class DisputeFactory extends Factory
{
    public function definition(): array
    {
        return [
            'type' => DisputeType::MISSING_ITEM,
            'description' => $this->faker->sentence(12),
            'status' => DisputeStatus::OPEN,
        ];
    }
}
