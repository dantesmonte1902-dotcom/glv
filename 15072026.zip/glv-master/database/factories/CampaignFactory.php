<?php

namespace Database\Factories;

use App\Enums\CampaignSegmentType;
use App\Enums\CampaignStatus;
use Illuminate\Database\Eloquent\Factories\Factory;

class CampaignFactory extends Factory
{
    public function definition(): array
    {
        return [
            'title' => $this->faker->sentence(3),
            'message_title' => '🎉 '.$this->faker->words(3, true),
            'message_body' => $this->faker->sentence(10),
            'segment_type' => CampaignSegmentType::ALL,
            'segment_params' => null,
            'status' => CampaignStatus::DRAFT,
            'recipient_count' => 0,
        ];
    }
}
