<?php

// database/seeders/CouponSeeder.php
// Bu dosyayı database/seeders/ klasörüne ekle
// DatabaseSeeder.php'ye $this->call(CouponSeeder::class); ekle

namespace Database\Seeders;

use App\Models\Coupon;
use Illuminate\Database\Seeder;

class CouponSeeder extends Seeder
{
    public function run(): void
    {
        // %10 indirim, max 5 KM, min 20 KM sipariş
        Coupon::query()->updateOrCreate(['code' => 'HOSGELDIN10'], [
            'type' => 'percentage',
            'value' => 10,
            'minimum_order_amount' => 20.00,
            'maximum_discount' => 5.00,
            'restaurant_id' => null,
            'usage_limit' => 500,
            'per_user_limit' => 1,
            'is_active' => true,
            'starts_at' => now(),
            'expires_at' => now()->addMonths(3),
        ]);

        // 5 KM sabit indirim
        Coupon::query()->updateOrCreate(['code' => 'INDIRIM5'], [
            'type' => 'fixed',
            'value' => 5.00,
            'minimum_order_amount' => 25.00,
            'maximum_discount' => null,
            'restaurant_id' => null,
            'usage_limit' => 200,
            'per_user_limit' => 2,
            'is_active' => true,
            'starts_at' => now(),
            'expires_at' => now()->addMonth(),
        ]);

        // Test kuponu (sınırsız kullanım)
        Coupon::query()->updateOrCreate(['code' => 'TEST'], [
            'type' => 'fixed',
            'value' => 1.00,
            'minimum_order_amount' => 0,
            'maximum_discount' => null,
            'restaurant_id' => null,
            'usage_limit' => null,
            'per_user_limit' => 999,
            'is_active' => true,
        ]);
    }
}
