<?php

namespace Database\Seeders;

use App\Enums\UserRole;
use App\Models\City;
use App\Models\CourierProfile;
use App\Models\MenuCategory;
use App\Models\Product;
use App\Models\ProductOption;
use App\Models\ProductOptionGroup;
use App\Models\Restaurant;
use App\Models\RestaurantBranch;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // ─── Şehirler ─────────────────────────────────────────────────────────
        $sarajevo = City::query()->updateOrCreate(['name' => 'Sarajevo'], [
            'country_code' => 'BA', 'is_active' => true,
        ]);
        City::query()->updateOrCreate(['name' => 'Mostar'], ['country_code' => 'BA', 'is_active' => true]);
        City::query()->updateOrCreate(['name' => 'Tuzla'], ['country_code' => 'BA', 'is_active' => true]);

        // ─── Restoran ve Şube ─────────────────────────────────────────────────
        $restaurant = Restaurant::query()->updateOrCreate(['brand_slug' => 'demo-burger'], [
            'name' => 'Demo Burger', 'is_active' => true,
        ]);

        $branch = RestaurantBranch::query()->updateOrCreate(
            ['restaurant_id' => $restaurant->id, 'city_id' => $sarajevo->id, 'name' => 'Demo Burger Center'],
            [
                'address' => 'Marshal Tito Street 1, Sarajevo',
                'lat' => 43.8563000,
                'lng' => 18.4131000,
                'service_radius_km' => 6,
                'is_active' => true,
                'is_open' => true,
                'opens_at' => '09:00',
                'closes_at' => '23:00',
                'minimum_order_amount' => 10.00,
                'estimated_delivery_minutes' => 35,
            ]
        );

        // ─── Menü Kategorileri ────────────────────────────────────────────────
        $burgerCat = MenuCategory::query()->updateOrCreate(
            ['restaurant_id' => $restaurant->id, 'slug' => 'burgerler'],
            ['name' => 'Burgerler', 'sort_order' => 1, 'is_active' => true]
        );

        $drinkCat = MenuCategory::query()->updateOrCreate(
            ['restaurant_id' => $restaurant->id, 'slug' => 'icecekler'],
            ['name' => 'İçecekler', 'sort_order' => 2, 'is_active' => true]
        );

        $sideCat = MenuCategory::query()->updateOrCreate(
            ['restaurant_id' => $restaurant->id, 'slug' => 'yan-urunler'],
            ['name' => 'Yan Ürünler', 'sort_order' => 3, 'is_active' => true]
        );

        // ─── Ürünler ─────────────────────────────────────────────────────────

        // Classic Burger
        $classic = Product::query()->updateOrCreate(
            ['restaurant_id' => $restaurant->id, 'slug' => 'classic-burger'],
            [
                'menu_category_id' => $burgerCat->id,
                'name' => 'Classic Burger',
                'description' => 'Dana eti, cheddar, domates, marul, özel sos',
                'base_price' => 14.90,
                'preparation_time_minutes' => 20,
                'is_available' => true,
                'is_active' => true,
                'sort_order' => 1,
            ]
        );

        // Classic Burger — Boy seçimi (zorunlu)
        $sizeGroup = ProductOptionGroup::query()->updateOrCreate(
            ['product_id' => $classic->id, 'name' => 'Boy Seçimi'],
            ['is_required' => true, 'is_multiple' => false, 'min_selections' => 1, 'max_selections' => 1, 'sort_order' => 1]
        );
        ProductOption::query()->updateOrCreate(['product_option_group_id' => $sizeGroup->id, 'name' => 'Tek'], ['price_modifier' => 0, 'is_default' => true, 'is_active' => true, 'sort_order' => 1]);
        ProductOption::query()->updateOrCreate(['product_option_group_id' => $sizeGroup->id, 'name' => 'Menü (Patates + İçecek)'], ['price_modifier' => 7.00, 'is_default' => false, 'is_active' => true, 'sort_order' => 2]);

        // Classic Burger — Ekstra (çoklu)
        $extraGroup = ProductOptionGroup::query()->updateOrCreate(
            ['product_id' => $classic->id, 'name' => 'Ekstra Malzeme'],
            ['is_required' => false, 'is_multiple' => true, 'min_selections' => 0, 'max_selections' => 5, 'sort_order' => 2]
        );
        ProductOption::query()->updateOrCreate(['product_option_group_id' => $extraGroup->id, 'name' => 'Ekstra Peynir'], ['price_modifier' => 1.50, 'is_default' => false, 'is_active' => true, 'sort_order' => 1]);
        ProductOption::query()->updateOrCreate(['product_option_group_id' => $extraGroup->id, 'name' => 'Pastırma'], ['price_modifier' => 2.00, 'is_default' => false, 'is_active' => true, 'sort_order' => 2]);
        ProductOption::query()->updateOrCreate(['product_option_group_id' => $extraGroup->id, 'name' => 'Karamelize Soğan'], ['price_modifier' => 1.00, 'is_default' => false, 'is_active' => true, 'sort_order' => 3]);

        // Spicy Burger
        Product::query()->updateOrCreate(
            ['restaurant_id' => $restaurant->id, 'slug' => 'spicy-burger'],
            [
                'menu_category_id' => $burgerCat->id,
                'name' => 'Spicy Burger',
                'description' => 'Acı biber sosu, jalapeno, çedar, sıcak sos',
                'base_price' => 16.90,
                'preparation_time_minutes' => 20,
                'is_available' => true,
                'is_active' => true,
                'sort_order' => 2,
            ]
        );

        // İçecekler
        foreach ([
            ['Cola', 4.50, 1],
            ['Ayran', 3.00, 2],
            ['Su', 1.50, 3],
        ] as [$name, $price, $order]) {
            Product::query()->updateOrCreate(
                ['restaurant_id' => $restaurant->id, 'slug' => \Illuminate\Support\Str::slug($name)],
                [
                    'menu_category_id' => $drinkCat->id,
                    'name' => $name,
                    'base_price' => $price,
                    'preparation_time_minutes' => 5,
                    'is_available' => true,
                    'is_active' => true,
                    'sort_order' => $order,
                ]
            );
        }

        // Yan ürünler
        foreach ([
            ['Patates Kızartması', 6.00, 1],
            ['Soğan Halkası', 5.50, 2],
        ] as [$name, $price, $order]) {
            Product::query()->updateOrCreate(
                ['restaurant_id' => $restaurant->id, 'slug' => \Illuminate\Support\Str::slug($name)],
                [
                    'menu_category_id' => $sideCat->id,
                    'name' => $name,
                    'base_price' => $price,
                    'preparation_time_minutes' => 10,
                    'is_available' => true,
                    'is_active' => true,
                    'sort_order' => $order,
                ]
            );
        }

        // ─── Kullanıcılar ─────────────────────────────────────────────────────
        User::query()->updateOrCreate(['email' => 'admin@glv.local'], [
            'city_id' => $sarajevo->id, 'restaurant_id' => null,
            'name' => 'GLV Admin', 'phone' => '+38761000000',
            'password' => Hash::make('password'),
            'role' => UserRole::ADMIN, 'is_active' => true, 'email_verified_at' => now(),
        ]);

        User::query()->updateOrCreate(['email' => 'restaurant@glv.local'], [
            'city_id' => $sarajevo->id, 'restaurant_id' => $restaurant->id,
            'name' => 'Demo Restaurant Manager', 'phone' => '+38761000001',
            'password' => Hash::make('password'),
            'role' => UserRole::RESTAURANT, 'is_active' => true, 'email_verified_at' => now(),
        ]);

        User::query()->updateOrCreate(['email' => 'customer@glv.local'], [
            'city_id' => $sarajevo->id, 'restaurant_id' => null,
            'name' => 'Demo Customer', 'phone' => '+38761000002',
            'password' => Hash::make('password'),
            'role' => UserRole::CUSTOMER, 'is_active' => true, 'email_verified_at' => now(),
        ]);

        $courier = User::query()->updateOrCreate(['email' => 'courier@glv.local'], [
            'city_id' => $sarajevo->id, 'restaurant_id' => null,
            'name' => 'Demo Courier', 'phone' => '+38761000003',
            'password' => Hash::make('password'),
            'role' => UserRole::COURIER, 'is_active' => true, 'email_verified_at' => now(),
        ]);

        $this->call([\\Database\\Seeders\\CouponSeeder::class]);

        CourierProfile::query()->updateOrCreate(['user_id' => $courier->id], [
            'is_online' => true, 'vehicle_type' => 'bike',
            'last_lat' => 43.8570000, 'last_lng' => 18.4120000, 'last_seen_at' => now(),
        ]);
    }
}
